Candle 10.9 AB - Phase 54
========================

New feature
-----------
Adds a "Check program" button beside the read-only XYZAB inspector.

When pressed, it selects the loaded program rows and refreshes the existing
inspection report over the complete parsed toolpath. The report reuses the
preview checks already available in this source tree:
- configured XYZ travel envelope (advisory, based on the current reported
  machine/work offset and the preview geometry);
- optional, independently configured A and B angular ranges;
- selected row/segment counts and XYZAB movement summary.

Safety and limitations
----------------------
- The action only changes the table selection and refreshes the preview report.
- It does not queue, stream, or send G-code, and does not issue motion commands.
- This is an advisory preview, not a machine safety interlock or substitute
  for FluidNC hard/soft limits, homing, workholding, or operator verification.
- The check depends on the currently loaded/parsed program and current displayed
  machine/work coordinates. It cannot guarantee actual physical position.
- A/B checks run only when each axis' own limit checkbox is enabled and its
  entered minimum is lower than its maximum. No angular range is guessed.
- The button selects all table rows (including non-motion source rows); rows
  without drawable segments contribute no path geometry.

Validation
----------
Source-level checks and archive integrity checks were performed. Qt compilation,
interactive GUI testing, FluidNC communication testing, and physical machine
validation have not been performed.
