CANDLE 10.9 - PHASE 6 (A/B ROTARY PREVIEW)

Changes in this phase:
- GcodeViewParse now applies rotary B angle deltas (the parsed B coordinate is axes().y()) as well as A deltas when building the preview transform.
- Linear moves are subdivided according to the larger of the A and B angular changes, then both rotations are applied incrementally.
- Arc preview segments apply both A and B angle deltas.
- The conventional preview mapping is A about X and B about Y. B preview rotation is disabled when the B axis setting is disabled.

Important limitations:
- This is a preview transform, not full five-axis machine kinematics or collision simulation.
- The rotary axes are assumed to pass through the visualizer origin. Real rotary tables/head pivots may require configurable pivot offsets and a defined machine layout.
- The B rotation axis is currently fixed to conventional Y; a future settings control should allow selecting X/Y/Z and pivot position.
- Source-level/static checks were performed (UI XML parsing and targeted code checks). A Qt build and hardware test were NOT performed.
- Test with motors A and B disconnected first. Do not use this preview as a substitute for checking machine limits, homing, work offsets, or safe tool clearance.
