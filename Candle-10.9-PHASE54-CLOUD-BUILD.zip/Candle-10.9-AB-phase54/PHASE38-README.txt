Candle 10.9 — Phase 38
======================

Purpose
-------
Make independent A and B rotary motion visible in the G-code toolpath preview.

Changes
-------
- Segments with A-only movement use a dedicated purple color.
- Segments with B-only movement use a dedicated teal color.
- Segments with simultaneous A+B movement use a dedicated amber color.
- Rotary classification uses the per-segment axesStart/axesEnd values already
  retained by the five-axis preview parser.
- Non-finite rotary values are ignored; a small 1e-6 degree threshold avoids
  classifying floating-point noise as real rotation.
- Toolpath simplification now treats changes in A/B movement class as
  boundaries, so it cannot merge A-only, B-only, and simultaneous A+B moves.
- Existing visual precedence is retained: drawn/highlighted, G0 rapid, and
  Z-movement colors take priority over rotary colors. Normal G1 segments retain
  the configured normal color.

Compatibility and scope
-----------------------
- This phase changes preview classification and color only.
- No G-code parsing, command transmission, jog, homing, FluidNC configuration,
  machine kinematics, or physical motion commands were added or changed.
- This classification reflects rotary coordinate deltas in the parsed
  segments; it does not prove the machine's physical orientation or TCP path.
- Colors are source defaults, not yet exposed as user preferences.

Validation
----------
- Static source checks cover A/B finite-delta classification, distinct colors,
  simultaneous A+B handling, and simplification boundaries.
- All Qt Designer .ui files are parsed as XML.
- ZIP integrity is checked.
- Qt compilation and physical machine tests have not been performed.
