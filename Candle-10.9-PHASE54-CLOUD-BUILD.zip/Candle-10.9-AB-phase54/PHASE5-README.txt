Candle 10.9 - Phase 5: five-axis jog pipeline (A/B)

Changes in this phase:
- B- and B+ now use press/release handlers rather than sending one isolated command on press.
- Incremental B jogging is routed through the same jogStep() path as X/Y/Z/A.
- Continuous B jogging is handled by jogContinuous() when the jog-step selector is set to 0.
- A and B are appended independently to the FluidNC $J jog command when their respective axis settings are enabled.
- Stop clears both the four-component XYZA vector and the B direction state before issuing the realtime jog-cancel byte (0x85).

Important limits:
- This is a source-level experimental change, not a compiled executable.
- Qt development tools/libraries were not available in the build environment, so a full compile and hardware test were not performed.
- Continuous B jog uses a 360-degree jog target, following the existing A-axis continuous-jog convention. Confirm your FluidNC build accepts rotary-axis $J commands and configure suitable rotary feed/rate limits before connecting the B motor.
- Test first with B motor disconnected or mechanically safe. Verify B+ and B- direction, jog cancel, and feed settings before normal operation.
- This phase does not implement simultaneous five-axis kinematics or rotary visualization.
