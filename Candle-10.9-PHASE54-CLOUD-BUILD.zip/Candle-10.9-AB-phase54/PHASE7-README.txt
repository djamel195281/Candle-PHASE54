CANDLE 10.9 - PHASE 7
Independent rotary axes A and B

DESIGN CHOICE
- A is treated as an independent rotary axis around machine X.
- B is treated as an independent rotary axis around machine Y.
- A and B remain separate coordinates in the G-code parser, status display,
  jog controls, and preview settings.
- This is a conventional starting arrangement for two independent rotary axes.
  The user can later request another orientation if the physical machine differs.

PREVIEW IMPROVEMENT
- Linear toolpath moves with rotary motion are subdivided using the largest
  angular change of A or B.
- The subdivision count now uses ceiling, so each preview segment stays at
  or below the configured 5-degree angular increment (rather than truncating
  fractional segments).
- Both A and B angular increments are applied during preview generation.

IMPORTANT LIMITATIONS
- This does not implement full five-axis inverse kinematics, machine-specific
  rotary pivot offsets, tool collision checking, or physical table geometry.
- The preview uses the current visualizer origin as the rotation origin.
- The A/B orientation choice is a software preview convention, not confirmation
  of the user's physical mounting geometry.
- A and B remain disabled by default in settings until enabled by the user.
- No Qt compilation or hardware test has been performed in this environment.

BUILD AND TEST STATUS
- Source-level targeted checks only.
- UI XML and archive integrity must be checked before distribution.
- A successful build and a controlled test with A/B axes disconnected are still
  required before connecting motors or running a real machine.
