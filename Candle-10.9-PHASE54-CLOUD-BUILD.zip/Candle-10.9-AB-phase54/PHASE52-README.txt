Candle 10.9 – Phase 52
======================

Independent optional angular travel checks for rotary axes A and B.

The program preview now exposes separate enable controls and minimum/maximum
angle fields for A and B. Both checks are disabled by default. The operator
must explicitly enable each axis and enter the real mechanical/configured
angular limits before the inspector evaluates the selected preview segments.
A and B are checked independently; no limit is inferred from XYZ bounds and
no generic +/-360 degree assumption is activated automatically.

The check examines both endpoints of each selected parsed segment and reports
how many segments exceed each enabled range. Invalid or reversed ranges remain
unchecked. This is a visual preflight aid only: it does not query FluidNC's
axis configuration, alter G-code, send motion commands, or replace controller
soft limits, hard limits, homing, or physical safety measures.

The values are currently session controls and return to their safe defaults
(disabled, -360..+360 displayed) when Candle is restarted. The displayed
values are placeholders only until the operator enters the actual machine
limits. Compilation and hardware testing have not been performed.
