Candle 10.9 — Phase 22
Synchronisation visuelle de la fraise, des pièces et des axes rotatifs A/B

Cette phase ajoute un repère lumineux de la pointe de l'outil dans le même
repère de coordonnées que le dessin de la fraise. Le repère est mis à jour
aux mêmes endroits du code que ToolDrawer lors des retours de position et
du suivi de lecture du programme.

Inclus :
- Repère en croix jaune à la position courante de la pointe de l'outil.
- Petite tige verticale orange comme indication visuelle de l'axe de broche.
- Mise à jour conjointe avec ToolDrawer lors des positions rapportées et du
  suivi de progression du programme.
- Conservation de l'affichage des trajectoires A/B et des angles A/B en direct.
- A et B restent deux axes indépendants.

Limites importantes :
- Le repère de pointe est un indicateur graphique, pas une détection de contact.
- La tige suppose une broche verticale; elle ne constitue pas une cinématique
  d'orientation de tête.
- Aucun enlèvement de matière, calcul de collision ou compensation cinématique
  n'est ajouté.
- Aucun G-code, paramètre FluidNC, coordonnée machine ou commande moteur n'est
  modifié par cette fonctionnalité.

Vérifications réalisées : contrôle des points d'appel et des symboles modifiés,
validation XML des interfaces Qt, contrôle d'intégrité de l'archive ZIP.
Compilation Qt et essai sur machine non réalisés dans cet environnement.
