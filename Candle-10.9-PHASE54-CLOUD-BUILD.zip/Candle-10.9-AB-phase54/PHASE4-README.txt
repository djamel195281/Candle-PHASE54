Candle 10.9 - Phase 4 (experimental source patch)

Adds an independent Enable axis B checkbox to Settings. The preference is persisted
under axisBEnabled and controls visibility of the B position readouts and B+/B-
incremental jog buttons. Existing default is false so existing users do not see B
controls unless they enable it.

This is source only. It has not been compiled or tested against a live FluidNC device.
Before connecting axis B, verify the FluidNC pin map, motor driver current, travel limits,
and that the controller reports five coordinates in its status response.
