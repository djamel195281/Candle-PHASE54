CANDLE 10.9 — PHASE 10

Objectif : préparer une visualisation rotative qui tient compte de centres/pivots
mécaniques configurables, sans modifier le comportement existant par défaut.

Modifications :
- Ajout dans GcodeViewParse d'un pivot indépendant pour chaque axe rotatif A, B et C.
- Ajout de setAxisRotationPivot() et getAxisRotationPivot() pour configurer/lire
  ces pivots depuis les prochaines étapes de l'interface.
- Les rotations A et B des segments linéaires et des arcs passent maintenant par
  une fonction commune qui applique une rotation autour du pivot correspondant.
- Les trois pivots sont initialisés à (0,0,0) : tant qu'aucun pivot n'est défini,
  le comportement reste celui de la version précédente.
- A et B conservent des vecteurs et des pivots séparés. Le réglage d'un axe
  n'écrase pas celui de l'autre.

Limites et prudence :
- Cette phase ajoute le moteur de transformation autour d'un pivot, mais ne crée
  pas encore les commandes graphiques de réglage des pivots dans les paramètres.
- Les valeurs de pivots sont exprimées dans le repère du modèle/aperçu ; il faudra
  définir précisément leur repère et leur ordre cinématique selon la mécanique
  réelle de la machine avant de les renseigner.
- La convention A autour de X et B autour de Y reste provisoire.
- Les rotations sont une approximation d'aperçu et ne constituent pas une
  cinématique complète : pas d'offset outil, de chaîne de tables/têtes, de
  cinématique inverse ni de détection de collision.
- Compilation Qt et essais matériels non réalisés dans cet environnement.

Vérifications statiques :
- Présence des API de pivot A/B/C.
- Initialisation des pivots à zéro.
- Utilisation de la fonction commune pour les rotations A/B des lignes et arcs.
- Validation XML des interfaces .ui et intégrité de l'archive ZIP.
