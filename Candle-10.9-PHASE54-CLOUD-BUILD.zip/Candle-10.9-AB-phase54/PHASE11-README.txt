CANDLE 10.9 — PHASE 11

Objectif : rendre les pivots A et B de l'aperçu configurables dans les paramètres,
avec mémorisation des valeurs entre les lancements.

Modifications :
- Ajout d'une section « Rotary axis preview pivots » dans les paramètres Machine.
- Six champs numériques : pivot A X/Y/Z et pivot B X/Y/Z, en millimètres.
- Valeurs autorisées : -100000 à +100000 mm, précision 0,001 mm.
- Sauvegarde et rechargement des six valeurs dans les paramètres Candle.
- Application des pivots au parseur de trajectoire A/B.
- Valeur par défaut de chaque coordonnée : 0 mm, pour conserver le comportement
  historique tant que la géométrie réelle n'a pas été mesurée.
- Le réglage de pivot n'active pas les axes A/B et ne modifie pas le G-code envoyé.

IMPORTANT :
- Ces pivots ne concernent que la transformation de l'aperçu de trajectoire.
- Les valeurs doivent rester à zéro tant que les centres mécaniques réels, le repère
  et l'ordre de la chaîne cinématique ne sont pas établis.
- La convention A autour de X et B autour de Y reste provisoire.
- Ce n'est pas encore une cinématique 5 axes complète : pas de cinématique inverse,
  d'offset outil, de chaîne table/tête, ni de détection de collision.
- Compilation Qt et essais matériels non réalisés dans cet environnement.

Vérifications statiques prévues : XML Qt, présence des six champs, persistance,
application des pivots et intégrité ZIP.
