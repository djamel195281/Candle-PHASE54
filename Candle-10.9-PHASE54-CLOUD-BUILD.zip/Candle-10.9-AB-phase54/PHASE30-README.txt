Candle 10.9 – Phase 30
Robust parsing of optional rotary status fields

Changes
- MPos parsing now updates A only when the A field is present and B only
  when the B field is present. Three-axis status reports no longer overwrite
  the last known rotary machine positions with zero.
- The script device receives the current displayed A and B machine positions,
  including retained values when a status report omits one or both rotary axes.
- WCO parsing always refreshes XYZ offsets, but refreshes A and B offsets only
  when the corresponding optional fields are present. An omitted rotary offset
  no longer erases the previously known value.
- Corrected the B machine-position range check to compare the incoming B value,
  rather than the previous displayed value.
- A and B remain independent; no coupling, homing, startup motion, or new
  controller commands have been introduced.

Safety and scope
- This is a status-parsing/UI-state correction. It does not command axis motion.
- Retained rotary values are only as trustworthy as the last valid controller
  report; this does not establish homing or machine position after a reset.
- Verify the actual FluidNC status format for the configured axes before relying
  on displayed coordinates for recovery or machining.

Validation performed
- Source-level assertions checked conditional A/B updates and preservation of
  omitted fields.
- All .ui XML files were parsed.
- ZIP integrity was checked after packaging.
- Qt compilation and physical machine tests were not performed.
