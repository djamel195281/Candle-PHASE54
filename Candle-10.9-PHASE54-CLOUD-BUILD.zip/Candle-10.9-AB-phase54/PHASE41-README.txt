Candle 10.9 - Phase 41
Read-only XYZAB G-code row inspector

Changes
-------
- Adds a read-only information label below the independent A/B preview filters.
- When a G-code table row is selected, the label reports the parsed movement type
  (G0, G1, G2 or G3), whether A and/or B changes, and start/end XYZAB values.
- XYZ values come from the original programmed model coordinates (modelStart/modelEnd),
  not the transformed 3D preview coordinates. This matters when rotary preview
  transformations are active.
- A and B values are read independently from the parser's rotary-axis coordinate
  storage (axesStart/axesEnd).
- Adds guards for empty/invalid table selections and validates segment indexes
  before reading them for the inspector or selection marker.
- Inspection is display-only. It does not send commands, alter G-code, change
  FluidNC settings, home axes, or initiate motion.

Limitations / validation
------------------------
- The report describes Candle's parsed preview data; it is not a live confirmation
  of physical machine position or motor movement.
- The current A/B parser convention stores A in axes*.x() and B in axes*.y().
- Qt compilation and physical machine tests were not performed in this environment.
- A/B motors must remain untested until their wiring, driver current limits,
  limit inputs and emergency-stop behavior have been checked.
