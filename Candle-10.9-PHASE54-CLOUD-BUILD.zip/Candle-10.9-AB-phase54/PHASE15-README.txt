Candle 10.9 - Phase 15

Changes:
- Added independent visibility toggles for the A and B rotary preview tables.
- Added configurable width and depth for each schematic table (millimetres).
- Persisted the four dimensions and two visibility options in Candle settings.
- The preview tables use the existing A/B pivot positions and live angles.
- Display is gated by both the corresponding machine axis enable setting and the new preview visibility toggle.

Safety / scope:
- These are schematic wireframe preview dimensions only; they do not change machine travel, FluidNC settings, G-code, motor commands, or physical limits.
- Default dimensions are 32 x 24 mm for both tables. Measure the real fixtures before using dimensions as a visual reference.
- A remains a rotation about X and B about Y as a provisional preview convention. Actual machine geometry may differ.
- Qt compilation and physical machine tests have not been performed in this environment.
