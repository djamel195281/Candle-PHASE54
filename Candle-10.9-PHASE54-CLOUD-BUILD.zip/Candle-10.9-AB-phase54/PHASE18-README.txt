Candle 10.9 — Phase 18
Correction de l'echelle reelle des pieces brutes A et B

Cette phase corrige un decalage entre les dimensions saisies dans les reglages
et la taille effectivement dessinee dans l'aperçu 3D.

Avant : la largeur et la profondeur de la piece etaient multipliees par 0,60.
Une piece configuree a 20 x 15 mm apparaissait donc a 12 x 9 mm.

Maintenant : largeur et profondeur utilisees dans le dessin correspondent aux
valeurs configurees, en millimetres. Les axes A et B conservent leurs dimensions
independantes, leurs formes rectangulaire/cylindrique et leurs rotations
independantes autour des pivots respectifs.

Si une piece depasse la table rotative, l'aperçu la montre a sa vraie taille ;
il ne la reduit pas automatiquement. Cela permet de reperer une incoherence
de configuration. Ce dessin ne constitue pas un controle de collision.

Limites :
- Apercu filaire uniquement ; aucune simulation de retrait de matiere.
- Pas de calcul booleen de fraise/stock, pas de detection de collision.
- La convention provisoire A autour de X et B autour de Y reste a confirmer
  avec la geometrie reelle de la machine.
- Aucun G-code, parametre FluidNC, decalage outil ou commande moteur modifie.
- Compilation Qt et essai machine non effectues dans cet environnement.

Verification effectuee : controle statique du changement et validation XML des
interfaces Qt presentes dans l'archive. Cela ne remplace pas une compilation.
