Candle 10.9 — Phase 39
======================

Adds a compact explanatory legend directly beneath the 3D visualizer.

Legend mapping is aligned with the current preview implementation:
- Blue: G0 rapid moves (GcodeDrawer rapid color).
- Orange: A-only rotary preview segments.
- Cyan: B-only rotary preview segments.
- Magenta: simultaneous A+B rotary preview segments.
- G1: normal configured path color.

The legend is a QLabel inserted into the existing visualizer layout. It is
explanatory UI only. It does not change parser behavior, segment colors,
coordinate calculations, motion commands, homing, or FluidNC settings.

Validation performed:
- Static source assertions for the legend, labels, and layout insertion.
- XML parsing of all .ui files.
- ZIP integrity check.

Not performed:
- Qt compilation, application launch, or physical machine tests.
