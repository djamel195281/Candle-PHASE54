﻿// This file is a part of "Candle" application.
// Copyright 2015-2025 Hayrullin Denis Ravilevich

#include <algorithm>
#include <QFileDialog>
#include <QAbstractItemView>
#include <QTextStream>
#include <QDebug>
#include <QDesktopServices>
#include <QStringList>
#include <QTextBlock>
#include <QTextCursor>
#include <QMessageBox>
#include <QComboBox>
#include <QCheckBox>
#include <QDoubleSpinBox>
#include <QPushButton>
#include <QApplication>
#include <QScreen>
#include <QHBoxLayout>
#include <QScrollBar>
#include <QShortcut>
#include <QAction>
#include <QLayout>
#include <QDrag>
#include <QMimeData>
#include <QTranslator>
#include <QScriptValueIterator>
#include <QSplitter>
#include <QInputDialog>
#include <QElapsedTimer>
#include "frmmain.h"
#include "ui_frmmain.h"
#include "ui_frmsettings.h"
#include "widgets/widgetmimedata.h"
#include "loggingcategories.h"
#include "layoutentry.h"
#include "settingsprofileentry.h"
#include "utils/optarg.h"

frmMain::frmMain(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::frmMain)
{
    // Initializing variables
    m_deviceStatuses[DeviceUnknown] = "Unknown";
    m_deviceStatuses[DeviceIdle] = "Idle";
    m_deviceStatuses[DeviceAlarm] = "Alarm";
    m_deviceStatuses[DeviceRun] = "Run";
    m_deviceStatuses[DeviceHome] = "Home";
    m_deviceStatuses[DeviceHold0] = "Hold:0";
    m_deviceStatuses[DeviceHold1] = "Hold:1";
    m_deviceStatuses[DeviceQueue] = "Queue";
    m_deviceStatuses[DeviceCheck] = "Check";
    m_deviceStatuses[DeviceDoor0] = "Door:0";
    m_deviceStatuses[DeviceDoor1] = "Door:1";
    m_deviceStatuses[DeviceDoor2] = "Door:2";
    m_deviceStatuses[DeviceDoor3] = "Door:3";
    m_deviceStatuses[DeviceJog] = "Jog";
    m_deviceStatuses[DeviceSleep] = "Sleep";

	m_statusCaptions[DeviceUnknown] = tr("Unknown");
	m_statusCaptions[DeviceIdle] = tr("Idle");
	m_statusCaptions[DeviceAlarm] = tr("Alarm");
	m_statusCaptions[DeviceRun] = tr("Run");
	m_statusCaptions[DeviceHome] = tr("Home");
	m_statusCaptions[DeviceHold0] = tr("Hold") + " (0)";
	m_statusCaptions[DeviceHold1] = tr("Hold") + " (1)";
	m_statusCaptions[DeviceQueue] = tr("Queue");
	m_statusCaptions[DeviceCheck] = tr("Check");
	m_statusCaptions[DeviceDoor0] = tr("Door") + " (0)";
	m_statusCaptions[DeviceDoor1] = tr("Door") + " (1)";
	m_statusCaptions[DeviceDoor2] = tr("Door") + " (2)";
	m_statusCaptions[DeviceDoor3] = tr("Door") + " (3)";
	m_statusCaptions[DeviceJog] = tr("Jog");
	m_statusCaptions[DeviceSleep] = tr("Sleep");

	m_statusBackColors[DeviceUnknown] = "red";
	m_statusBackColors[DeviceIdle] = "palette(button)";
	m_statusBackColors[DeviceAlarm] = "red";
	m_statusBackColors[DeviceRun] = "lime";
	m_statusBackColors[DeviceHome] = "lime";
	m_statusBackColors[DeviceHold0] = "yellow";
	m_statusBackColors[DeviceHold1] = "yellow";
	m_statusBackColors[DeviceQueue] = "yellow";
	m_statusBackColors[DeviceCheck] = "palette(button)";
	m_statusBackColors[DeviceDoor0] = "red";
	m_statusBackColors[DeviceDoor1] = "red";
	m_statusBackColors[DeviceDoor2] = "red";
	m_statusBackColors[DeviceDoor3] = "red";
	m_statusBackColors[DeviceJog] = "lime";
	m_statusBackColors[DeviceSleep] = "blue";

	m_statusForeColors[DeviceUnknown] = "white";
	m_statusForeColors[DeviceIdle] = "palette(text)";
	m_statusForeColors[DeviceAlarm] = "white";
	m_statusForeColors[DeviceRun] = "black";
	m_statusForeColors[DeviceHome] = "black";
	m_statusForeColors[DeviceHold0] = "black";
	m_statusForeColors[DeviceHold1] = "black";
	m_statusForeColors[DeviceQueue] = "black";
	m_statusForeColors[DeviceCheck] = "palette(text)";
	m_statusForeColors[DeviceDoor0] = "white";
	m_statusForeColors[DeviceDoor1] = "white";
	m_statusForeColors[DeviceDoor2] = "white";
	m_statusForeColors[DeviceDoor3] = "white";
	m_statusForeColors[DeviceJog] = "black";
	m_statusForeColors[DeviceSleep] = "white";

    m_fileChanged = false;
    m_heightMapChanged = false;

    m_homing = false;
    m_updateSpindleSpeed = false;
    m_updateParserStatus = false;

    m_reseting = false;
    m_resetCompleted = true;
    m_aborting = false;
    m_statusReceived = false;

    m_deviceState = DeviceUnknown;
    m_senderState = SenderUnknown;

    m_spindleCW = true;

    // Loading settings

    m_settings = new frmSettings(this);
    m_about = new frmAbout(this);

    ui->setupUi(this);

    // Phase 39: compact legend for the independent five-axis preview.
    // Keep the legend outside the GL scene: it is explanatory UI only and
    // does not alter the G-code parser, toolpath colors, or machine commands.
    QLabel *rotaryLegend = new QLabel(ui->fraProgram);
    rotaryLegend->setObjectName("lblRotaryToolpathLegend");
    rotaryLegend->setTextFormat(Qt::RichText);
    rotaryLegend->setWordWrap(true);
    rotaryLegend->setText(
        tr("<b>Toolpath legend:</b> ") +
        QStringLiteral("<span style='color:#1e90ff'>&#9632;</span> G0 ") +
        QStringLiteral("<span style='color:#ff9e20'>&#9632;</span> A ") +
        QStringLiteral("<span style='color:#20dfff'>&#9632;</span> B ") +
        QStringLiteral("<span style='color:#f279ff'>&#9632;</span> A+B ") +
        tr("G1: normal path color"));
    rotaryLegend->setToolTip(tr("G0 rapid; A and B independent rotary moves; A+B simultaneous rotary moves; G1 uses the normal path color."));
    rotaryLegend->setContentsMargins(6, 2, 6, 2);
    ui->verticalLayout_8->insertWidget(1, rotaryLegend);

    // Phase 25: live XYZAB readout and program progress (display only).
    m_axisMonitorLabel = new QLabel(this);
    m_axisMonitorLabel->setMinimumWidth(520);
    m_axisMonitorLabel->setText(tr("X: --  Y: --  Z: --  A: --  B: --  Progress: --"));
    statusBar()->addPermanentWidget(m_axisMonitorLabel, 1);

    // Drag&drop placeholders
    ui->fraDropDevice->setVisible(false);
    ui->fraDropModification->setVisible(false);
    ui->fraDropUser->setVisible(false);

#ifdef WINDOWS
    if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
        m_taskBarButton = NULL;
        m_taskBarProgress = NULL;
    }
#endif

    m_heightMapMode = false;
    m_lastDrawnLineIndex = 0;
    m_fileProcessedCommandIndex = 0;
    m_programLoading = false;
    m_currentModel = &m_programModel;

    // Dock widgets
    setCorner(Qt::TopLeftCorner, Qt::LeftDockWidgetArea);
    setCorner(Qt::BottomLeftCorner, Qt::LeftDockWidgetArea);
    setCorner(Qt::TopRightCorner, Qt::RightDockWidgetArea);
    setCorner(Qt::BottomRightCorner, Qt::RightDockWidgetArea);

    ui->widgetHeightmapSettings->setVisible(false);

    ui->cmdXMinus->setBackColor(QColor(153, 180, 209));
    ui->cmdXPlus->setBackColor(ui->cmdXMinus->backColor());
    ui->cmdYMinus->setBackColor(ui->cmdXMinus->backColor());
    ui->cmdYPlus->setBackColor(ui->cmdXMinus->backColor());

    ui->cmdFit->setParent(ui->glwVisualizer);
    ui->cmdIsometric->setParent(ui->glwVisualizer);
    ui->cmdTop->setParent(ui->glwVisualizer);
    ui->cmdFront->setParent(ui->glwVisualizer);
    ui->cmdLeft->setParent(ui->glwVisualizer);
    ui->cmdPerspective->setParent(ui->glwVisualizer);

    ui->cmdHeightMapBorderAuto->setMinimumHeight(ui->chkHeightMapBorderShow->sizeHint().height());
    ui->cmdHeightMapCreate->setMinimumHeight(ui->cmdFileOpen->sizeHint().height());
    ui->cmdHeightMapLoad->setMinimumHeight(ui->cmdFileOpen->sizeHint().height());
    ui->cmdHeightMapMode->setMinimumHeight(ui->cmdFileOpen->sizeHint().height());
    ui->cmdHeightMapOrigin->setMinimumHeight(ui->cmdFileOpen->sizeHint().height());
    ui->cmdHeightMapOriginTool->setMinimumHeight(ui->chkHeightMapOriginShow->sizeHint().height());

    ui->cboJogStep->lineEdit()->setValidator(new QDoubleValidator(0, 10000, 2));
    ui->cboJogFeed->lineEdit()->setValidator(new QIntValidator(0, 100000));
    connect(ui->cboJogStep, &ComboBoxKey::currentTextChanged, this, &frmMain::updateJogTitle);
    connect(ui->cboJogFeed, &ComboBoxKey::currentTextChanged, this, &frmMain::updateJogTitle);

    // Prepare "Send"-button
    ui->cmdFileSend->setMinimumWidth(qMax(ui->cmdFileSend->width(), ui->cmdFileOpen->width()));
    QMenu *menuSend = new QMenu();
    menuSend->addAction(tr("Send from current line"), this, SLOT(onActSendFromLineTriggered()));
    ui->cmdFileSend->setMenu(menuSend);

    connect(ui->cboCommand, SIGNAL(returnPressed()), this, SLOT(onCboCommandReturnPressed()));

    foreach (StyledToolButton* button, this->findChildren<StyledToolButton*>(QRegExp("cmdUser\\d"))) {
        connect(button, SIGNAL(clicked(bool)), this, SLOT(onCmdUserClicked(bool)));
    }

    // Setting up slider boxes
    ui->slbFeedOverride->setRatio(1);
    ui->slbFeedOverride->setMinimum(10);
    ui->slbFeedOverride->setMaximum(200);
    ui->slbFeedOverride->setCurrentValue(100);
    ui->slbFeedOverride->setTitle(tr("Feed rate:"));
    ui->slbFeedOverride->setSuffix("%");
    connect(ui->slbFeedOverride, SIGNAL(toggled(bool)), this, SLOT(onOverridingToggled(bool)));
    connect(ui->slbFeedOverride, &SliderBox::toggled, this, &frmMain::onOverrideChanged);
    connect(ui->slbFeedOverride, &SliderBox::valueChanged, this, &frmMain::onOverrideChanged);

    ui->slbRapidOverride->setRatio(50);
    ui->slbRapidOverride->setMinimum(25);
    ui->slbRapidOverride->setMaximum(100);
    ui->slbRapidOverride->setCurrentValue(100);
    ui->slbRapidOverride->setTitle(tr("Rapid speed:"));
    ui->slbRapidOverride->setSuffix("%");
    connect(ui->slbRapidOverride, SIGNAL(toggled(bool)), this, SLOT(onOverridingToggled(bool)));
    connect(ui->slbRapidOverride, &SliderBox::toggled, this, &frmMain::onOverrideChanged);
    connect(ui->slbRapidOverride, &SliderBox::valueChanged, this, &frmMain::onOverrideChanged);

    ui->slbSpindleOverride->setRatio(1);
    ui->slbSpindleOverride->setMinimum(50);
    ui->slbSpindleOverride->setMaximum(200);
    ui->slbSpindleOverride->setCurrentValue(100);
    ui->slbSpindleOverride->setTitle(tr("Spindle speed:"));
    ui->slbSpindleOverride->setSuffix("%");
    connect(ui->slbSpindleOverride, SIGNAL(toggled(bool)), this, SLOT(onOverridingToggled(bool)));

    m_originDrawer = new OriginDrawer();
    m_codeDrawer = new GcodeDrawer();
    m_codeDrawer->setViewParser(&m_viewParser);
    // Phase 40: independent display filters for rotary toolpath segments.
    // These controls affect preview visibility only; they never alter G-code.
    QWidget *rotaryFilterRow = new QWidget(ui->fraProgram);
    QHBoxLayout *rotaryFilterLayout = new QHBoxLayout(rotaryFilterRow);
    rotaryFilterLayout->setContentsMargins(6, 0, 6, 0);
    rotaryFilterLayout->setSpacing(12);
    QCheckBox *showRotaryA = new QCheckBox(tr("Show A moves"), rotaryFilterRow);
    QCheckBox *showRotaryB = new QCheckBox(tr("Show B moves"), rotaryFilterRow);
    showRotaryA->setObjectName("chkShowRotaryA");
    showRotaryB->setObjectName("chkShowRotaryB");
    showRotaryA->setChecked(true);
    showRotaryB->setChecked(true);
    showRotaryA->setToolTip(tr("Show or hide segments that move rotary axis A. Combined A+B segments require both filters."));
    showRotaryB->setToolTip(tr("Show or hide segments that move rotary axis B. Combined A+B segments require both filters."));
    rotaryFilterLayout->addWidget(showRotaryA);
    rotaryFilterLayout->addWidget(showRotaryB);
    rotaryFilterLayout->addStretch(1);
    ui->verticalLayout_8->insertWidget(2, rotaryFilterRow);

    // Phase 52: optional independent A/B angular travel envelopes for preview.
    // Disabled by default: the operator must enter the real machine limits.
    QWidget *rotaryLimitRow = new QWidget(ui->fraProgram);
    QHBoxLayout *rotaryLimitLayout = new QHBoxLayout(rotaryLimitRow);
    rotaryLimitLayout->setContentsMargins(6, 0, 6, 0);
    rotaryLimitLayout->setSpacing(5);
    m_checkRotaryALimits = new QCheckBox(tr("A limits"), rotaryLimitRow);
    m_checkRotaryBLimits = new QCheckBox(tr("B limits"), rotaryLimitRow);
    auto makeAngleLimit = [rotaryLimitRow](double value) {
        QDoubleSpinBox *spin = new QDoubleSpinBox(rotaryLimitRow);
        spin->setRange(-1000000.0, 1000000.0);
        spin->setDecimals(3);
        spin->setSingleStep(15.0);
        spin->setSuffix(QString::fromUtf8("°"));
        spin->setValue(value);
        spin->setMaximumWidth(105);
        return spin;
    };
    m_rotaryAMinLimit = makeAngleLimit(-360.0);
    m_rotaryAMaxLimit = makeAngleLimit(360.0);
    m_rotaryBMinLimit = makeAngleLimit(-360.0);
    m_rotaryBMaxLimit = makeAngleLimit(360.0);
    m_checkRotaryALimits->setObjectName("chkRotaryALimits");
    m_checkRotaryBLimits->setObjectName("chkRotaryBLimits");
    m_rotaryAMinLimit->setObjectName("spinRotaryAMinLimit");
    m_rotaryAMaxLimit->setObjectName("spinRotaryAMaxLimit");
    m_rotaryBMinLimit->setObjectName("spinRotaryBMinLimit");
    m_rotaryBMaxLimit->setObjectName("spinRotaryBMaxLimit");
    m_checkRotaryALimits->setToolTip(tr("Enable the preview-only angular range check for axis A. Enter the actual configured machine limits."));
    m_checkRotaryBLimits->setToolTip(tr("Enable the preview-only angular range check for axis B. Enter the actual configured machine limits."));
    m_rotaryAMinLimit->setToolTip(tr("Minimum A angle in degrees"));
    m_rotaryAMaxLimit->setToolTip(tr("Maximum A angle in degrees"));
    m_rotaryBMinLimit->setToolTip(tr("Minimum B angle in degrees"));
    m_rotaryBMaxLimit->setToolTip(tr("Maximum B angle in degrees"));
    rotaryLimitLayout->addWidget(m_checkRotaryALimits);
    rotaryLimitLayout->addWidget(m_rotaryAMinLimit);
    rotaryLimitLayout->addWidget(m_rotaryAMaxLimit);
    rotaryLimitLayout->addSpacing(10);
    rotaryLimitLayout->addWidget(m_checkRotaryBLimits);
    rotaryLimitLayout->addWidget(m_rotaryBMinLimit);
    rotaryLimitLayout->addWidget(m_rotaryBMaxLimit);
    rotaryLimitLayout->addStretch(1);
    ui->verticalLayout_8->insertWidget(3, rotaryLimitRow);

    // Phase 41: read-only details for the currently selected G-code row.
    // This is an inspection aid only: it never queues or sends machine commands.
    QWidget *rotaryInspectorRow = new QWidget(ui->fraProgram);
    QHBoxLayout *rotaryInspectorLayout = new QHBoxLayout(rotaryInspectorRow);
    rotaryInspectorLayout->setContentsMargins(6, 2, 6, 4);
    rotaryInspectorLayout->setSpacing(8);
    m_rotarySegmentInfoLabel = new QLabel(rotaryInspectorRow);
    m_rotarySegmentInfoLabel->setObjectName("lblRotarySegmentInfo");
    m_rotarySegmentInfoLabel->setWordWrap(true);
    m_rotarySegmentInfoLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    m_rotarySegmentInfoLabel->setText(tr("Select a G-code row to inspect its XYZAB movement."));
    m_rotarySegmentInfoLabel->setToolTip(tr("Read-only preview of the selected parsed G-code line; displayed values are not a confirmation of physical machine position."));
    // Phase 43: navigate between drawable G-code movements without sending commands.
    QPushButton *previousMovementButton = new QPushButton(tr("◀ Prev"), rotaryInspectorRow);
    previousMovementButton->setObjectName("btnPreviousRotaryMovement");
    previousMovementButton->setToolTip(tr("Select the previous G-code row that contains a drawable movement."));
    QPushButton *nextMovementButton = new QPushButton(tr("Next ▶"), rotaryInspectorRow);
    nextMovementButton->setObjectName("btnNextRotaryMovement");
    nextMovementButton->setToolTip(tr("Select the next G-code row that contains a drawable movement."));
    rotaryInspectorLayout->addWidget(previousMovementButton, 0, Qt::AlignTop);
    rotaryInspectorLayout->addWidget(nextMovementButton, 0, Qt::AlignTop);

    auto selectAdjacentMovement = [this](int direction) {
        if (!m_currentModel || !m_currentDrawer || !ui || direction == 0) return;
        const int rowCount = m_currentModel->rowCount();
        if (rowCount < 2) return; // Last row is Candle's editable empty row.
        const int currentRow = ui->tblProgram->currentIndex().isValid()
                ? ui->tblProgram->currentIndex().row() : (direction > 0 ? -1 : rowCount);
        GcodeViewParse *parser = m_currentDrawer->viewParser();
        if (!parser) return;
        const QVector<QList<int>> lineIndexes = parser->getLinesIndexes();
        const QList<LineSegment*> segments = parser->getLineSegmentList();
        for (int row = currentRow + direction; row >= 0 && row < rowCount - 1; row += direction) {
            const int sourceLine = m_currentModel->data(m_currentModel->index(row, 4)).toInt();
            if (sourceLine < 0 || sourceLine >= lineIndexes.count()) continue;
            bool hasDrawableMovement = false;
            for (int segmentIndex : lineIndexes.at(sourceLine)) {
                if (segmentIndex >= 0 && segmentIndex < segments.count() && segments.at(segmentIndex)) {
                    hasDrawableMovement = true;
                    break;
                }
            }
            if (!hasDrawableMovement) continue;
            const QModelIndex target = m_currentModel->index(row, 0);
            if (!target.isValid()) return;
            ui->tblProgram->setCurrentIndex(target);
            ui->tblProgram->selectRow(row);
            ui->tblProgram->scrollTo(target, QAbstractItemView::EnsureVisible);
            return;
        }
    };
    connect(previousMovementButton, &QPushButton::clicked, this, [selectAdjacentMovement]() {
        selectAdjacentMovement(-1);
    });
    connect(nextMovementButton, &QPushButton::clicked, this, [selectAdjacentMovement]() {
        selectAdjacentMovement(1);
    });

    // Phase 54: run the same read-only XYZAB inspection over every source
    // row in the loaded program. Selecting rows does not queue or send G-code.
    QPushButton *preflightProgramButton = new QPushButton(tr("Check program"), rotaryInspectorRow);
    preflightProgramButton->setObjectName("btnPreflightProgram");
    preflightProgramButton->setToolTip(tr("Select and inspect the complete loaded toolpath for configured XYZAB preview limits. This is advisory only and sends no commands."));
    connect(preflightProgramButton, &QPushButton::clicked, this, [this]() {
        if (!ui || !m_currentModel || !ui->tblProgram->selectionModel()
                || m_currentModel->rowCount() < 2) return;
        ui->tblProgram->selectAll();
        QModelIndex current = ui->tblProgram->currentIndex();
        if (!current.isValid() || current.row() >= m_currentModel->rowCount() - 1) {
            current = m_currentModel->index(0, 0);
            ui->tblProgram->setCurrentIndex(current);
        }
        // selectAll() changes the selection but not necessarily the current
        // index, so explicitly refresh the inspector after the selection settles.
        onTableCurrentChanged(current, QModelIndex());
    });

    m_rotarySegmentCopyButton = new QPushButton(tr("Copy"), rotaryInspectorRow);
    m_rotarySegmentCopyButton->setObjectName("btnCopyRotarySegmentInfo");
    m_rotarySegmentCopyButton->setToolTip(tr("Copy the selected movement details as text. This does not send anything to the machine."));
    m_rotarySegmentCopyButton->setEnabled(false);
    rotaryInspectorLayout->addWidget(m_rotarySegmentInfoLabel, 1);
    rotaryInspectorLayout->addWidget(preflightProgramButton, 0, Qt::AlignTop);
    rotaryInspectorLayout->addWidget(m_rotarySegmentCopyButton, 0, Qt::AlignTop);
    connect(m_rotarySegmentCopyButton, &QPushButton::clicked, this, [this]() {
        if (m_rotarySegmentInfoLabel && m_rotarySegmentCopyButton && m_rotarySegmentCopyButton->isEnabled()) {
            QApplication::clipboard()->setText(m_rotarySegmentInfoLabel->text());
        }
    });
    ui->verticalLayout_8->insertWidget(4, rotaryInspectorRow);

    connect(showRotaryA, &QCheckBox::toggled, m_codeDrawer, &GcodeDrawer::setShowRotaryA);
    connect(showRotaryB, &QCheckBox::toggled, m_codeDrawer, &GcodeDrawer::setShowRotaryB);
    m_probeDrawer = new GcodeDrawer();
    m_probeDrawer->setViewParser(&m_probeParser);
    m_probeDrawer->setVisible(false);
    m_heightMapGridDrawer.setModel(&m_heightMapModel);
    m_heightMapOriginDrawer.setWorldScale(3);
    m_currentDrawer = m_codeDrawer;
    m_toolDrawer.setToolPosition(QVector3D(0, 0, 0));
    m_rotaryPivotDrawer.setToolPosition(QVector3D(0, 0, 0));
    m_selectionDrawer.setVisible(false);
    m_machineBoundsDrawer.setVisible(false);

    m_tableMenu = new QMenu(this);
    m_tableMenu->addAction(tr("&Insert line"), this, SLOT(onTableInsertLine()), QKeySequence(Qt::Key_Insert));
    m_tableMenu->addAction(tr("&Delete lines"), this, SLOT(onTableDeleteLines()), QKeySequence(Qt::Key_Delete));

    ui->glwVisualizer->addDrawable(m_originDrawer);
    ui->glwVisualizer->addDrawable(m_codeDrawer);
    ui->glwVisualizer->addDrawable(m_probeDrawer);
    ui->glwVisualizer->addDrawable(&m_toolDrawer);
    ui->glwVisualizer->addDrawable(&m_heightMapBorderDrawer);
    ui->glwVisualizer->addDrawable(&m_heightMapOriginDrawer);
    ui->glwVisualizer->addDrawable(&m_heightMapGridDrawer);
    ui->glwVisualizer->addDrawable(&m_heightMapInterpolationDrawer);
    ui->glwVisualizer->addDrawable(&m_selectionDrawer);
    ui->glwVisualizer->addDrawable(&m_machineBoundsDrawer);
    ui->glwVisualizer->addDrawable(&m_rotaryPivotDrawer);
    // Phase 44: clicking a visible toolpath segment selects its source G-code row.
    // This is a read-only preview interaction; it never sends motion commands.
    connect(ui->glwVisualizer, &GLWidget::sceneClicked, this, [this](const QPoint &position) {
        if (!m_currentModel || !m_currentDrawer || !m_codeDrawer || m_currentModel->rowCount() < 2) return;
        const int sourceLine = m_codeDrawer->findSegmentLineAtScreenPosition(
                    position, ui->glwVisualizer->size(), ui->glwVisualizer->projectionMatrix(),
                    ui->glwVisualizer->viewMatrix(), 10.0);
        if (sourceLine < 0) return;
        for (int row = 0; row < m_currentModel->rowCount() - 1; ++row) {
            bool ok = false;
            const int rowLine = m_currentModel->data(m_currentModel->index(row, 4)).toInt(&ok);
            if (ok && rowLine == sourceLine) {
                const QModelIndex target = m_currentModel->index(row, 0);
                ui->tblProgram->setCurrentIndex(target);
                ui->tblProgram->selectRow(row);
                ui->tblProgram->scrollTo(target, QAbstractItemView::EnsureVisible);
                break;
            }
        }
    });
    ui->glwVisualizer->fitDrawable();

    connect(ui->glwVisualizer, SIGNAL(resized()), this, SLOT(placeVisualizerButtons()));
    connect(&m_programModel, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCellChanged(QModelIndex,QModelIndex)));
    connect(&m_programHeightmapModel, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCellChanged(QModelIndex,QModelIndex)));
    connect(&m_probeModel, SIGNAL(dataChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCellChanged(QModelIndex,QModelIndex)));
    connect(&m_heightMapModel, SIGNAL(dataChangedByUserInput()), this, SLOT(updateHeightMapInterpolationDrawer()));

    ui->tblProgram->setModel(&m_programModel);
    // Phase 48: allow selecting several source rows for read-only toolpath inspection.
    ui->tblProgram->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tblProgram->setSelectionMode(QAbstractItemView::ExtendedSelection);
    ui->tblProgram->horizontalHeader()->setSectionResizeMode(3, QHeaderView::Stretch);
    connect(ui->tblProgram->verticalScrollBar(), SIGNAL(actionTriggered(int)), this, SLOT(onScroolBarAction(int)));
    connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));
    clearTable();

    m_senderErrorBox = new QMessageBox(QMessageBox::Warning, qApp->applicationDisplayName(), QString(),
                                       QMessageBox::Ignore | QMessageBox::Abort, this);
    m_senderErrorBox->setCheckBox(new QCheckBox(tr("Don't show again")));

    // Prepare script functions
    m_scriptApp = new ScriptApp(this);
    connect(this, &frmMain::responseReceived, m_scriptApp->device(), &ScriptDevice::responseReceived);
    connect(this, &frmMain::statusReceived, m_scriptApp->device(), &ScriptDevice::statusReceived);
    connect(this, &frmMain::deviceStateChanged, m_scriptApp->device(), &ScriptDevice::stateChanged);
    connect(this, &frmMain::senderStateChanged, m_scriptApp->sender(), &ScriptSender::stateChanged);
    connect(this, &frmMain::settingsAboutToLoad, m_scriptApp, &ScriptApp::settingsAboutToLoad);
    connect(this, &frmMain::settingsLoaded, m_scriptApp, &ScriptApp::settingsLoaded);
    connect(this, &frmMain::settingsAboutToSave, m_scriptApp, &ScriptApp::settingsAboutToSave);
    connect(this, &frmMain::settingsSaved, m_scriptApp, &ScriptApp::settingsSaved);
    connect(this, &frmMain::settingsAboutToShow, m_scriptApp, &ScriptApp::settingsAboutToShow);
    connect(this, &frmMain::settingsAccepted, m_scriptApp, &ScriptApp::settingsAccepted);
    connect(this, &frmMain::settingsRejected, m_scriptApp, &ScriptApp::settingsRejected);
    connect(this, &frmMain::settingsSetByDefault, m_scriptApp, &ScriptApp::settingsSetByDefault);
    connect(this, &frmMain::pluginsLoaded, m_scriptApp, &ScriptApp::pluginsLoaded);

    // Loading settings
    loadSettings();
    ui->tblProgram->hideColumn(4);
    ui->tblProgram->hideColumn(5);

    setSenderState(SenderStopped);
    updateControlsState();

    // Prepare jog buttons
    foreach (StyledToolButton* button, ui->grpJog->findChildren<StyledToolButton*>(QRegExp("cmdJogFeed\\d")))
    {
        connect(button, SIGNAL(clicked(bool)), this, SLOT(onCmdJogFeedClicked()));
    }

    // Setting up spindle slider box
    ui->slbSpindle->setTitle(tr("Speed:"));
    ui->slbSpindle->setCheckable(false);
    ui->slbSpindle->setChecked(true);
    connect(ui->slbSpindle, &SliderBox::valueUserChanged, this, &frmMain::onSlbSpindleValueUserChanged);
    connect(ui->slbSpindle, &SliderBox::valueChanged, this, &frmMain::onSlbSpindleValueChanged);

    // Setup serial port
    m_serialPort.setParity(QSerialPort::NoParity);
    m_serialPort.setDataBits(QSerialPort::Data8);
    m_serialPort.setFlowControl(QSerialPort::NoFlowControl);
    m_serialPort.setStopBits(QSerialPort::OneStop);

    if (m_settings->port() != "") {
        m_serialPort.setPortName(m_settings->port());
        m_serialPort.setBaudRate(m_settings->baud());
    }

    // Enable form actions
    QList<QAction*> noActions;
    noActions << ui->actJogXMinus << ui->actJogXPlus
              << ui->actJogYMinus << ui->actJogYPlus
              << ui->actJogZMinus << ui->actJogZPlus;
    foreach (QAction* a, findChildren<QAction*>()) if (!noActions.contains(a)) addAction(a);

    // Handle file drop
    if (qApp->arguments().count() > 1 && isGCodeFile(qApp->arguments().last())) {
        loadFile(qApp->arguments().last());
    }

    // TODO: remove global script engine and related features
    // Delegate vars to script engine
    QScriptValue vars = m_scriptEngine.newQObject(&m_storedVars);
    m_scriptEngine.globalObject().setProperty("vars", vars);

    // Delegate import extension function
    QScriptValue sv = m_scriptEngine.newObject();
    sv.setProperty("importExtension", m_scriptEngine.newFunction(frmMain::importExtension));
    m_scriptEngine.globalObject().setProperty("script", sv);
    m_scriptEngine.setObjectName("global");

    // Signals/slots
    connect(&m_serialPort, SIGNAL(readyRead()), this, SLOT(onSerialPortReadyRead()), Qt::QueuedConnection);
    connect(&m_serialPort, SIGNAL(error(QSerialPort::SerialPortError)), this, SLOT(onSerialPortError(QSerialPort::SerialPortError)));
    connect(&m_timerConnection, SIGNAL(timeout()), this, SLOT(onTimerConnection()));
    connect(&m_timerStateQuery, SIGNAL(timeout()), this, SLOT(onTimerStateQuery()));
    connect(&m_scriptEngine, &QScriptEngine::signalHandlerException, this, &frmMain::onScriptException);
    connect(ui->fraScript, &frmScript::ScriptStartClicked, this, &frmMain::onScriptStartClicked);

    // Event filter
    qApp->installEventFilter(this);

    // Start timers
    m_timerConnection.start(1000);
    m_timerStateQuery.start();
}

frmMain::~frmMain()
{
    qApp->removeEventFilter(this);

    delete m_senderErrorBox;
    delete ui;
}

void frmMain::showEvent(QShowEvent *se)
{
    Q_UNUSED(se)

    placeVisualizerButtons();

#ifdef WINDOWS
    if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
        if (m_taskBarButton == NULL) {
            m_taskBarButton = new QWinTaskbarButton(this);
            m_taskBarButton->setWindow(this->windowHandle());
            m_taskBarProgress = m_taskBarButton->progress();
        }
    }
#endif
}

void frmMain::hideEvent(QHideEvent *he)
{
    Q_UNUSED(he)
}

void frmMain::resizeEvent(QResizeEvent *re)
{
    Q_UNUSED(re)

    placeVisualizerButtons();
    resizeTableHeightMapSections();
}

void frmMain::timerEvent(QTimerEvent *te)
{
    if (te->timerId() == m_timerToolAnimation.timerId()) {
        m_toolDrawer.spin((m_spindleCW ? -40 : 40) * (double)(ui->slbSpindle->currentValue())
                            / (ui->slbSpindle->maximum()));
    } else {
        QMainWindow::timerEvent(te);
    }
}

void frmMain::closeEvent(QCloseEvent *ce)
{
    bool mode = m_heightMapMode;
    m_heightMapMode = false;

    if (!saveChanges(m_heightMapMode)) {
        ce->ignore();
        m_heightMapMode = mode;
        return;
    }

    if ((m_senderState != SenderStopped) &&
        QMessageBox::warning(this, this->windowTitle(), tr("File sending in progress. Terminate and exit?"),
        QMessageBox::Yes | QMessageBox::No) == QMessageBox::No)
    {
        ce->ignore();
        m_heightMapMode = mode;
        return;
    }

    m_timerConnection.stop();
    if (m_serialPort.isOpen()) m_serialPort.close();

    if (m_queue.length() > 0) {
        m_commands.clear();
        m_queue.clear();
    }

    saveSettings();
}

void frmMain::dragEnterEvent(QDragEnterEvent *dee)
{
    if (m_senderState != SenderStopped) return;

    if (dee->mimeData()->hasFormat("application/widget")) return;

    if (dee->mimeData()->hasFormat("text/plain") && !m_heightMapMode) dee->acceptProposedAction();
    else if (dee->mimeData()->hasFormat("text/uri-list") && dee->mimeData()->urls().count() == 1) {
        QString fileName = dee->mimeData()->urls().at(0).toLocalFile();

        if ((!m_heightMapMode && isGCodeFile(fileName))
        || (m_heightMapMode && isHeightmapFile(fileName)))
            dee->acceptProposedAction();
    }
}

void frmMain::dropEvent(QDropEvent *de)
{
    QString fileName = de->mimeData()->urls().at(0).toLocalFile();

    if (!m_heightMapMode) {
        if (!saveChanges(false)) return;

        // Load dropped g-code file
        if (!fileName.isEmpty()) {
            addRecentFile(fileName);
            updateRecentFilesMenu();
            loadFile(fileName);
        // Load dropped text
        } else {
            m_programFileName.clear();
            m_fileChanged = true;
            loadFile(de->mimeData()->text().split("\n"));
        }
    } else {
        if (!saveChanges(true)) return;

        // Load dropped heightmap file
        addRecentHeightmap(fileName);
        updateRecentFilesMenu();
        loadHeightMap(fileName);
    }
}

QMenu *frmMain::createPopupMenu()
{
    QMenu *menu = QMainWindow::createPopupMenu();

    foreach (QAction *a, menu->actions()) {
        if (a->text().contains("_spacer")) {
            a->setVisible(false);
        }
    }

    return menu;
}

void frmMain::on_actFileNew_triggered()
{
    if (!saveChanges(m_heightMapMode)) return;

    if (!m_heightMapMode) {
        newFile();
    } else {
        newHeightmap();
    }
}

void frmMain::on_actFileOpen_triggered()
{
    on_cmdFileOpen_clicked();
}

void frmMain::on_actFileReload_triggered()
{
    if (!m_heightMapMode) {
        if (!saveChanges(false)) return;
        if (m_programFileName != "") {
            loadFile(m_programFileName);
        }
    } else {
        if (!saveChanges(true)) return;
        if (m_heightMapFileName != "") {
            loadHeightMap(m_heightMapFileName);
        }
    }
}

void frmMain::on_actFileSave_triggered()
{
    if (!m_heightMapMode) {
        // G-code saving
        if (m_programFileName.isEmpty()) on_actFileSaveAs_triggered(); else {
            saveProgramToFile(m_programFileName, &m_programModel);
            m_fileChanged = false;
        }
    } else {
        // Height map saving
        if (m_heightMapFileName.isEmpty()) on_actFileSaveAs_triggered(); else saveHeightMap(m_heightMapFileName);
    }
}

void frmMain::on_actFileSaveAs_triggered()
{
    if (!m_heightMapMode) {
        QString fileName = (QFileDialog::getSaveFileName(this, tr("Save file as"), m_lastFolder, tr("G-Code files (*.nc *.ncc *.ngc *.tap *.txt *.gcode)")));

        if (!fileName.isEmpty()) if (saveProgramToFile(fileName, &m_programModel)) {
            m_programFileName = fileName;
            m_fileChanged = false;

            addRecentFile(fileName);
            updateRecentFilesMenu();

            updateControlsState();
        }
    } else {
        QString fileName = (QFileDialog::getSaveFileName(this, tr("Save file as"), m_lastFolder, tr("Heightmap files (*.map)")));

        if (!fileName.isEmpty()) if (saveHeightMap(fileName)) {
            ui->txtHeightMap->setText(fileName.mid(fileName.lastIndexOf("/") + 1));
            m_heightMapFileName = fileName;
            m_heightMapChanged = false;

            addRecentHeightmap(fileName);
            updateRecentFilesMenu();

            updateControlsState();
        }
    }
}

void frmMain::on_actFileSaveTransformedAs_triggered()
{
    QString fileName = (QFileDialog::getSaveFileName(this, tr("Save file as"), m_lastFolder, tr("G-Code files (*.nc *.ncc *.ngc *.tap *.txt *.gcode)")));

    if (!fileName.isEmpty()) {
        saveProgramToFile(fileName, &m_programHeightmapModel);
    }
}

void frmMain::on_actRecentClear_triggered()
{
    if (!m_heightMapMode) m_recentFiles.clear(); else m_recentHeightmaps.clear();
    updateRecentFilesMenu();
}

void frmMain::on_actFileExit_triggered()
{
    close();
}

void frmMain::on_actServiceSettings_triggered()
{
    m_settings->setShortcuts(findChildren<QAction*>(QRegExp("act.*")));

    emit settingsAboutToShow();

    if (m_settings->exec()) {
        applySettings();
        emit settingsAccepted();
    } else {
        m_settings->undo();
        emit settingsRejected();
    }
}

void frmMain::on_actHelpAbout_triggered()
{
    m_about->exec();
}

void frmMain::on_actHelpDocumentation_triggered()
{
    const QString docsFolder = "doc";
    const QString fallbackHelpFileName = docsFolder + "/help_en.html";

    QString helpFileName = docsFolder + "/help_" + (!m_settings->language().isEmpty() ? m_settings->language() : "en")
        + ".html";

    if (!QFile::exists(helpFileName)) {
        helpFileName = fallbackHelpFileName;
    }

    QDesktopServices::openUrl(QUrl::fromLocalFile(helpFileName));
}

void frmMain::on_actJogStepNext_triggered()
{
    ui->cboJogStep->setCurrentNext();
}

void frmMain::on_actJogStepPrevious_triggered()
{
    ui->cboJogStep->setCurrentPrevious();
}

void frmMain::on_actJogFeedNext_triggered()
{
    ui->cboJogFeed->setCurrentNext();
}

void frmMain::on_actJogFeedPrevious_triggered()
{
    ui->cboJogFeed->setCurrentPrevious();
}

void frmMain::on_actSpindleSpeedPlus_triggered()
{
    ui->slbSpindle->setSliderPosition(ui->slbSpindle->sliderPosition() + 1);
}

void frmMain::on_actSpindleSpeedMinus_triggered()
{
    ui->slbSpindle->setSliderPosition(ui->slbSpindle->sliderPosition() - 1);
}

void frmMain::on_actOverrideFeedPlus_triggered()
{
    ui->slbFeedOverride->setSliderPosition(ui->slbFeedOverride->sliderPosition() + 1);
}

void frmMain::on_actOverrideFeedMinus_triggered()
{
    ui->slbFeedOverride->setSliderPosition(ui->slbFeedOverride->sliderPosition() - 1);
}

void frmMain::on_actOverrideRapidPlus_triggered()
{
    ui->slbRapidOverride->setSliderPosition(ui->slbRapidOverride->sliderPosition() + 1);
}

void frmMain::on_actOverrideRapidMinus_triggered()
{
    ui->slbRapidOverride->setSliderPosition(ui->slbRapidOverride->sliderPosition() - 1);
}

void frmMain::on_actOverrideSpindlePlus_triggered()
{
    ui->slbSpindleOverride->setSliderPosition(ui->slbSpindleOverride->sliderPosition() + 1);
}

void frmMain::on_actOverrideSpindleMinus_triggered()
{
    ui->slbSpindleOverride->setSliderPosition(ui->slbSpindleOverride->sliderPosition() - 1);
}

void frmMain::on_actViewLockWindows_toggled(bool checked)
{
    QList<QDockWidget*> dl = findChildren<QDockWidget*>();

    foreach (QDockWidget *d, dl) {
        d->setFeatures(checked ? QDockWidget::NoDockWidgetFeatures : QDockWidget::AllDockWidgetFeatures);
    }
}

void frmMain::on_actServiceProfilesCreate_triggered()
{
    auto profileName = QInputDialog::getText(this, "", tr("Enter profile name"), QLineEdit::Normal, m_currentProfileName);

    if (profileName.isEmpty())
        return;

    // Save profile
    auto actions = m_profilesActionGroup->actions();
    auto it = std::find_if(actions.constBegin(), actions.constEnd(), [=](QAction *action) {
        return action->text() == profileName;
    });

    if (it != actions.constEnd()) {
        QMessageBox::critical(this, "", QString(tr("Profile '%1' already exists")).arg(profileName));
        return;
    } else {
        storeSettings();

        auto action = new QAction(profileName, m_profilesActionGroup);
        action->setData(SettingsProfileEntry { profileName, m_storage.save() });
        action->setCheckable(true);
        action->setChecked(true);

        auto menuActions = ui->mnuServiceProfiles->actions();
        auto separator = *std::find_if(menuActions.constBegin(), menuActions.constEnd(), [](QAction *action) { 
            return action->isSeparator();
        });

        m_profilesActionGroup->addAction(action);
        ui->mnuServiceProfiles->insertAction(separator, action);

        connect(action, &QAction::toggled, this, &frmMain::onActServiceProfilesSelected);
    }

    m_currentProfileName = profileName;
    ui->actServiceProfilesDelete->setEnabled(true);
}

void frmMain::on_actServiceProfilesDelete_triggered()
{
    auto actions = m_profilesActionGroup->actions();
    auto action = m_profilesActionGroup->checkedAction();

    if (action) {
        if (action == actions.first())
            return;

        m_profilesActionGroup->removeAction(action);
        ui->mnuServiceProfiles->removeAction(action);
    }

    actions.first()->setChecked(true);
}

void frmMain::on_cmdFileOpen_clicked()
{
    if (!m_heightMapMode) {
        if (!saveChanges(false)) return;

        QString fileName  = QFileDialog::getOpenFileName(this, tr("Open"), m_lastFolder,
                                   tr("G-Code files (*.nc *.ncc *.ngc *.tap *.txt *.gcode);;All files (*.*)"));

        if (!fileName.isEmpty()) m_lastFolder = fileName.left(fileName.lastIndexOf(QRegExp("[/\\\\]+")));

        if (fileName != "") {
            addRecentFile(fileName);
            updateRecentFilesMenu();

            loadFile(fileName);
        }
    } else {
        if (!saveChanges(true)) return;

        QString fileName = QFileDialog::getOpenFileName(this, tr("Open"), m_lastFolder, tr("Heightmap files (*.map)"));

        if (fileName != "") {
            addRecentHeightmap(fileName);
            updateRecentFilesMenu();
            loadHeightMap(fileName);
        }
    }
}

void frmMain::on_cmdFileSend_clicked()
{
    if (m_currentModel->rowCount() == 1) return;

    on_cmdFileReset_clicked();

    m_startTime.start();

    setSenderState(SenderTransferring);

    m_storedKeyboardControl = ui->chkKeyboardControl->isChecked();
    ui->chkKeyboardControl->setChecked(false);

    storeParserState();

#ifdef WINDOWS
    if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
        if (m_taskBarProgress) {
            m_taskBarProgress->setMaximum(m_currentModel->rowCount() - 2);
            m_taskBarProgress->setValue(0);
            m_taskBarProgress->show();
        }
    }
#endif

    updateControlsState();
    ui->cmdFilePause->setFocus();

    if (m_settings->useStartCommands()) sendCommands(m_settings->startCommands());
    sendNextFileCommands();
}

void frmMain::on_cmdFilePause_clicked(bool checked)
{
    static SenderState s;

    if (checked) {
        s = m_senderState;
        // setSenderState(SenderPaused);
        setSenderState(SenderPausing);
        ui->cmdFilePause->setEnabled(false);
    } else {
        if (m_senderState == SenderChangingTool) {
            setSenderState(SenderTransferring);
        } else {
            setSenderState(s);
        }
        updateControlsState();
    }
}

void frmMain::on_cmdFileAbort_clicked()
{
    ui->cmdFileAbort->setEnabled(false);

    if ((m_senderState == SenderPaused) || (m_senderState == SenderChangingTool)) {
        sendCommand("M2", -1, m_settings->showUICommands(), false);
    } else {
        sendCommand("M2", -1, m_settings->showUICommands(), true);
    }
}

void frmMain::on_cmdFileReset_clicked()
{
    m_fileCommandIndex = 0;
    m_fileProcessedCommandIndex = 0;
    m_lastDrawnLineIndex = 0;
    m_probeIndex = -1;

    if (!m_heightMapMode) {
        QList<LineSegment*> list = m_viewParser.getLineSegmentList();

        QList<int> indexes;
        for (int i = 0; i < list.count(); i++) {
            list[i]->setDrawn(false);
            indexes.append(i);
        }
        m_codeDrawer->update(indexes);

        ui->tblProgram->setUpdatesEnabled(false);

        for (int i = 0; i < m_currentModel->data().count() - 1; i++) {
            m_currentModel->data()[i].state = GCodeItem::InQueue;
            m_currentModel->data()[i].response = QString();
        }
        ui->tblProgram->setUpdatesEnabled(true);

        ui->tblProgram->scrollTo(m_currentModel->index(0, 0));
        ui->tblProgram->clearSelection();
        ui->tblProgram->selectRow(0);

        ui->glwVisualizer->setSpendTime(QTime(0, 0, 0));
    } else {
        ui->txtHeightMapGridX->setEnabled(true);
        ui->txtHeightMapGridY->setEnabled(true);
        ui->txtHeightMapGridZBottom->setEnabled(true);
        ui->txtHeightMapGridZTop->setEnabled(true);

        delete m_heightMapInterpolationDrawer.data();
        m_heightMapInterpolationDrawer.setData(NULL);

        m_heightMapModel.clear();
        updateHeightMapGrid();
    }
}

void frmMain::on_cmdCommandSend_clicked()
{
    QString command = ui->cboCommand->currentText();
    if (command.isEmpty()) return;

    QCoreApplication::sendEvent(ui->cboCommand, &QKeyEvent(QEvent::KeyPress, Qt::Key_Return, Qt::NoModifier));
}

void frmMain::on_cmdClearConsole_clicked()
{
    ui->txtConsole->clear();
}

void frmMain::on_cmdHome_clicked()
{
    m_homing = true;
    m_updateSpindleSpeed = true;
    sendCommand("$H", -1, m_settings->showUICommands());
}

void frmMain::on_cmdCheck_clicked(bool checked)
{
    if (checked) {
        storeParserState();
        sendCommand("$C", -1, m_settings->showUICommands());
    } else {
        m_aborting = true;
        grblReset();
    };
}

void frmMain::on_cmdReset_clicked()
{
    grblReset();
}

void frmMain::on_cmdUnlock_clicked()
{
    m_updateSpindleSpeed = true;
    sendCommand("$X", -1, m_settings->showUICommands());
}

void frmMain::on_cmdHold_clicked(bool checked)
{
    m_serialPort.write(QByteArray(1, checked ? (char)'!' : (char)'~'));
}

void frmMain::on_cmdSleep_clicked()
{
    sendCommand("$SLP", -1, m_settings->showUICommands());
}

void frmMain::on_cmdDoor_clicked()
{
    m_serialPort.write(QByteArray(1, (char)0x84));
}

void frmMain::on_cmdFlood_clicked()
{
    m_serialPort.write(QByteArray(1, (char)0xa0));
}

void frmMain::on_cmdSpindle_toggled(bool checked)
{
    ui->grpSpindle->setProperty("overrided", checked);
    style()->unpolish(ui->grpSpindle);
    ui->grpSpindle->ensurePolished();

    if (checked) {
        if (!ui->grpSpindle->isChecked()) ui->grpSpindle->setTitle(tr("Spindle") + QString(tr(" (%1)")).arg(ui->slbSpindle->value()));
    } else {
        ui->grpSpindle->setTitle(tr("Spindle"));
    }
}

void frmMain::on_cmdSpindle_clicked(bool checked)
{
    if (ui->cmdHold->isChecked()) {
        m_serialPort.write(QByteArray(1, char(0x9e)));
    } else {
        sendCommand(checked ? QString("M3 S%1").arg(ui->slbSpindle->value()) : "M5", -1, m_settings->showUICommands());
    }
}

void frmMain::on_cmdTop_clicked()
{
    ui->glwVisualizer->setTopView();
}

void frmMain::on_cmdFront_clicked()
{
    ui->glwVisualizer->setFrontView();
}

void frmMain::on_cmdLeft_clicked()
{
    ui->glwVisualizer->setLeftView();
}

void frmMain::on_cmdIsometric_clicked()
{
    ui->glwVisualizer->setIsometricView();
}

void frmMain::on_cmdFit_clicked()
{
    ui->glwVisualizer->fitDrawable(m_currentDrawer);
}

void frmMain::on_cmdPerspective_toggled()
{
    ui->glwVisualizer->setPerspective(ui->cmdPerspective->isChecked());
}

void frmMain::on_grpOverriding_toggled(bool checked)
{
    if (checked) {
        ui->grpOverriding->setTitle(tr("Overriding"));
    } else if (ui->slbFeedOverride->isChecked() | ui->slbRapidOverride->isChecked() | ui->slbSpindleOverride->isChecked()) {
        ui->grpOverriding->setTitle(tr("Overriding") + QString(tr(" (%1/%2/%3)"))
                                    .arg(ui->slbFeedOverride->isChecked() ? QString::number(ui->slbFeedOverride->value()) : "-")
                                    .arg(ui->slbRapidOverride->isChecked() ? QString::number(ui->slbRapidOverride->value()) : "-")
                                    .arg(ui->slbSpindleOverride->isChecked() ? QString::number(ui->slbSpindleOverride->value()) : "-"));
    }
    updateLayouts();

    ui->widgetFeed->setVisible(checked);
}

void frmMain::on_grpSpindle_toggled(bool checked)
{
    if (checked) {
        ui->grpSpindle->setTitle(tr("Spindle"));
    } else if (ui->cmdSpindle->isChecked()) {
//        ui->grpSpindle->setTitle(tr("Spindle") + QString(tr(" (%1)")).arg(ui->txtSpindleSpeed->text()));
        ui->grpSpindle->setTitle(tr("Spindle") + QString(tr(" (%1)")).arg(ui->slbSpindle->value()));
    }
    updateLayouts();

    ui->widgetSpindle->setVisible(checked);
}

void frmMain::on_grpJog_toggled(bool checked)
{
    updateJogTitle();
    updateLayouts();

    ui->widgetJog->setVisible(checked);
}

void frmMain::on_grpHeightMap_toggled(bool arg1)
{
    ui->widgetHeightMap->setVisible(arg1);
}

void frmMain::on_chkKeyboardControl_toggled(bool checked)
{
    ui->grpJog->setProperty("overrided", checked);
    style()->unpolish(ui->grpJog);
    ui->grpJog->ensurePolished();

    // Store/restore coordinate system
    if (checked) {
        sendCommand("$G", -2, m_settings->showUICommands());
    } else {
        if (m_absoluteCoordinates) sendCommand("G90", -1, m_settings->showUICommands());
    }

    if ((m_senderState != SenderTransferring) && (m_senderState != SenderStopping))
        m_storedKeyboardControl = checked;

    updateJogTitle();
    updateControlsState();
}

void frmMain::on_chkHeightMapBorderShow_toggled(bool checked)
{
    Q_UNUSED(checked)

    updateControlsState();
}

void frmMain::on_chkHeightMapOriginShow_toggled(bool checked)
{
    Q_UNUSED(checked)

    updateControlsState();
}

void frmMain::on_chkHeightMapInterpolationShow_toggled(bool checked)
{
    Q_UNUSED(checked)

    updateControlsState();
}

void frmMain::on_chkHeightMapUse_clicked(bool checked)
{
    ui->glwVisualizer->setUpdatesEnabled(false);

    // Reset table view
    QByteArray headerState = ui->tblProgram->horizontalHeader()->saveState();
    ui->tblProgram->setModel(NULL);

    CancelException cancel;

    if (checked) try {

        // Prepare progress dialog
        QProgressDialog progress(tr("Applying heightmap..."), tr("Abort"), 0, 0, this);
        progress.setWindowModality(Qt::WindowModal);
        progress.setFixedHeight(progress.sizeHint().height());
        progress.show();
        progress.setStyleSheet("QProgressBar {text-align: center; qproperty-format: \"\"}");

        // Set current model to prevent reseting heightmap cache
        m_currentModel = &m_programHeightmapModel;

        // Update heightmap-modificated program if not cached
        if (m_programHeightmapModel.rowCount() == 0) {

            // Modifying linesegments
            QList<LineSegment*> *list = m_viewParser.getLines();
            QRectF borderRect = borderRectFromTextboxes();
            double x, y, z;
            QVector3D point;

            progress.setLabelText(tr("Subdividing segments..."));
            progress.setMaximum(list->count() - 1);

            for (int i = 0; i < list->count(); i++) {
                if (!list->at(i)->isZMovement()) {
                    QList<LineSegment*> subSegments = subdivideSegment(list->at(i));

                    if (subSegments.count() > 0) {
                        delete list->at(i);
                        list->removeAt(i);
                        foreach (LineSegment* subSegment, subSegments) list->insert(i++, subSegment);
                        i--;
                    }
                }

                if (progress.isVisible() && (i % PROGRESSSTEP == 0)) {
                    progress.setMaximum(list->count() - 1);
                    progress.setValue(i);
                    qApp->processEvents();
                    if (progress.wasCanceled()) throw cancel;
                }
            }

            progress.setLabelText(tr("Updating Z-coordinates..."));
            progress.setMaximum(list->count() - 1);

            for (int i = 0; i < list->count(); i++) {
                if (i == 0) {
                    x = list->at(i)->getStart().x();
                    y = list->at(i)->getStart().y();
                    z = list->at(i)->getStart().z() + Interpolation::bicubicInterpolate(borderRect, &m_heightMapModel, x, y);
                    list->at(i)->setStart(QVector3D(x, y, z));
                } else list->at(i)->setStart(list->at(i - 1)->getEnd());

                x = list->at(i)->getEnd().x();
                y = list->at(i)->getEnd().y();
                z = list->at(i)->getEnd().z() + Interpolation::bicubicInterpolate(borderRect, &m_heightMapModel, x, y);
                list->at(i)->setEnd(QVector3D(x, y, z));

                if (progress.isVisible() && (i % PROGRESSSTEP == 0)) {
                    progress.setValue(i);
                    qApp->processEvents();
                    if (progress.wasCanceled()) throw cancel;
                }
            }

            progress.setLabelText(tr("Modifying G-code program..."));
            progress.setMaximum(m_programModel.rowCount() - 2);

            // Modifying g-code program
            QString command;
            QStringList args;
            int line;
            QString newCommand;
            GCodeItem item;
            int lastSegmentIndex = 0;
            int lastCommandIndex = -1;

            // Search strings
            QString coords("XxYyZzIiJjKkRr");
            QString g("Gg");
            QString m("Mm");

            char codeChar;          // Single code char G1 -> G
            float codeNum;          // Code number      G1 -> 1

            QString lastCode;
            bool isLinearMove;
            bool hasCommand;

            m_programLoading = true;
            for (int i = 0; i < m_programModel.rowCount() - 1; i++) {
                command = m_programModel.data().at(i).command;
                line = m_programModel.data().at(i).line;
                isLinearMove = false;
                hasCommand = false;

                if (line < 0 || line == lastCommandIndex || lastSegmentIndex == list->count() - 1) {
                    item.command = command;
                    m_programHeightmapModel.data().append(item);
                } else {
                    // Get commands args
                    args = m_programModel.data().at(i).args;
                    newCommand.clear();

                    // Prevent G53 commands from modification
                    if (args.contains("G53") || args.contains("g53")) {
                        newCommand = args.join("");
                        item.command = command;
                        m_programHeightmapModel.data().append(item);
                        continue;
                    }

                    // Parse command args
                    foreach (QString arg, args) {                   // arg examples: G1, G2, M3, X100...
                        codeChar = arg.at(0).toLatin1();            // codeChar: G, M, X...
                        if (!coords.contains(codeChar)) {           // Not parameter
                            codeNum = arg.mid(1).toDouble();
                            if (g.contains(codeChar)) {             // 'G'-command
                                // Store 'G0' & 'G1'
                                if (codeNum == 0.0f || codeNum == 1.0f) {
                                    lastCode = arg;
                                    isLinearMove = true;            // Store linear move
                                }

                                // Replace 'G2' & 'G3' with 'G1'
                                if (codeNum == 2.0f || codeNum == 3.0f) {
                                    newCommand.append("G1");
                                    isLinearMove = true;
                                // Drop plane command for arcs
                                } else if (codeNum != 17.0f && codeNum != 18.0f && codeNum != 19.0f) {
                                    newCommand.append(arg);
                                }

                                hasCommand = true;                  // Command has 'G'
                            } else {
                                if (m.contains(codeChar))
                                    hasCommand = true;              // Command has 'M'
                                newCommand.append(arg);       // Other commands
                            }
                        }
                    }

                    // Find first linesegment by command index
                    for (int j = lastSegmentIndex; j < list->count(); j++) {
                        if (list->at(j)->getLineNumber() == line) {
                            if (!qIsNaN(list->at(j)->getEnd().length()) && (isLinearMove || (!hasCommand && !lastCode.isEmpty()))) {
                                // Create new commands for each linesegment with given command index
                                while ((j < list->count()) && (list->at(j)->getLineNumber() == line)) {

                                    point = list->at(j)->getEnd();
                                    if (!list->at(j)->isAbsolute()) point -= list->at(j)->getStart();
                                    if (!list->at(j)->isMetric()) point /= 25.4f;

                                    item.command = newCommand + QString("X%1Y%2Z%3")
                                            .arg(point.x(), 0, 'f', 3).arg(point.y(), 0, 'f', 3).arg(point.z(), 0, 'f', 3);
                                    m_programHeightmapModel.data().append(item);

                                    if (!newCommand.isEmpty()) newCommand.clear();
                                    j++;
                                }
                            // Copy original command if not G0 or G1
                            } else {
                                item.command = command;
                                m_programHeightmapModel.data().append(item);
                            }

                            lastSegmentIndex = j;
                            break;
                        }
                    }
                }
                lastCommandIndex = line;

                if (progress.isVisible() && (i % PROGRESSSTEP == 0)) {
                    progress.setValue(i);
                    qApp->processEvents();
                    if (progress.wasCanceled()) throw cancel;
                }
            }
            m_programHeightmapModel.insertRow(m_programHeightmapModel.rowCount());
        }
        progress.close();

        ui->tblProgram->setModel(&m_programHeightmapModel);
        ui->tblProgram->horizontalHeader()->restoreState(headerState);

        connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));

        m_programLoading = false;

        // Update parser
        m_currentDrawer = m_codeDrawer;
        updateParser();

        // Select first row
        ui->tblProgram->selectRow(0);
    }
    catch (CancelException) {                       // Cancel modification
        m_programHeightmapModel.clear();
        m_currentModel = &m_programModel;

        ui->tblProgram->setModel(&m_programModel);
        ui->tblProgram->horizontalHeader()->restoreState(headerState);

        connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));
        ui->tblProgram->selectRow(0);

        ui->chkHeightMapUse->setChecked(false);

        return;
    } else {                                        // Restore original program
        m_currentModel = &m_programModel;

        ui->tblProgram->setModel(&m_programModel);
        ui->tblProgram->horizontalHeader()->restoreState(headerState);

        connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));

        // Store changes flag
        bool fileChanged = m_fileChanged;

        // Update parser
        updateParser();

        // Select first row
        ui->tblProgram->selectRow(0);

        // Restore changes flag
        m_fileChanged = fileChanged;
    }

    // Update groupbox title
    ui->grpHeightMap->setProperty("overrided", checked);
    style()->unpolish(ui->grpHeightMap);
    ui->grpHeightMap->ensurePolished();

    // Update menu
    ui->actFileSaveTransformedAs->setVisible(checked);

    ui->glwVisualizer->setUpdatesEnabled(!isMinimized() && ui->dockVisualizer->isVisible());
}

void frmMain::on_chkHeightMapGridShow_toggled(bool checked)
{
    Q_UNUSED(checked)

    updateControlsState();
}

void frmMain::on_txtHeightMapBorderX_valueChanged(double arg1)
{
    updateHeightMapBorderDrawer();
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapBorderWidth_valueChanged(double arg1)
{
    updateHeightMapBorderDrawer();
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapBorderY_valueChanged(double arg1)
{
    updateHeightMapBorderDrawer();
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapBorderHeight_valueChanged(double arg1)
{
    updateHeightMapBorderDrawer();
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapOriginX_valueChanged(double arg1)
{
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapOriginY_valueChanged(double arg1)
{
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapGridX_valueChanged(double arg1)
{
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapGridY_valueChanged(double arg1)
{
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapGridZBottom_valueChanged(double arg1)
{
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapGridZTop_valueChanged(double arg1)
{
    updateHeightMapGrid(arg1);
}

void frmMain::on_txtHeightMapInterpolationStepX_valueChanged(double arg1)
{
    Q_UNUSED(arg1)

    updateHeightMapInterpolationDrawer();
}

void frmMain::on_txtHeightMapInterpolationStepY_valueChanged(double arg1)
{
    Q_UNUSED(arg1)

    updateHeightMapInterpolationDrawer();
}

void frmMain::on_cmdHeightMapMode_toggled(bool checked)
{
    // Update flag
    m_heightMapMode = checked;

    // Reset file progress
    m_fileCommandIndex = 0;
    m_fileProcessedCommandIndex = 0;
    m_lastDrawnLineIndex = 0;

    // Reset/restore g-code program modification on edit mode enter/exit
    if (ui->chkHeightMapUse->isChecked()) {
        on_chkHeightMapUse_clicked(!checked); // Update gcode program parser
    }

    if (checked) {
        ui->tblProgram->selectRow(0);
        ui->tblProgram->setModel(&m_probeModel);
        resizeTableHeightMapSections();
        m_currentModel = &m_probeModel;
        m_currentDrawer = m_probeDrawer;
        updateParser();  // Update probe program parser
    } else {
        m_probeParser.reset();
        if (!ui->chkHeightMapUse->isChecked()) {
            m_currentModel = &m_programModel;
            m_currentDrawer = m_codeDrawer;

            ui->tblProgram->setModel(&m_programModel);
            connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this,
                SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));
            ui->tblProgram->selectRow(0);

            ui->glwVisualizer->updateModelBounds(m_codeDrawer);
            updateProgramEstimatedTime(m_currentDrawer->viewParser()->getLineSegmentList());
        }
    }

    // Shadow toolpath
    QList<LineSegment*> list = m_viewParser.getLineSegmentList();
    QList<int> indexes;
    for (int i = m_lastDrawnLineIndex; i < list.count(); i++) {
        list[i]->setDrawn(checked);
        list[i]->setIsHightlight(false);
        indexes.append(i);
    }
    // Update only vertex color.
    // If chkHeightMapUse was checked codeDrawer updated via updateParser
    if (!ui->chkHeightMapUse->isChecked()) m_codeDrawer->update(indexes);

    updateRecentFilesMenu();
    updateControlsState();
}

void frmMain::on_cmdHeightMapCreate_clicked()
{
    ui->cmdHeightMapMode->setChecked(true);
    on_actFileNew_triggered();
}

void frmMain::on_cmdHeightMapLoad_clicked()
{
    if (!saveChanges(true)) {
        return;
    }

    QString fileName = QFileDialog::getOpenFileName(this, tr("Open"), m_lastFolder, tr("Heightmap files (*.map)"));

    if (fileName != "") {
        addRecentHeightmap(fileName);
        loadHeightMap(fileName);

        // If using heightmap
        if (ui->chkHeightMapUse->isChecked() && !m_heightMapMode) {
            // Restore original file
            on_chkHeightMapUse_clicked(false);
            // Apply heightmap
            on_chkHeightMapUse_clicked(true);
        }

        updateRecentFilesMenu();
        updateControlsState(); // Enable 'cmdHeightMapMode' button
    }
}

void frmMain::on_cmdHeightMapOrigin_clicked()
{
    sendCommand(QString("G21G90G0X%1Y%2").arg(ui->txtHeightMapOriginX->value()).arg(ui->txtHeightMapOriginY->value()));
}

void frmMain::on_cmdHeightMapBorderAuto_clicked()
{
    QRectF rect = borderRectFromExtremes();

    if (!qIsNaN(rect.width()) && !qIsNaN(rect.height())) {
        ui->txtHeightMapBorderX->setValue(rect.x());
        ui->txtHeightMapBorderY->setValue(rect.y());
        ui->txtHeightMapBorderWidth->setValue(rect.width());
        ui->txtHeightMapBorderHeight->setValue(rect.height());
    }
}

void frmMain::on_cmdHeightMapOriginTool_clicked()
{
    ui->txtHeightMapOriginX->setValue(ui->txtWPosX->value());
    ui->txtHeightMapOriginY->setValue(ui->txtWPosY->value());
}

void frmMain::on_cmdYPlus_pressed()
{
    m_jogVector += QVector4D(0, 1, 0, 0);
    jogStep();
}

void frmMain::on_cmdYPlus_released()
{
    m_jogVector -= QVector4D(0, 1, 0, 0);
    jogStep();
}

void frmMain::on_cmdYMinus_pressed()
{
    m_jogVector += QVector4D(0, -1, 0, 0);
    jogStep();
}

void frmMain::on_cmdYMinus_released()
{
    m_jogVector -= QVector4D(0, -1, 0, 0);
    jogStep();
}

void frmMain::on_cmdXPlus_pressed()
{
    m_jogVector += QVector4D(1, 0, 0, 0);
    jogStep();
}

void frmMain::on_cmdXPlus_released()
{
    m_jogVector -= QVector4D(1, 0, 0, 0);
    jogStep();
}

void frmMain::on_cmdXMinus_pressed()
{
    m_jogVector += QVector4D(-1, 0, 0, 0);
    jogStep();
}

void frmMain::on_cmdXMinus_released()
{
    m_jogVector -= QVector4D(-1, 0, 0, 0);
    jogStep();
}

void frmMain::on_cmdZPlus_pressed()
{
    m_jogVector += QVector4D(0, 0, 1, 0);
    jogStep();
}

void frmMain::on_cmdZPlus_released()
{
    m_jogVector -= QVector4D(0, 0, 1, 0);
    jogStep();
}

void frmMain::on_cmdZMinus_pressed()
{
    m_jogVector += QVector4D(0, 0, -1, 0);
    jogStep();
}

void frmMain::on_cmdZMinus_released()
{
    m_jogVector -= QVector4D(0, 0, -1, 0);
    jogStep();
}

void frmMain::on_cmdAMinus_pressed()
{
    if (!m_settings->axisAEnabled() || !ui->cmdAMinus->isVisible())
        return;

    m_jogVector += QVector4D(0, 0, 0, -1);
    jogStep();
}

void frmMain::on_cmdAMinus_released()
{
    // Always clear the pressed direction, even if the axis was hidden or
    // disabled while the mouse button was held.
    m_jogVector -= QVector4D(0, 0, 0, -1);
    jogStep();
}

void frmMain::on_cmdAPlusX_pressed()
{
    if (!m_settings->axisAEnabled() || !ui->cmdAPlusX->isVisible())
        return;

    m_jogVector += QVector4D(0, 0, 0, 1);
    jogStep();
}

void frmMain::on_cmdAPlusX_released()
{
    m_jogVector -= QVector4D(0, 0, 0, 1);
    jogStep();
}

void frmMain::on_cmdAPlusY_pressed()
{
    if (!m_settings->axisAEnabled() || !ui->cmdAPlusY->isVisible())
        return;

    m_jogVector += QVector4D(0, 0, 0, 1);
    jogStep();
}

void frmMain::on_cmdAPlusY_released()
{
    m_jogVector -= QVector4D(0, 0, 0, 1);
    jogStep();
}

// Rotary axis B shares the normal jog pipeline so press/release works for
// both incremental and continuous jogging.
void frmMain::on_cmdBMinus_pressed()
{
    if (!ui->cmdBMinus->isVisible() || !m_settings->axisBEnabled()) return;
    m_jogB -= 1.0;
    jogStep();
}

void frmMain::on_cmdBMinus_released()
{
    m_jogB += 1.0;
    jogStep();
}

void frmMain::on_cmdBPlus_pressed()
{
    if (!ui->cmdBPlus->isVisible() || !m_settings->axisBEnabled()) return;
    m_jogB += 1.0;
    jogStep();
}

void frmMain::on_cmdBPlus_released()
{
    m_jogB -= 1.0;
    jogStep();
}

void frmMain::on_cmdStop_clicked()
{
    m_jogVector = QVector4D(0, 0, 0, 0);
    m_jogB = 0.0;
    m_lastContinuousJogVector = QVector4D(0, 0, 0, 0);
    m_lastContinuousJogB = 0.0;
    m_queue.clear();
    m_serialPort.write(QByteArray(1, char(0x85)));
}

void frmMain::on_tblProgram_customContextMenuRequested(const QPoint &pos)
{
    if (m_senderState != SenderStopped) return;

    if (ui->tblProgram->selectionModel()->selectedRows().count() > 0) {
        m_tableMenu->actions().at(0)->setEnabled(true);
        m_tableMenu->actions().at(1)->setEnabled(ui->tblProgram->selectionModel()->selectedRows()[0].row() != m_currentModel->rowCount() - 1);
    } else {
        m_tableMenu->actions().at(0)->setEnabled(false);
        m_tableMenu->actions().at(1)->setEnabled(false);
    }
    m_tableMenu->popup(ui->tblProgram->viewport()->mapToGlobal(pos));
}

void frmMain::on_mnuViewWindows_aboutToShow()
{
    QAction *a;
    QList<QAction*> al;

    foreach (QDockWidget *d, findChildren<QDockWidget*>()) {
        a = new QAction(d->windowTitle(), ui->mnuViewWindows);
        a->setCheckable(true);
        a->setChecked(d->isVisible());
        connect(a, &QAction::triggered, d, &QDockWidget::setVisible);
        al.append(a);
    }

    qSort(al.begin(), al.end(), frmMain::actionTextLessThan);

    ui->mnuViewWindows->clear();
    ui->mnuViewWindows->addActions(al);
}

void frmMain::on_mnuViewPanels_aboutToShow()
{
    QAction *a;

    ui->mnuViewPanels->clear();

    QStringList panels;
    if (ui->scrollContentsDevice->isVisible()) panels << ui->scrollContentsDevice->saveState();
    if (ui->scrollContentsModification->isVisible()) panels << "\n" << ui->scrollContentsModification->saveState();
    if (ui->scrollContentsUser->isVisible()) panels << "\n" << ui->scrollContentsUser->saveState();

    foreach (QString s, panels) {
        if (s == "\n") {
            ui->mnuViewPanels->addSeparator();
        } else {
            QGroupBox *b = findChild<QGroupBox*>(s);
            if (b) {
                a = ui->mnuViewPanels->addAction(b->title());
                a->setCheckable(true);
                a->setChecked(b->isVisible());
                connect(a, &QAction::triggered, b, &QWidget::setVisible);
            }
        }
    }
}

void frmMain::on_dockVisualizer_visibilityChanged(bool visible)
{
    ui->glwVisualizer->setUpdatesEnabled(visible);
}

void frmMain::onSerialPortReadyRead()
{
    while (m_serialPort.canReadLine()) {
        QString data = m_serialPort.readLine().trimmed();
        // Serial devices may occasionally deliver an empty line. Do not index
        // data[0] until a non-empty status/response line is available.
        if (data.isEmpty()) continue;

        // Filter prereset responses
        if (m_reseting) {
            if (!dataIsReset(data)) continue;
            else {
                m_reseting = false;
                m_timerStateQuery.setInterval(m_settings->queryStateTime());
            }
        }

        // Status response
        if (data[0] == '<') {
            DeviceState state = DeviceUnknown;

            m_statusReceived = true;

            // Update machine coordinates
            // Capture X/Y/Z plus optional rotary axes A/B. The previous
            // expression used a repeated capture group and silently lost B.
            static QRegExp mpx("MPos:([^,]*),([^,]*),([^,>|]*)(?:,([^,>|]*))?(?:,([^,>|]*))?");
            if (mpx.indexIn(data) != -1) {
                bool xOk = false, yOk = false, zOk = false;
                const double x = mpx.cap(1).toDouble(&xOk);
                const double y = mpx.cap(2).toDouble(&yOk);
                const double z = mpx.cap(3).toDouble(&zOk);
                // Validate each axis independently. A malformed XYZ field
                // must not prevent a valid A or B value from being retained.
                if (xOk && qIsFinite(x)) ui->txtMPosX->setValue(x);
                if (yOk && qIsFinite(y)) ui->txtMPosY->setValue(y);
                if (zOk && qIsFinite(z)) ui->txtMPosZ->setValue(z);

                // FluidNC can omit optional rotary fields. Update each rotary
                // coordinate only when its own value is present and valid.
                if (!mpx.cap(4).isEmpty()) {
                    bool aOk = false;
                    const double a = mpx.cap(4).toDouble(&aOk);
                    if (aOk && qIsFinite(a)) {
                        if (ui->txtMPosA->minimum() > a || ui->txtMPosA->maximum() < a) {
                            ui->txtMPosA->setMaximum(ui->txtMPosA->maximum() * 10);
                            ui->txtMPosA->setMinimum(-ui->txtMPosA->maximum());
                        }
                        ui->txtMPosA->setValue(a);
                    }
                }
                if (!mpx.cap(5).isEmpty()) {
                    bool bOk = false;
                    const double b = mpx.cap(5).toDouble(&bOk);
                    if (bOk && qIsFinite(b)) {
                        if (ui->txtMPosB->minimum() > b || ui->txtMPosB->maximum() < b) {
                            ui->txtMPosB->setMaximum(ui->txtMPosB->maximum() * 10);
                            ui->txtMPosB->setMinimum(-ui->txtMPosB->maximum());
                        }
                        ui->txtMPosB->setValue(b);
                    }
                }

                m_scriptApp->device()->setMachineCoordinates(ui->txtMPosX->value(), ui->txtMPosY->value(),
                    ui->txtMPosZ->value(), ui->txtMPosA->value(), ui->txtMPosB->value());

                // TODO: remove
                // Update stored vars
                m_storedVars.setCoords("M", QVector3D(
                    ui->txtMPosX->value(),
                    ui->txtMPosY->value(),
                    ui->txtMPosZ->value()));
            }

            // Status
            static QRegExp stx("<([^,^>^|]*)");
            if (stx.indexIn(data) != -1) {
                state = m_deviceStatuses.key(stx.cap(1), DeviceUnknown);

                // Update status
                if (state != m_deviceState) {
                    ui->txtStatus->setText(m_statusCaptions[state]);
                    ui->txtStatus->setStyleSheet(QString("background-color: %1; color: %2;")
                                                 .arg(m_statusBackColors[state]).arg(m_statusForeColors[state]));
                }

                // Update controls
                ui->cmdCheck->setEnabled(state != DeviceRun && (m_senderState == SenderStopped));
                ui->cmdCheck->setChecked(state == DeviceCheck);
                ui->cmdHold->setChecked(state == DeviceHold0 || state == DeviceHold1 || state == DeviceQueue);
                ui->cmdSpindle->setEnabled(state == DeviceHold0 || ((m_senderState != SenderTransferring) &&
                    (m_senderState != SenderStopping)));

                // Update "elapsed time" timer
                if ((m_senderState == SenderTransferring) || (m_senderState == SenderStopping)) {
                    QTime time(0, 0, 0);
                    int elapsed = m_startTime.elapsed();
                    ui->glwVisualizer->setSpendTime(time.addMSecs(elapsed));
                }

                // Test for job complete
                if ((m_senderState == SenderStopping) &&
                        ((state == DeviceIdle && m_deviceState == DeviceRun) || state == DeviceCheck))
                {
                    completeTransfer();
                }

                // Abort
                static double x = qQNaN();
                static double y = qQNaN();
                static double z = qQNaN();

                if (m_aborting) {
                    switch (state) {
                        case DeviceIdle: // Idle
                            if ((m_senderState == SenderStopped) && m_resetCompleted) {
                                m_aborting = false;
                                restoreParserState();
                                restoreOffsets();
                                return;
                            }
                            break;
                        case DeviceHold0: // Hold
                        case DeviceHold1:
                        case DeviceQueue:
                            if (!m_reseting && compareCoordinates(x, y, z)) {
                                x = qQNaN();
                                y = qQNaN();
                                z = qQNaN();
                                grblReset();
                            }
                            else {
                                x = ui->txtMPosX->value();
                                y = ui->txtMPosY->value();
                                z = ui->txtMPosZ->value();
                            }
                            break;
                        default:
                            break;
                    }
                }
            }

            // Store work offset
            static QVector4D workOffset;
            static double workOffsetB = 0.0;
            static QRegExp wpx("WCO:([^,]*),([^,]*),([^,>|]*)(?:,([^,>|]*))?(?:,([^,>|]*))?");

            if (wpx.indexIn(data) != -1)
            {
                // Keep each offset independently. A missing or malformed
                // component must not block valid updates for the other axes.
                bool xOk = false, yOk = false, zOk = false;
                const double x = wpx.cap(1).toDouble(&xOk);
                const double y = wpx.cap(2).toDouble(&yOk);
                const double z = wpx.cap(3).toDouble(&zOk);
                if (xOk && qIsFinite(x)) workOffset.setX(x);
                if (yOk && qIsFinite(y)) workOffset.setY(y);
                if (zOk && qIsFinite(z)) workOffset.setZ(z);

                if (!wpx.cap(4).isEmpty()) {
                    bool aOk = false;
                    const double a = wpx.cap(4).toDouble(&aOk);
                    if (aOk && qIsFinite(a)) workOffset.setW(a);
                }
                if (!wpx.cap(5).isEmpty()) {
                    bool bOk = false;
                    const double b = wpx.cap(5).toDouble(&bOk);
                    if (bOk && qIsFinite(b)) workOffsetB = b;
                }

                m_machineBoundsDrawer.setTranslation(
                    -QVector3D(toMetric(workOffset.x()), toMetric(workOffset.y()), toMetric(workOffset.z())));
            }

            // Update work coordinates
            ui->txtWPosX->setValue(ui->txtMPosX->value() - workOffset.x());
            ui->txtWPosY->setValue(ui->txtMPosY->value() - workOffset.y());
            ui->txtWPosZ->setValue(ui->txtMPosZ->value() - workOffset.z());

            double a = ui->txtMPosA->value() - workOffset.w();
            if (ui->txtWPosA->minimum() > a || ui->txtWPosA->maximum() < a) {
                ui->txtWPosA->setMaximum(ui->txtWPosA->maximum() * 10);
                ui->txtWPosA->setMinimum(-ui->txtWPosA->maximum());
            }
            ui->txtWPosA->setValue(a);

            double b = ui->txtMPosB->value() - workOffsetB;
            if (ui->txtMPosB->minimum() > b || ui->txtMPosB->maximum() < b) {
                ui->txtMPosB->setMaximum(ui->txtMPosB->maximum() * 10);
                ui->txtMPosB->setMinimum(-ui->txtMPosB->maximum());
            }
            if (ui->txtWPosB->minimum() > b || ui->txtWPosB->maximum() < b) {
                ui->txtWPosB->setMaximum(ui->txtWPosB->maximum() * 10);
                ui->txtWPosB->setMinimum(-ui->txtWPosB->maximum());
            }
            ui->txtWPosB->setValue(b);

            // Phase 13: show the independent live A/B angular positions in the
            // preview pivot indicators. This is visualization only; it sends
            // no commands and does not alter the G-code or machine coordinates.
            m_rotaryPivotDrawer.setAngles(ui->txtWPosA->value(), ui->txtWPosB->value());

            // Phase 25: display live work coordinates and transfer progress.
            // This monitor is informational only and never sends controller commands.
            {
                const int totalRows = qMax(0, m_currentModel ? m_currentModel->rowCount() : 0);
                const int completedRows = qBound(0, m_fileProcessedCommandIndex, totalRows);
                const int progress = totalRows > 0 ? (completedRows * 100 / totalRows) : 0;
                m_axisMonitorLabel->setText(
                    tr("X: %1  Y: %2  Z: %3  A: %4°  B: %5°  Progress: %6%")
                        .arg(ui->txtWPosX->value(), 0, 'f', 2)
                        .arg(ui->txtWPosY->value(), 0, 'f', 2)
                        .arg(ui->txtWPosZ->value(), 0, 'f', 2)
                        .arg(ui->txtWPosA->value(), 0, 'f', 2)
                        .arg(ui->txtWPosB->value(), 0, 'f', 2)
                        .arg(progress));
            }

            m_scriptApp->device()->setWorkCoordinates(ui->txtWPosX->value(), ui->txtWPosY->value(),
                ui->txtWPosZ->value(), ui->txtWPosA->value(), ui->txtWPosB->value());

            // TODO: remove
            // Update stored vars
            m_storedVars.setCoords("W", QVector3D(
                    ui->txtWPosX->value(),
                    ui->txtWPosY->value(),
                    ui->txtWPosZ->value()));

            // Update tool position
            QVector3D toolPosition;
            if (!(state == DeviceCheck && m_fileProcessedCommandIndex < m_currentModel->rowCount() - 1))
            {
                toolPosition = QVector3D(toMetric(ui->txtWPosX->value()),
                                         toMetric(ui->txtWPosY->value()),
                                         toMetric(ui->txtWPosZ->value()));

                auto normalizedRotation = Util::normalizeRotation(ui->txtWPosA->value());

                const QVector3D previewToolPosition =
                    m_codeDrawer->getIgnoreZ() ? QVector3D(toolPosition.x(), toolPosition.y(), 0) : toolPosition;
                m_toolDrawer.setToolPosition(previewToolPosition);
                m_rotaryPivotDrawer.setToolPosition(previewToolPosition);

                if (m_settings->axisAEnabled() && m_currentDrawer->viewParser()->axisRotationUsed(GcodeViewParse::RotationAxisA)) {
                    m_codeDrawer->setRotation(
                        normalizedRotation,
                        Util::rotationVector(m_settings->axisAX() ? Util::RotationVectorX : Util::RotationVectorY)
                    );
                } else {
                    m_codeDrawer->setRotation(
                        0,
                        Util::rotationVector(m_settings->axisAX() ? Util::RotationVectorX : Util::RotationVectorY)
                    );
                }
                m_selectionDrawer.setRotation(m_codeDrawer->rotation());
            }

            // Toolpath shadowing
            if (((m_senderState == SenderTransferring) || (m_senderState == SenderStopping)
                || (m_senderState == SenderPausing) || (m_senderState == SenderPaused)) && state != DeviceCheck) {
                GcodeViewParse *parser = m_currentDrawer->viewParser();

                bool toolOntoolpath = false;

                QList<int> drawnLines;
                QList<LineSegment*> list = parser->getLineSegmentList();

                for (int i = m_lastDrawnLineIndex; i < list.count()
                     && list.at(i)->getLineNumber()
                     <= (m_currentModel->data(m_currentModel->index(m_fileProcessedCommandIndex, 4)).toInt() + 1); i++) {
                    if (list.at(i)->contains(m_codeDrawer->rotation().transposed() * toolPosition)) {
                        toolOntoolpath = true;
                        m_lastDrawnLineIndex = i;
                        break;
                    }
                    drawnLines << i;
                }

                if (toolOntoolpath) {
                    foreach (int i, drawnLines) {
                        list.at(i)->setDrawn(true);
                    }
                    if (!drawnLines.isEmpty()) {
                        m_currentDrawer->update(drawnLines);
                        // Refresh the preview progress colors from the parser's
                        // updated drawn flags while a job is running.
                        m_rotaryPivotDrawer.setToolpath(list);
                    }
                }
                else if (m_lastDrawnLineIndex < list.count() && m_lastDrawnLineIndex > 0)
                {
                    qWarning(generalLogCategory)
                    << QString("Tool not on toolpath. Last drawn line index: %1, model line: %2, processed index: %3")
                        .arg(list.at(m_lastDrawnLineIndex)->getLineNumber())
                        .arg(m_currentModel->data(m_currentModel->index(m_fileProcessedCommandIndex, 4)).toInt())
                        .arg(m_fileProcessedCommandIndex);
                }
            }

            // Get overridings
            static QRegExp ov("Ov:([^,]*),([^,]*),([^,^>^|]*)");
            if (ov.indexIn(data) != -1)
            {
                updateOverride(ui->slbFeedOverride, ov.cap(1).toInt(), '\x91');
                updateOverride(ui->slbSpindleOverride, ov.cap(3).toInt(), '\x9a');

                int rapid = ov.cap(2).toInt();
                ui->slbRapidOverride->setCurrentValue(rapid);

                int target = ui->slbRapidOverride->isChecked() ? ui->slbRapidOverride->value() : 100;

                if (rapid != target) switch (target) {
                case 25:
                    m_serialPort.write(QByteArray(1, char(0x97)));
                    break;
                case 50:
                    m_serialPort.write(QByteArray(1, char(0x96)));
                    break;
                case 100:
                    m_serialPort.write(QByteArray(1, char(0x95)));
                    break;
                }

                // Update pins state
                QString pinState;
                static QRegExp pn("Pn:([^|^>]*)");
                if (pn.indexIn(data) != -1) {
                    pinState.append(QString(tr("PS: %1")).arg(pn.cap(1)));
                }

                // Process spindle state
                static QRegExp as("A:([^,^>^|]+)");
                if (as.indexIn(data) != -1) {
                    QString q = as.cap(1);
                    ui->cmdFlood->setChecked(q.contains("F"));

                    if (!pinState.isEmpty()) pinState.append(" / ");
                    pinState.append(QString(tr("AS: %1")).arg(as.cap(1)));
                }
                ui->glwVisualizer->setPinState(pinState);
            }

            // Get feed/spindle values
            static QRegExp fs("FS:([^,]*),([^,^|^>]*)");
            if (fs.indexIn(data) != -1) {
                auto spindleSpeed = fs.cap(2);
                if (spindleSpeed != "0") {
                    if ((!m_timerToolAnimation.isActive())) {
                        m_timerToolAnimation.start(25, this);
                        ui->cmdSpindle->setChecked(true);
                    }
                } else if (m_timerToolAnimation.isActive()) {
                    m_timerToolAnimation.stop();
                    ui->cmdSpindle->setChecked(false);
                }
                ui->glwVisualizer->setSpeedState((QString(tr("F/S: %1 / %2")).arg(fs.cap(1)).arg(spindleSpeed)));
            }

            // Store device state
            setDeviceState(state);

            // Update continuous jog
            jogContinuous();

            // Emit status signal
            emit statusReceived(data);

        // Command response
        } else if (data.length() > 0) {

            if (m_commands.length() > 0 && !dataIsFloating(data)
                    && !(m_commands[0].command != "[CTRL+X]" && dataIsReset(data))) {

                static QString response; // Full response string

                if ((m_commands[0].command != "[CTRL+X]" && dataIsEnd(data))
                        || (m_commands[0].command == "[CTRL+X]" && dataIsReset(data))) {

                    response.append(data);

                    // Take command from buffer
                    CommandAttributes ca = m_commands.takeFirst();
                    QTextBlock tb = ui->txtConsole->document()->findBlockByNumber(ca.consoleIndex);
                    QTextCursor tc(tb);

                    QString uncomment = GcodePreprocessorUtils::removeComment(ca.command).toUpper();

                    // TODO: remove/rework
                    // Store current coordinate system
                    if (uncomment == "$G") {
                        static QRegExp g("G5[4-9]");
                        if (g.indexIn(response) != -1) {
                            m_storedVars.setCS(g.cap(0));
                        }
                        static QRegExp t("T(\\d+)(?!\\d)");
                        if (t.indexIn(response) != -1) {
                            m_storedVars.setTool(g.cap(1).toInt());
                        }
                    }

                    // TODO: Store firmware version, features, buffer size on $I command
                    // [VER:1.1d.20161014:Some string]
                    // [OPT:VL,15,128]

                    // Restore absolute/relative coordinate system after jog
                    if (uncomment == "$G" && ca.tableIndex == -2) {
                        if (ui->chkKeyboardControl->isChecked()) m_absoluteCoordinates = response.contains("G90");
                        else if (response.contains("G90")) sendCommand("G90", -1, m_settings->showUICommands());
                    }

                    // Process parser status
                    if (uncomment == "$G" && ca.tableIndex == -3) {
                        // Update status in visualizer window
                        ui->glwVisualizer->setParserStatus(response.left(response.indexOf("; ")));

                        // Store parser status
                        if ((m_senderState == SenderTransferring) || (m_senderState == SenderStopping)) storeParserState();

                        // Spindle speed
                        QRegExp rx(".*S([\\d\\.]+)");
                        if (rx.indexIn(response) != -1) {
                            double speed = rx.cap(1).toDouble();
                            ui->slbSpindle->setCurrentValue(speed);
                        }
                        m_spindleCW = !response.contains("M4");

                        m_updateParserStatus = true;
                    }

                    // Offsets
                    if (uncomment == "$#") storeOffsetsVars(response);

                    // Settings response
                    if (uncomment == "$$" && ca.tableIndex == -2) {
                        static QRegExp gs("\\$(\\d+)\\=([^;]+)\\; ");
                        QMap<int, double> set;
                        int p = 0;
                        while ((p = gs.indexIn(response, p)) != -1) {
                            set[gs.cap(1).toInt()] = gs.cap(2).toDouble();
                            p += gs.matchedLength();
                        }
                        if (set.keys().contains(13)) m_settings->setUnits(set[13]);
                        if (set.keys().contains(20)) m_settings->setSoftLimitsEnabled(set[20]);
                        if (set.keys().contains(22)) {
                            m_settings->setHomingEnabled(set[22]);
                            m_machineBoundsDrawer.setVisible(set[22]);
                        }
                        if (set.keys().contains(110)) m_settings->setRapidSpeed(set[110]);
                        if (set.keys().contains(120)) m_settings->setAcceleration(set[120]);
                        if (set.keys().contains(130) && set.keys().contains(131) && set.keys().contains(132)) {
                            m_settings->setMachineBounds(QVector3D(
                                m_settings->referenceXPlus() ? -set[130] : set[130],
                                m_settings->referenceYPlus() ? -set[131] : set[131],
                                m_settings->referenceZPlus() ? -set[132] : set[132]));
                            m_machineBoundsDrawer.setBorderRect(QRectF(0, 0,
                                m_settings->referenceXPlus() ? -set[130] : set[130],
                                m_settings->referenceYPlus() ? -set[131] : set[131]));
                        }

                        setupCoordsTextboxes();
                    }

                    // Homing response
                    if ((uncomment == "$H" || uncomment == "$T") && m_homing) m_homing = false;

                    // Reset complete response
                    if (uncomment == "[CTRL+X]") {
                        m_resetCompleted = true;
                        m_updateParserStatus = true;

                        // Query grbl settings
                        sendCommand("$$", -2, false);
                        sendCommand("$#", -2, false, true);
                    }

                    // Clear command buffer on "M2" & "M30" command (old firmwares)
                    static QRegExp M230("(M0*2|M30)(?!\\d)");
                    if (uncomment.contains(M230) && response.contains("ok") && !response.contains("Pgm End")) {
                        m_commands.clear();
                        m_queue.clear();
                    }

                    // Update probe coords on user commands
                    if (uncomment.contains("G38.2") && ca.tableIndex < 0) {
                        static QRegExp PRB(".*PRB:([^,]*),([^,]*),([^,:]*)(?:,([^,:]*))*");
                        if (PRB.indexIn(response) != -1) {
                            m_scriptApp->device()->setProbeCoordinates(PRB.cap(1).toDouble(), PRB.cap(2).toDouble(),
                                PRB.cap(3).toDouble(), PRB.cap(4).toDouble());

                            // TODO: remove
                            m_storedVars.setCoords("PRB", QVector3D(
                                PRB.cap(1).toDouble(),
                                PRB.cap(2).toDouble(),
                                PRB.cap(3).toDouble()
                            ));
                        }
                    }

                    // Process probing on heightmap mode only from table commands
                    if (uncomment.contains("G38.2") && m_heightMapMode && ca.tableIndex > -1) {
                        // Get probe Z coordinate
                        // "[PRB:0.000,0.000,0.000:0];ok"
                        // "[PRB:0.000,0.000,0.000,0.000:0];ok"
                        QRegExp rx(".*PRB:([^,]*),([^,]*),([^,:]*)");
                        double z = qQNaN();
                        if (rx.indexIn(response) != -1) {
                            z = toMetric(rx.cap(3).toDouble());
                        }

                        static double firstZ;
                        if (m_probeIndex == -1) {
                            firstZ = z;
                            z = 0;
                        } else {
                            // Calculate delta Z
                            z -= firstZ;

                            // Calculate table indexes
                            int row = (m_probeIndex / m_heightMapModel.columnCount());
                            int column = m_probeIndex - row * m_heightMapModel.columnCount();
                            if (row % 2) column = m_heightMapModel.columnCount() - 1 - column;

                            // Store Z in table
                            m_heightMapModel.setData(m_heightMapModel.index(row, column), z, Qt::UserRole);
                            ui->tblHeightMap->update(m_heightMapModel.index(m_heightMapModel.rowCount() - 1 - row, column));
                            updateHeightMapInterpolationDrawer();
                        }

                        m_probeIndex++;
                    }

                    // Change state query time on check mode on
                    if (uncomment.contains(QRegExp("$[cC]"))) {
                        m_timerStateQuery.setInterval(response.contains("Enable") ? 1000 : m_settings->queryStateTime());
                    }

                    // Add response to console
                    if (tb.isValid() && tb.text() == ca.command) {

                        bool scrolledDown = ui->txtConsole->verticalScrollBar()->value()
                            == ui->txtConsole->verticalScrollBar()->maximum();

                        // Update text block numbers
                        int blocksAdded = response.count("; ");

                        if (blocksAdded > 0) for (int i = 0; i < m_commands.count(); i++) {
                            if (m_commands[i].consoleIndex != -1) m_commands[i].consoleIndex += blocksAdded;
                        }

                        tc.beginEditBlock();
                        tc.movePosition(QTextCursor::EndOfBlock);

                        tc.insertText(" < " + QString(response).replace("; ", "\r\n"));
                        tc.endEditBlock();

                        if (scrolledDown) ui->txtConsole->verticalScrollBar()->setValue(
                            ui->txtConsole->verticalScrollBar()->maximum());
                    }

                    // Check queue
                    static bool processingQueue = false;
                    if (m_queue.length() > 0 && !processingQueue) {
                        processingQueue = true;
                        while (m_queue.length() > 0) {
                            CommandQueue cq = m_queue.takeFirst();
                            SendCommandResult r = sendCommand(cq.command, cq.tableIndex, cq.showInConsole);
                            if (r == SendDone) {
                                break;
                            } else if (r == SendQueue) {
                                m_queue.prepend(m_queue.takeLast());
                                break;
                            }
                        }
                        processingQueue = false;
                    }

                    // Add response to table, send next program commands
                    if (m_senderState != SenderStopped) {
                        // Only if command from table
                        if (ca.tableIndex > -1) {
                            m_currentModel->setData(m_currentModel->index(ca.tableIndex, 2), GCodeItem::Processed);
                            m_currentModel->setData(m_currentModel->index(ca.tableIndex, 3), response);

                            m_fileProcessedCommandIndex = ca.tableIndex;

                            if (ui->chkAutoScroll->isChecked() && ca.tableIndex != -1) {
                                scrollToTableIndex(m_currentModel->index(ca.tableIndex + 1, 0));
                            }
                        }

                        // Update taskbar progress
#ifdef WINDOWS
                        if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
                            if (m_taskBarProgress) m_taskBarProgress->setValue(m_fileProcessedCommandIndex);
                        }
#endif
                        // Process error messages
                        static bool holding = false;
                        static QString errors;

                        if (ca.tableIndex > -1 && response.toUpper().contains("ERROR") && !m_settings->ignoreErrors()) {
                            errors.append(QString::number(ca.tableIndex + 1) + ": " + ca.command
                                          + " < " + response + "\n");

                            m_senderErrorBox->setText(tr("Error message(s) received:\n") + errors);

                            if (!holding) {
                                holding = true;         // Hold transmit while messagebox is visible
                                response.clear();

                                m_serialPort.write("!");
                                m_senderErrorBox->checkBox()->setChecked(false);
                                qApp->beep();
                                int result = m_senderErrorBox->exec();

                                holding = false;
                                errors.clear();
                                if (m_senderErrorBox->checkBox()->isChecked()) m_settings->setIgnoreErrors(true);
                                if (result == QMessageBox::Ignore) {
                                    m_serialPort.write("~");
                                } else {
                                    grblReset();
                                }
                            }
                        }

                        // Check transfer complete (last row always blank, last command row = rowcount - 2)
                        if ((m_fileProcessedCommandIndex == m_currentModel->rowCount() - 2) ||
                            uncomment.contains(QRegExp("(M0*2|M30)(?!\\d)")))
                        {
                            if (m_deviceState == DeviceRun) {
                                setSenderState(SenderStopping);
                            } else {
                                completeTransfer();
                            }
                        } else if ((m_fileCommandIndex < m_currentModel->rowCount())
                            && (m_senderState == SenderTransferring)
                            && !holding)
                        {
                            // Send next program commands
                            sendNextFileCommands();
                        }
                    }

                    // Tool change mode
                    static QRegExp M6("(M0*6)(?!\\d)");
                    if ((m_senderState == SenderPausing) && uncomment.contains(M6)) {

                        response.clear();

                        if (m_settings->toolChangePause()) {
                            QMessageBox::information(this, qApp->applicationDisplayName(),
                                tr("Change tool and press 'Pause' button to continue job"));
                        }

                        if (m_settings->toolChangeUseCommands()) {
                            if (m_settings->toolChangeUseCommandsConfirm()) {
                                QMessageBox box(this);
                                box.setIcon(QMessageBox::Information);
                                box.setText(tr("M6 command detected. Send tool change commands?\n"));
                                box.setWindowTitle(qApp->applicationDisplayName());
                                box.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
                                box.setCheckBox(new QCheckBox(tr("Don't show again")));
                                int res = box.exec();
                                if (box.checkBox()->isChecked()) m_settings->setToolChangeUseCommandsConfirm(false);
                                if (res == QMessageBox::Yes) {
                                    sendCommands(m_settings->toolChangeCommands());
                                }
                            } else {
                                sendCommands(m_settings->toolChangeCommands());
                            }
                        }

                        setSenderState(SenderChangingTool);
                        updateControlsState();
                    }
                    if ((m_senderState == SenderChangingTool) && !m_settings->toolChangePause()
                        && m_commands.isEmpty())
                    {
                        setSenderState(SenderTransferring);
                    }

                    // Switch to pause mode
                    if ((m_senderState == SenderPausing) && m_commands.isEmpty()) {
                        setSenderState(SenderPaused);
                        updateControlsState();
                    }

                    // Scroll to first line on "M30" command
                    if (uncomment.contains("M30")) ui->tblProgram->setCurrentIndex(m_currentModel->index(0, 1));

                    // Toolpath shadowing on check mode
                    if (m_deviceState == DeviceCheck) {
                        GcodeViewParse *parser = m_currentDrawer->viewParser();
                        QList<LineSegment*> list = parser->getLineSegmentList();

                        if ((m_senderState != SenderStopping) && m_fileProcessedCommandIndex < m_currentModel->rowCount() - 1) {
                            int i;
                            QList<int> drawnLines;

                            for (i = m_lastDrawnLineIndex; i < list.count()
                                 && list.at(i)->getLineNumber()
                                 <= (m_currentModel->data(m_currentModel->index(m_fileProcessedCommandIndex, 4)).toInt()); i++) {
                                drawnLines << i;
                            }

                            if (!drawnLines.isEmpty() && (i < list.count())) {
                                m_lastDrawnLineIndex = i;
                                QVector3D vec = list.at(i)->getEnd();
                                m_toolDrawer.setToolPosition(vec);
                                m_rotaryPivotDrawer.setToolPosition(vec);
                            }

                            foreach (int i, drawnLines) {
                                list.at(i)->setDrawn(true);
                            }
                            if (!drawnLines.isEmpty()) m_currentDrawer->update(drawnLines);
                        } else {
                            foreach (LineSegment* s, list) {
                                if (!qIsNaN(s->getEnd().length())) {
                                    m_toolDrawer.setToolPosition(s->getEnd());
                                    m_rotaryPivotDrawer.setToolPosition(s->getEnd());
                                    break;
                                }
                            }
                        }
                    }

                    // Emit response signal
                    emit responseReceived(ca.command, ca.tableIndex, response);

                    response.clear();
                } else {
                    response.append(data + "; ");
                }

            } else {
                // Unprocessed responses
                // Handle hardware reset
                if (dataIsReset(data)) {
                    setSenderState(SenderStopped);
                    setDeviceState(DeviceUnknown);

                    m_fileCommandIndex = 0;

                    m_reseting = false;
                    m_homing = false;

                    m_updateParserStatus = true;
                    m_statusReceived = true;

                    m_commands.clear();
                    m_queue.clear();

                    updateControlsState();
                }
                ui->txtConsole->appendPlainText(data);
            }
        } else {
            // Blank response
        }
    }
}

void frmMain::onSerialPortError(QSerialPort::SerialPortError error)
{
    static QSerialPort::SerialPortError previousError;

    if (error != QSerialPort::NoError && error != previousError) {
        previousError = error;
        ui->txtConsole->appendPlainText(tr("Serial port error ") + QString::number(error) + ": " + m_serialPort.errorString());
        if (m_serialPort.isOpen()) {
            m_serialPort.close();
            updateControlsState();
        }
    }
}

void frmMain::onTimerConnection()
{
    if (!m_serialPort.isOpen()) {
        openPort();
    } else if (!m_homing/* && !m_reseting*/ && !ui->cmdHold->isChecked() && m_queue.length() == 0) {
        if (m_updateSpindleSpeed) {
            m_updateSpindleSpeed = false;
            sendCommand(QString("S%1").arg(ui->slbSpindle->value()), -2, m_settings->showUICommands());
        }
        if (m_updateParserStatus) {
            m_updateParserStatus = false;
            sendCommand("$G", -3, false);
        }
    }
}

void frmMain::onTimerStateQuery()
{
    if (m_serialPort.isOpen() && m_resetCompleted && m_statusReceived) {
        m_serialPort.write(QByteArray(1, '?'));
        m_statusReceived = false;
    }

    ui->glwVisualizer->setBufferState(QString(tr("Buffer: %1 / %2 / %3")).arg(bufferLength()).arg(m_commands.length()).arg(m_queue.length()));
}

void frmMain::onTableInsertLine()
{
    if (ui->tblProgram->selectionModel()->selectedRows().count() == 0 ||
        (m_senderState == SenderTransferring) || (m_senderState == SenderStopping)) return;

    int row = ui->tblProgram->selectionModel()->selectedRows()[0].row();

    m_currentModel->insertRow(row);
    m_currentModel->setData(m_currentModel->index(row, 2), GCodeItem::InQueue);

    updateParser();

    ui->tblProgram->selectRow(row);
}

void frmMain::onTableDeleteLines()
{
    if (ui->tblProgram->selectionModel()->selectedRows().count() == 0 ||
        (m_senderState == SenderTransferring) || (m_senderState == SenderStopping) ||
        QMessageBox::warning(this, this->windowTitle(), tr("Delete lines?"), QMessageBox::Yes | QMessageBox::No) == QMessageBox::No) return;

    QModelIndex firstRow = ui->tblProgram->selectionModel()->selectedRows()[0];
    int rowsCount = ui->tblProgram->selectionModel()->selectedRows().count();
    if (ui->tblProgram->selectionModel()->selectedRows().last().row() == m_currentModel->rowCount() - 1) rowsCount--;

    if (firstRow.row() != m_currentModel->rowCount() - 1) {
        m_currentModel->removeRows(firstRow.row(), rowsCount);
    } else return;

    // Drop heightmap cache
    if (m_currentModel == &m_programModel) m_programHeightmapModel.clear();

    updateParser();

    ui->tblProgram->selectRow(firstRow.row());
}

void frmMain::onTableCellChanged(QModelIndex i1, QModelIndex i2)
{
    Q_UNUSED(i2)

    GCodeTableModel *model = (GCodeTableModel*)sender();

    if (i1.column() != 1) return;
    // Inserting new line at end
    if (i1.row() == (model->rowCount() - 1) && model->data(model->index(i1.row(), 1)).toString() != "") {
        model->setData(model->index(model->rowCount() - 1, 2), GCodeItem::InQueue);
        model->insertRow(model->rowCount());
        if (!m_programLoading) ui->tblProgram->setCurrentIndex(model->index(i1.row() + 1, 1));
    }

    if (!m_programLoading) {

        // Clear cached args
        model->setData(model->index(i1.row(), 5), QVariant());

        // Drop heightmap cache
        if (m_currentModel == &m_programModel) m_programHeightmapModel.clear();

        // Update visualizer
        updateParser();

        // Hightlight w/o current cell changed event (double hightlight on current cell changed)
        QList<LineSegment*> list = m_viewParser.getLineSegmentList();
        for (int i = 0; i < list.count() && list[i]->getLineNumber() <= m_currentModel->data(m_currentModel->index(i1.row(), 4)).toInt(); i++) {
            list[i]->setIsHightlight(true);
        }
    }
}

void frmMain::onTableCurrentChanged(QModelIndex idx1, QModelIndex idx2)
{
    // A model can be replaced while the table is empty or has no current row.
    // Keep the inspector and selection marker safe during file/model transitions.
    if (!m_currentModel || !m_currentDrawer || m_currentModel->rowCount() < 2
            || !idx1.isValid() || idx1.row() < 0) {
        if (m_rotarySegmentInfoLabel) {
            m_rotarySegmentInfoLabel->setText(tr("Select a G-code row to inspect its XYZAB movement."));
        }
        if (m_rotarySegmentCopyButton) m_rotarySegmentCopyButton->setEnabled(false);
        m_selectionDrawer.setVisible(false);
        return;
    }

    // Update toolpath hightlighting
    if (idx1.row() > m_currentModel->rowCount() - 2) idx1 = m_currentModel->index(m_currentModel->rowCount() - 2, 0);
    if (!idx2.isValid() || idx2.row() < 0 || idx2.row() > m_currentModel->rowCount() - 2) idx2 = idx1;

    GcodeViewParse *parser = m_currentDrawer->viewParser();
    QList<LineSegment*> list = parser->getLineSegmentList();
    QVector<QList<int>> lineIndexes = parser->getLinesIndexes();

    // Phase 48: highlight all drawable segments belonging to every selected
    // source row. Extended row selection lets the operator inspect a complete
    // group of XYZAB moves at once. The current row remains the inspector's
    // reference row; additional selected rows only extend the visual highlight.
    // This is read-only and never changes parser or controller state.
    QList<int> selectionUpdates;
    for (int i = 0; i < list.count(); ++i) {
        if (list.at(i) && list.at(i)->isSelected()) {
            list.at(i)->setIsSelected(false);
            selectionUpdates.append(i);
        }
    }

    QList<int> selectedRows;
    if (ui->tblProgram->selectionModel()) {
        const QModelIndexList rows = ui->tblProgram->selectionModel()->selectedRows();
        for (const QModelIndex &rowIndex : rows) {
            if (rowIndex.isValid() && rowIndex.row() >= 0
                    && rowIndex.row() < m_currentModel->rowCount() - 1
                    && !selectedRows.contains(rowIndex.row())) {
                selectedRows.append(rowIndex.row());
            }
        }
    }
    if (selectedRows.isEmpty()) selectedRows.append(idx1.row());

    for (int row : selectedRows) {
        const int sourceLine = m_currentModel->data(m_currentModel->index(row, 4)).toInt();
        if (sourceLine < 0 || sourceLine >= lineIndexes.count()) continue;
        const QList<int> candidates = lineIndexes.at(sourceLine);
        for (int segmentIndex : candidates) {
            if (segmentIndex < 0 || segmentIndex >= list.count() || !list.at(segmentIndex)) continue;
            list.at(segmentIndex)->setIsSelected(true);
            selectionUpdates.append(segmentIndex);
        }
    }
    if (!selectionUpdates.isEmpty()) {
        // Remove duplicate indices before updating GPU vertex colors.
        std::sort(selectionUpdates.begin(), selectionUpdates.end());
        selectionUpdates.erase(std::unique(selectionUpdates.begin(), selectionUpdates.end()), selectionUpdates.end());
        m_currentDrawer->update(selectionUpdates);
    }

    // Update linesegments on cell changed
    if (!m_currentDrawer->geometryUpdated()) {
        for (int i = 0; i < list.count(); i++) {
            list.at(i)->setIsHightlight(list.at(i)->getLineNumber() <= m_currentModel->data(m_currentModel->index(idx1.row(), 4)).toInt());
        }
    // Update vertices on current cell changed
    } else {

        int lineFirst = m_currentModel->data(m_currentModel->index(idx1.row(), 4)).toInt();
        int lineLast = m_currentModel->data(m_currentModel->index(idx2.row(), 4)).toInt();
        if (lineLast < lineFirst) qSwap(lineLast, lineFirst);

        QList<int> indexes;
        for (int i = qMax(0, lineFirst + 1); i <= lineLast && i < lineIndexes.count(); i++) {
            foreach (int l, lineIndexes.at(i)) {
                if (l < 0 || l >= list.count() || !list.at(l)) continue;
                list.at(l)->setIsHightlight(idx1.row() > idx2.row());
                indexes.append(l);
            }
        }

        if (!indexes.isEmpty()) m_currentDrawer->update(indexes);
    }

    // Phase 41: show parsed start/end coordinates for the selected G-code line.
    // A is stored in axes*.x() and B in axes*.y(); XYZ comes from the preview path.
    int line = m_currentModel->data(m_currentModel->index(idx1.row(), 4)).toInt();
    if (m_rotarySegmentInfoLabel) {
        QString details = tr("Line %1: no drawable movement found.").arg(line);
        if (line >= 0 && line < lineIndexes.count() && !lineIndexes.at(line).isEmpty()) {
            const QList<int> segmentIndexes = lineIndexes.at(line);
            int firstIndex = -1;
            int lastIndex = -1;
            for (int segmentIndex : segmentIndexes) {
                if (segmentIndex >= 0 && segmentIndex < list.count() && list.at(segmentIndex)) {
                    if (firstIndex < 0) firstIndex = segmentIndex;
                    lastIndex = segmentIndex;
                }
            }
            if (firstIndex >= 0 && lastIndex >= 0) {
                const LineSegment *firstSegment = list.at(firstIndex);
                const LineSegment *lastSegment = list.at(lastIndex);
                // modelStart/modelEnd preserve the original programmed XYZ.
                // getStart/getEnd are transformed for the 3D rotary preview.
                const QVector3D start = firstSegment->modelStart();
                const QVector3D end = lastSegment->modelEnd();
                const QVector3D rotaryStart = firstSegment->axesStart();
                const QVector3D rotaryEnd = lastSegment->axesEnd();
                const bool movedA = qIsFinite(double(rotaryStart.x())) && qIsFinite(double(rotaryEnd.x()))
                        && qAbs(double(rotaryEnd.x()) - double(rotaryStart.x())) > 0.00001;
                const bool movedB = qIsFinite(double(rotaryStart.y())) && qIsFinite(double(rotaryEnd.y()))
                        && qAbs(double(rotaryEnd.y()) - double(rotaryStart.y())) > 0.00001;
                const auto value = [](double coordinate) {
                    return qIsFinite(coordinate) ? QString::number(coordinate, 'f', 3) : QStringLiteral("--");
                };
                QString movementType;
                if (firstSegment->isArc()) {
                    movementType = firstSegment->isClockwise() ? QStringLiteral("G2") : QStringLiteral("G3");
                } else {
                    movementType = firstSegment->isFastTraverse() ? QStringLiteral("G0") : QStringLiteral("G1");
                }
                if (movedA && movedB) movementType += QStringLiteral(" + A+B");
                else if (movedA) movementType += QStringLiteral(" + A");
                else if (movedB) movementType += QStringLiteral(" + B");
                details = tr("Line %1  |  %2\nStart: X %3  Y %4  Z %5  A %6°  B %7°\nEnd:   X %8  Y %9  Z %10  A %11°  B %12°")
                        .arg(line).arg(movementType)
                        .arg(value(start.x())).arg(value(start.y())).arg(value(start.z()))
                        .arg(value(rotaryStart.x())).arg(value(rotaryStart.y()))
                        .arg(value(end.x())).arg(value(end.y())).arg(value(end.z()))
                        .arg(value(rotaryEnd.x())).arg(value(rotaryEnd.y()));
            }
        }
        // Phase 49: append a read-only summary for the complete multi-row
        // selection. Rows are sorted into program order so the net XYZAB
        // displacement runs from the first selected move to the last one.
        QList<int> summaryRows = selectedRows;
        std::sort(summaryRows.begin(), summaryRows.end());
        int selectedSegmentCount = 0;
        double totalXyzPath = 0.0;
        double totalAPath = 0.0;
        double totalBPath = 0.0;
        bool hasXyzPath = true;
        bool hasAPath = true;
        bool hasBPath = true;
        QList<int> countedSegmentIndexes;
        const LineSegment *aggregateFirst = nullptr;
        const LineSegment *aggregateLast = nullptr;
        for (int selectedRow : summaryRows) {
            if (selectedRow < 0 || selectedRow >= m_currentModel->rowCount() - 1) continue;
            const int sourceLine = m_currentModel->data(m_currentModel->index(selectedRow, 4)).toInt();
            if (sourceLine < 0 || sourceLine >= lineIndexes.count()) continue;
            for (int segmentIndex : lineIndexes.at(sourceLine)) {
                if (segmentIndex < 0 || segmentIndex >= list.count() || !list.at(segmentIndex)
                        || countedSegmentIndexes.contains(segmentIndex)) continue;
                countedSegmentIndexes.append(segmentIndex);
                const LineSegment *segment = list.at(segmentIndex);
                ++selectedSegmentCount;
                if (!aggregateFirst) aggregateFirst = segment;
                aggregateLast = segment;

                // Sum each parsed sub-segment rather than measuring only the
                // endpoints. Arc tessellation therefore contributes its
                // successive chord lengths, and rotary travel is accumulated
                // independently in degrees (never mixed with XYZ units).
                const QVector3D xyzDelta = segment->modelEnd() - segment->modelStart();
                const double xyzLength = double(xyzDelta.length());
                if (qIsFinite(xyzLength)) totalXyzPath += xyzLength;
                else hasXyzPath = false;

                const QVector3D axesDelta = segment->axesEnd() - segment->axesStart();
                const double aTravel = qAbs(double(axesDelta.x()));
                const double bTravel = qAbs(double(axesDelta.y()));
                if (qIsFinite(aTravel)) totalAPath += aTravel;
                else hasAPath = false;
                if (qIsFinite(bTravel)) totalBPath += bTravel;
                else hasBPath = false;
            }
        }
        if (summaryRows.size() > 1) {
            details += tr("\n\nSelection: %1 G-code rows  |  %2 drawable segments")
                    .arg(summaryRows.size()).arg(selectedSegmentCount);
            if (aggregateFirst && aggregateLast) {
                const QVector3D start = aggregateFirst->modelStart();
                const QVector3D end = aggregateLast->modelEnd();
                const QVector3D rotaryStart = aggregateFirst->axesStart();
                const QVector3D rotaryEnd = aggregateLast->axesEnd();
                const auto delta = [](double a, double b) {
                    return qIsFinite(a) && qIsFinite(b)
                            ? QString::number(b - a, 'f', 3) : QStringLiteral("--");
                };
                details += tr("\nNet change: ΔX %1  ΔY %2  ΔZ %3  ΔA %4°  ΔB %5°")
                        .arg(delta(start.x(), end.x()))
                        .arg(delta(start.y(), end.y()))
                        .arg(delta(start.z(), end.z()))
                        .arg(delta(rotaryStart.x(), rotaryEnd.x()))
                        .arg(delta(rotaryStart.y(), rotaryEnd.y()));
                const auto total = [](bool valid, double amount) {
                    return valid && qIsFinite(amount)
                            ? QString::number(amount, 'f', 3) : QStringLiteral("--");
                };
                details += tr("\nTravelled path: XYZ %1 coordinate units  |  A %2°  |  B %3°")
                        .arg(total(hasXyzPath, totalXyzPath))
                        .arg(total(hasAPath, totalAPath))
                        .arg(total(hasBPath, totalBPath));
                details += tr("\nXYZ path length follows parsed segments; arc length is approximated by their preview chords.");
            }
        }

        // Phase 51: advisory XYZ travel-envelope inspection. The preview path
        // is in work coordinates, so translate it by the currently reported
        // machine/work offset before comparing it with the configured XYZ
        // travel extents. Rotary travel limits are not exposed by Candle's
        // existing $130-$132 settings model and are deliberately not guessed.
        if (selectedSegmentCount > 0) {
            const QVector3D configuredBounds = m_settings->machineBounds();
            const double workOffsetX = toMetric(ui->txtMPosX->value() - ui->txtWPosX->value());
            const double workOffsetY = toMetric(ui->txtMPosY->value() - ui->txtWPosY->value());
            const double workOffsetZ = toMetric(ui->txtMPosZ->value() - ui->txtWPosZ->value());
            const double bounds[3] = {
                toMetric(configuredBounds.x()),
                toMetric(configuredBounds.y()),
                toMetric(configuredBounds.z())
            };
            const double offsets[3] = { workOffsetX, workOffsetY, workOffsetZ };
            const char *axisNames[3] = { "X", "Y", "Z" };
            bool axisKnown[3] = { true, true, true };
            bool axisOutside[3] = { false, false, false };
            int outsideSegmentCount = 0;
            const double toleranceMm = 0.001;

            for (int axis = 0; axis < 3; ++axis) {
                axisKnown[axis] = qIsFinite(bounds[axis]) && qAbs(bounds[axis]) > toleranceMm
                        && qIsFinite(offsets[axis]);
            }

            for (int segmentIndex : countedSegmentIndexes) {
                if (segmentIndex < 0 || segmentIndex >= list.count() || !list.at(segmentIndex)) continue;
                const LineSegment *segment = list.at(segmentIndex);
                const QVector3D points[2] = { segment->modelStart(), segment->modelEnd() };
                bool segmentOutside = false;
                for (int pointIndex = 0; pointIndex < 2; ++pointIndex) {
                    const double coordinates[3] = {
                        double(points[pointIndex].x()) + workOffsetX,
                        double(points[pointIndex].y()) + workOffsetY,
                        double(points[pointIndex].z()) + workOffsetZ
                    };
                    for (int axis = 0; axis < 3; ++axis) {
                        if (!axisKnown[axis] || !qIsFinite(coordinates[axis])) continue;
                        const double minimum = qMin(0.0, bounds[axis]);
                        const double maximum = qMax(0.0, bounds[axis]);
                        if (coordinates[axis] < minimum - toleranceMm
                                || coordinates[axis] > maximum + toleranceMm) {
                            axisOutside[axis] = true;
                            segmentOutside = true;
                        }
                    }
                }
                if (segmentOutside) ++outsideSegmentCount;
            }

            QStringList checkedAxes;
            QStringList outsideAxes;
            for (int axis = 0; axis < 3; ++axis) {
                if (axisKnown[axis]) checkedAxes.append(QString::fromLatin1(axisNames[axis]));
                if (axisOutside[axis]) outsideAxes.append(QString::fromLatin1(axisNames[axis]));
            }
            if (checkedAxes.isEmpty()) {
                details += tr("\nXYZ travel check: unavailable (machine travel extents not loaded).");
            } else if (outsideAxes.isEmpty()) {
                details += tr("\nXYZ travel check: no preview point outside the known %1 envelope.")
                        .arg(checkedAxes.join(QStringLiteral("/")));
            } else {
                details += tr("\nWARNING: preview exceeds configured %1 travel envelope on %2 (%3 segments).")
                        .arg(checkedAxes.join(QStringLiteral("/")))
                        .arg(outsideAxes.join(QStringLiteral("/")))
                        .arg(outsideSegmentCount);
            }
            // Angular limits are independent per rotary axis and opt-in. Never
            // infer them from XYZ travel or from a generic +/-360 degree range.
            int outsideA = 0;
            int outsideB = 0;
            bool validALimits = m_checkRotaryALimits && m_checkRotaryALimits->isChecked()
                    && m_rotaryAMinLimit && m_rotaryAMaxLimit
                    && qIsFinite(m_rotaryAMinLimit->value()) && qIsFinite(m_rotaryAMaxLimit->value())
                    && m_rotaryAMinLimit->value() < m_rotaryAMaxLimit->value();
            bool validBLimits = m_checkRotaryBLimits && m_checkRotaryBLimits->isChecked()
                    && m_rotaryBMinLimit && m_rotaryBMaxLimit
                    && qIsFinite(m_rotaryBMinLimit->value()) && qIsFinite(m_rotaryBMaxLimit->value())
                    && m_rotaryBMinLimit->value() < m_rotaryBMaxLimit->value();
            for (int segmentIndex : countedSegmentIndexes) {
                if (segmentIndex < 0 || segmentIndex >= list.count() || !list.at(segmentIndex)) continue;
                const LineSegment *segment = list.at(segmentIndex);
                const double aValues[2] = { double(segment->axesStart().x()), double(segment->axesEnd().x()) };
                const double bValues[2] = { double(segment->axesStart().y()), double(segment->axesEnd().y()) };
                if (validALimits && ( !qIsFinite(aValues[0]) || !qIsFinite(aValues[1])
                        || qMin(aValues[0], aValues[1]) < m_rotaryAMinLimit->value() - 0.001
                        || qMax(aValues[0], aValues[1]) > m_rotaryAMaxLimit->value() + 0.001)) ++outsideA;
                if (validBLimits && ( !qIsFinite(bValues[0]) || !qIsFinite(bValues[1])
                        || qMin(bValues[0], bValues[1]) < m_rotaryBMinLimit->value() - 0.001
                        || qMax(bValues[0], bValues[1]) > m_rotaryBMaxLimit->value() + 0.001)) ++outsideB;
            }
            if (validALimits) {
                details += outsideA == 0
                        ? tr("\nA travel check: within configured range [%1°, %2°].")
                            .arg(m_rotaryAMinLimit->value(), 0, 'f', 3).arg(m_rotaryAMaxLimit->value(), 0, 'f', 3)
                        : tr("\nWARNING: A exceeds configured range [%1°, %2°] on %3 segments.")
                            .arg(m_rotaryAMinLimit->value(), 0, 'f', 3).arg(m_rotaryAMaxLimit->value(), 0, 'f', 3).arg(outsideA);
            } else {
                details += tr("\nA travel check: not enabled or invalid limits.");
            }
            if (validBLimits) {
                details += outsideB == 0
                        ? tr("\nB travel check: within configured range [%1°, %2°].")
                            .arg(m_rotaryBMinLimit->value(), 0, 'f', 3).arg(m_rotaryBMaxLimit->value(), 0, 'f', 3)
                        : tr("\nWARNING: B exceeds configured range [%1°, %2°] on %3 segments.")
                            .arg(m_rotaryBMinLimit->value(), 0, 'f', 3).arg(m_rotaryBMaxLimit->value(), 0, 'f', 3).arg(outsideB);
            } else {
                details += tr("\nB travel check: not enabled or invalid limits.");
            }
            details += tr("\nThese rotary checks are preview-only and use the entered angular coordinates; they do not replace controller limits.");
            details += m_settings->softLimitsEnabled()
                    ? tr("Controller soft limits are reported enabled; this preview check is advisory only.")
                    : tr("Controller soft limits are reported disabled; this preview check is advisory only.");
        }
        m_rotarySegmentInfoLabel->setText(details);
        if (m_rotarySegmentCopyButton) {
            const bool hasMovement = details != tr("Line %1: no drawable movement found.").arg(line);
            m_rotarySegmentCopyButton->setEnabled(hasMovement);
        }
    }

    // Update selection marker
    if (line > 0 && line < lineIndexes.count() && !lineIndexes.at(line).isEmpty()) {
        const int selectedSegmentIndex = lineIndexes.at(line).last();
        if (selectedSegmentIndex >= 0 && selectedSegmentIndex < list.count() && list.at(selectedSegmentIndex)) {
            QVector3D pos = list.at(selectedSegmentIndex)->getEnd();
            m_selectionDrawer.setPosition(m_codeDrawer->getIgnoreZ() ? QVector3D(pos.x(), pos.y(), 0) : pos);
            m_selectionDrawer.setVisible(true);
            m_selectionDrawer.update();
        } else {
            m_selectionDrawer.setVisible(false);
        }
    } else {
        m_selectionDrawer.setVisible(false);
    }
}

void frmMain::onOverridingToggled(bool checked)
{
    Q_UNUSED(checked)

    ui->grpOverriding->setProperty("overrided", ui->slbFeedOverride->isChecked()
                                   || ui->slbRapidOverride->isChecked() || ui->slbSpindleOverride->isChecked());
    style()->unpolish(ui->grpOverriding);
    ui->grpOverriding->ensurePolished();
}

void frmMain::onOverrideChanged()
{
    updateProgramEstimatedTime(m_currentDrawer->viewParser()->getLineSegmentList());
}

void frmMain::onActRecentFileTriggered()
{
    QAction *action = static_cast<QAction*>(sender());
    QString fileName = action->text();

    if (action != NULL) {
        if (!saveChanges(m_heightMapMode)) return;
        if (!m_heightMapMode) loadFile(fileName); else loadHeightMap(fileName);
    }
}

void frmMain::onActSendFromLineTriggered()
{
    if (m_currentModel->rowCount() == 1) return;

    //Line to start from
    int commandIndex = ui->tblProgram->currentIndex().row();

    // Set parser state
    if (m_settings->autoLine()) {
        QString commands = getLineInitCommands(commandIndex);

        if (commands.length()) {
            bool res = false;
            commands = QInputDialog::getMultiLineText(this, "",
                tr("Following commands will be sent before selected line:\n"), commands, &res);
            if (!res) return;
            sendCommands(commands, -1);
        }
    }

    m_fileCommandIndex = commandIndex;
    m_fileProcessedCommandIndex = commandIndex;
    m_lastDrawnLineIndex = 0;
    m_probeIndex = -1;

    QList<LineSegment*> list = m_viewParser.getLineSegmentList();

    QList<int> indexes;
    for (int i = 0; i < list.count(); i++) {
        list[i]->setDrawn(list.at(i)->getLineNumber() < m_currentModel->data().at(commandIndex).line);
        indexes.append(i);
    }
    m_codeDrawer->update(indexes);

    ui->tblProgram->setUpdatesEnabled(false);

    for (int i = 0; i < m_currentModel->data().count() - 1; i++) {
        m_currentModel->data()[i].state = i < commandIndex ? GCodeItem::Skipped : GCodeItem::InQueue;
        m_currentModel->data()[i].response = QString();
    }
    ui->tblProgram->setUpdatesEnabled(true);
    ui->glwVisualizer->setSpendTime(QTime(0, 0, 0));

    m_startTime.start();

    setSenderState(SenderTransferring);

    m_storedKeyboardControl = ui->chkKeyboardControl->isChecked();
    ui->chkKeyboardControl->setChecked(false);

    storeParserState();

#ifdef WINDOWS
    if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
        if (m_taskBarProgress) {
            m_taskBarProgress->setMaximum(m_currentModel->rowCount() - 2);
            m_taskBarProgress->setValue(commandIndex);
            m_taskBarProgress->show();
        }
    }
#endif

    updateControlsState();
    ui->cmdFilePause->setFocus();

    m_fileCommandIndex = commandIndex;
    m_fileProcessedCommandIndex = commandIndex;
    sendNextFileCommands();
}

void frmMain::onSlbSpindleValueUserChanged()
{
    m_updateSpindleSpeed = true;
}

void frmMain::onSlbSpindleValueChanged()
{
    if (!ui->grpSpindle->isChecked() && ui->cmdSpindle->isChecked())
        ui->grpSpindle->setTitle(tr("Spindle") + QString(tr(" (%1)")).arg(ui->slbSpindle->value()));
}

void frmMain::onCboCommandReturnPressed()
{
    QString command = ui->cboCommand->currentText();
    if (command.isEmpty()) return;

    sendCommand(command, -1);
}

void frmMain::onDockTopLevelChanged(bool topLevel)
{
    QWidget* widget = static_cast<QWidget*>(sender());

    // Doesn't updates itself on object property change
    widget->setStyleSheet("");

    // Take into account margin of 11 
    widget->setMinimumWidth(widget->minimumWidth() + 22 * (topLevel ? 1 : -1));
    widget->setMaximumWidth(widget->maximumWidth() + 22 * (topLevel ? 1 : -1));
}

void frmMain::onScroolBarAction(int action)
{
    Q_UNUSED(action)

    if ((m_senderState == SenderTransferring) || (m_senderState == SenderStopping))
        ui->chkAutoScroll->setChecked(false);
}

void frmMain::onScriptException(const QScriptValue &exception)
{
    qCritical(scriptLogCategory) << "Script exception occured in plugin path:" << exception.engine()->objectName()
        << exception.toString();
}

void frmMain::onActServiceProfilesSelected(bool checked)
{
    if (!checked)
        return;

    auto action = static_cast<QAction*>(sender());
    auto profile = action->data().value<SettingsProfileEntry>();

    // Save previous profile changes
    if (m_currentProfileName != action->text()) {
        auto actions = m_profilesActionGroup->actions();
        auto it = std::find_if(actions.constBegin(), actions.constEnd(), [=](QAction *action) {
            return action->text() == m_currentProfileName;
        });
        if (it != actions.constEnd())
        {
            storeSettings();
            (*it)->setData(SettingsProfileEntry { m_currentProfileName, m_storage.save() });
        }
    }

    m_currentProfileName = action->text();

    m_storage.restore(profile.settings);
    restoreSettings();

    ui->actServiceProfilesDelete->setEnabled(action != ui->actServiceProfilesDefault);
}

void frmMain::onScriptStartClicked(const QString &script)
{
    QScriptEngine se;

    // Delegate import extension function
    QScriptValue sv = se.newObject();
    sv.setProperty("importExtension", se.newFunction(frmMain::importExtension));
    se.globalObject().setProperty("script", sv);
    se.setObjectName("script");

    // Delegate objects
    // App
    QScriptValue app = se.newQObject(m_scriptApp);
    app.setProperty("path", qApp->applicationDirPath());
    se.globalObject().setProperty("app", app);

    // Settings
    QScriptValue settings = se.newQObject(m_settings);
    app.setProperty("settings", settings);

    // Storage
    auto storage = se.newQObject(&m_storage);
    app.setProperty("storage", storage);

    qScriptRegisterMetaType<StorageGroup*>(&se,
        [](QScriptEngine *e, StorageGroup* const &g) {
            return e->newQObject(g, QScriptEngine::ScriptOwnership);
        },
        [](const QScriptValue &v, StorageGroup *&g) {
            g = qobject_cast<StorageGroup*>(v.toQObject());
        });

    // TODO: remove
    // Stored vars
    QScriptValue vars = se.newQObject(&m_storedVars);
    se.globalObject().setProperty("vars", vars);

    // Translator
    se.installTranslatorFunctions();

    // Evaluate script
    sv = se.evaluate(script);

    if (sv.isError()) {
        qCritical(scriptLogCategory) << "Error evaluating script" << sv.toString() << se.uncaughtExceptionBacktrace();
    }
}

void frmMain::updateHeightMapInterpolationDrawer(bool reset)
{
    if (m_settingsLoading) return;

    QRectF borderRect = borderRectFromTextboxes();
    m_heightMapInterpolationDrawer.setBorderRect(borderRect);

    QVector<QVector<double>> *interpolationData = new QVector<QVector<double>>;

    int interpolationPointsX = ui->txtHeightMapInterpolationStepX->value();// * (ui->txtHeightMapGridX->value() - 1) + 1;
    int interpolationPointsY = ui->txtHeightMapInterpolationStepY->value();// * (ui->txtHeightMapGridY->value() - 1) + 1;

    double interpolationStepX = interpolationPointsX > 1 ? borderRect.width() / (interpolationPointsX - 1) : 0;
    double interpolationStepY = interpolationPointsY > 1 ? borderRect.height() / (interpolationPointsY - 1) : 0;

    for (int i = 0; i < interpolationPointsY; i++) {
        QVector<double> row;
        for (int j = 0; j < interpolationPointsX; j++) {

            double x = interpolationStepX * j + borderRect.x();
            double y = interpolationStepY * i + borderRect.y();

            row.append(reset ? qQNaN() : Interpolation::bicubicInterpolate(borderRect, &m_heightMapModel, x, y));
        }
        interpolationData->append(row);
    }

    if (m_heightMapInterpolationDrawer.data() != NULL) {
        delete m_heightMapInterpolationDrawer.data();
    }
    m_heightMapInterpolationDrawer.setData(interpolationData);

    // Update grid drawer
    m_heightMapGridDrawer.update();

    // Heightmap changed by table user input
    if (sender() == &m_heightMapModel) m_heightMapChanged = true;

    // Reset heightmapped program model
    m_programHeightmapModel.clear();
}

void frmMain::placeVisualizerButtons()
{
    ui->cmdIsometric->move(ui->glwVisualizer->width() - ui->cmdIsometric->width() - 8, 8);
    ui->cmdTop->move(ui->cmdIsometric->geometry().left() - ui->cmdTop->width() - 8, 8);
    ui->cmdLeft->move(ui->glwVisualizer->width() - ui->cmdLeft->width() - 8, ui->cmdIsometric->geometry().bottom() + 8);
    ui->cmdFront->move(ui->cmdLeft->geometry().left() - ui->cmdFront->width() - 8, ui->cmdIsometric->geometry().bottom() + 8);
    ui->cmdFit->move(ui->glwVisualizer->width() - ui->cmdFit->width() - 8, ui->cmdLeft->geometry().bottom() + 8);
    ui->cmdPerspective->move(ui->cmdFit->geometry().left() - ui->cmdPerspective->width() - 8, ui->cmdLeft->geometry().bottom() + 8);
}

void frmMain::preloadSettings()
{
    QSettings set;
    set.beginGroup("General");

    qApp->setStyleSheet(QString(qApp->styleSheet()).replace(QRegExp("font-size:\\s*\\d+"), "font-size: "
        + set.value("fontSize", "9").toString()));

    set.endGroup();
}

void frmMain::loadSettings()
{
    m_settingsLoading = true;
    
    QSettings set;
    set.beginGroup("General");

    // Language
    m_settings->setLanguage(set.value("language", "fr").toString());

    // Load plugins
    loadPlugins();
    emit pluginsLoaded();

    // Load profiles
    loadProfiles(set);

    // Docks signals/slots
    foreach (QDockWidget *w, findChildren<QDockWidget*>())
        connect(w, &QDockWidget::topLevelChanged, this, &frmMain::onDockTopLevelChanged);

    // Restore main form geometry
    auto formGeometry = set.value("formGeometry").toByteArray();

    if (set.value("formMaximized", false).toBool())
    {
        // Force maximized window size for proper dockWidgets restoring as restoreGeometry will set non maximized
        //   window size
        resize(set.value("formSize").toSize());
        showMaximized();
    } else {
        const bool geometryRestored = restoreGeometry(formGeometry);
        QScreen *screen = QGuiApplication::primaryScreen();
        const QRect available = screen ? screen->availableGeometry() : QRect(0, 0, 1280, 800);
        const int minimumUsefulWidth = qMin(900, available.width());
        const int minimumUsefulHeight = qMin(650, available.height());

        // Recover only when the stored geometry is invalid or unusably small.
        // Valid user layouts are kept intact.
        if (!geometryRestored || width() < minimumUsefulWidth || height() < minimumUsefulHeight) {
            resize(available.size());
            showMaximized();
        }
    }

    // Settings form geometry
    m_settings->restoreGeometry(set.value("formSettingsGeometry").toByteArray());

    // Menu
    ui->actViewLockWindows->setChecked(set.value("lockWindows").toBool());
    ui->actViewLockPanels->setChecked(set.value("lockPanels").toBool());

    // Phase 53: restore the operator's independent A/B preview envelopes.
    // Checks remain opt-in; saved values are never treated as controller limits.
    set.beginGroup("RotaryPreviewLimits");
    if (m_checkRotaryALimits) m_checkRotaryALimits->setChecked(set.value("enableA", false).toBool());
    if (m_checkRotaryBLimits) m_checkRotaryBLimits->setChecked(set.value("enableB", false).toBool());
    if (m_rotaryAMinLimit) m_rotaryAMinLimit->setValue(set.value("aMin", -360.0).toDouble());
    if (m_rotaryAMaxLimit) m_rotaryAMaxLimit->setValue(set.value("aMax", 360.0).toDouble());
    if (m_rotaryBMinLimit) m_rotaryBMinLimit->setValue(set.value("bMin", -360.0).toDouble());
    if (m_rotaryBMaxLimit) m_rotaryBMaxLimit->setValue(set.value("bMax", 360.0).toDouble());
    set.endGroup();

    set.endGroup();

    m_settingsLoading = false;
}

void frmMain::saveSettings()
{
    QSettings set;
    set.beginGroup("General");

    // Save current profile changes
    auto action = m_profilesActionGroup->checkedAction();
    if (action)
    {
        storeSettings();
        action->setData(SettingsProfileEntry { m_currentProfileName, m_storage.save() });
    }

    // Save profiles
    saveProfiles(set);

    // Menu
    set.setValue("lockWindows", ui->actViewLockWindows->isChecked());
    set.setValue("lockPanels", ui->actViewLockPanels->isChecked());

    // Main form
    set.setValue("formGeometry", saveGeometry());
    set.setValue("formMaximized", isMaximized());
    set.setValue("formSize", size());

    // Settings form
    set.setValue("formSettingsGeometry", m_settings->saveGeometry());

    // Language
    set.setValue("language", m_settings->language());

    // Phase 53: persist preview-only rotary limits independently for A and B.
    // This stores the operator's entries, not a claim about physical limits.
    set.beginGroup("RotaryPreviewLimits");
    if (m_checkRotaryALimits) set.setValue("enableA", m_checkRotaryALimits->isChecked());
    if (m_checkRotaryBLimits) set.setValue("enableB", m_checkRotaryBLimits->isChecked());
    if (m_rotaryAMinLimit) set.setValue("aMin", m_rotaryAMinLimit->value());
    if (m_rotaryAMaxLimit) set.setValue("aMax", m_rotaryAMaxLimit->value());
    if (m_rotaryBMinLimit) set.setValue("bMin", m_rotaryBMinLimit->value());
    if (m_rotaryBMaxLimit) set.setValue("bMax", m_rotaryBMaxLimit->value());
    set.endGroup();

    set.endGroup();
}

void frmMain::storeSettings()
{
    auto set = m_storage.group("General");

    emit settingsAboutToSave();

    set->setValue("port", m_settings->port());
    set->setValue("baud", m_settings->baud());
    set->setValue("ignoreErrors", m_settings->ignoreErrors());
    set->setValue("autoLine", m_settings->autoLine());
    set->setValue("toolDiameter", m_settings->toolDiameter());
    set->setValue("toolLength", m_settings->toolLength());
    set->setValue("antialiasing", m_settings->antialiasing());
    set->setValue("msaa", m_settings->msaa());
    set->setValue("vsync", m_settings->vsync());
    set->setValue("zBuffer", m_settings->zBuffer());
    set->setValue("simplify", m_settings->simplify());
    set->setValue("simplifyPrecision", m_settings->simplifyPrecision());
    set->setValue("grayscaleSegments", m_settings->grayscaleSegments());
    set->setValue("grayscaleSCode", m_settings->grayscaleSCode());
    set->setValue("drawModeVectors", m_settings->drawModeVectors());

    set->setValue("spindleSpeed", ui->slbSpindle->value());
    set->setValue("lineWidth", m_settings->lineWidth());
    set->setValue("arcLength", m_settings->arcLength());
    set->setValue("arcDegree", m_settings->arcDegree());
    set->setValue("arcDegreeMode", m_settings->arcDegreeMode());
    set->setValue("showProgramCommands", m_settings->showProgramCommands());
    set->setValue("showUICommands", m_settings->showUICommands());
    set->setValue("spindleSpeedMin", m_settings->spindleSpeedMin());
    set->setValue("spindleSpeedMax", m_settings->spindleSpeedMax());
    set->setValue("laserPowerMin", m_settings->laserPowerMin());
    set->setValue("laserPowerMax", m_settings->laserPowerMax());
    set->setValue("rapidSpeed", m_settings->rapidSpeed());
    set->setValue("acceleration", m_settings->acceleration());
    set->setValue("toolAngle", m_settings->toolAngle());
    set->setValue("toolType", m_settings->toolType());
    set->setValue("fps", m_settings->fps());
    set->setValue("queryStateTime", m_settings->queryStateTime());
    set->setValue("axisAEnabled", m_settings->axisAEnabled());
    set->setValue("axisAX", m_settings->axisAX());
    set->setValue("axisBEnabled", m_settings->axisBEnabled());
    set->setValue("pivotAX", m_settings->pivotAX());
    set->setValue("pivotAY", m_settings->pivotAY());
    set->setValue("pivotAZ", m_settings->pivotAZ());
    set->setValue("pivotBX", m_settings->pivotBX());
    set->setValue("pivotBY", m_settings->pivotBY());
    set->setValue("pivotBZ", m_settings->pivotBZ());
    set->setValue("showRotaryA", m_settings->showRotaryA());
    set->setValue("showRotaryB", m_settings->showRotaryB());
    set->setValue("rotaryAWidth", m_settings->rotaryAWidth());
    set->setValue("rotaryADepth", m_settings->rotaryADepth());
    set->setValue("rotaryBWidth", m_settings->rotaryBWidth());
    set->setValue("rotaryBDepth", m_settings->rotaryBDepth());
    set->setValue("stockAWidth", m_settings->stockAWidth());
    set->setValue("stockADepth", m_settings->stockADepth());
    set->setValue("stockBWidth", m_settings->stockBWidth());
    set->setValue("stockBDepth", m_settings->stockBDepth());
    set->setValue("stockAHeight", m_settings->stockAHeight());
    set->setValue("stockBHeight", m_settings->stockBHeight());
    set->setValue("stockAShape", m_settings->stockAShape());
    set->setValue("stockBShape", m_settings->stockBShape());

    set->setValue("autoScroll", ui->chkAutoScroll->isChecked());
    set->setValue("header", ui->tblProgram->horizontalHeader()->saveState());

    set->setValue("autoCompletion", m_settings->autoCompletion());
    set->setValue("units", m_settings->units());
    set->setValue("recentFiles", m_recentFiles);
    set->setValue("recentHeightmaps", m_recentHeightmaps);
    set->setValue("lastFolder", m_lastFolder);
    set->setValue("fontSize", m_settings->fontSize());
    set->setValue("panelWidth", m_settings->panelWidth());
    set->setValue("keyboardControl", m_storedKeyboardControl);

    set->setValue("useStartCommands", m_settings->useStartCommands());
    set->setValue("startCommands", m_settings->startCommands());
    set->setValue("useEndCommands", m_settings->useEndCommands());
    set->setValue("endCommands", m_settings->endCommands());
    set->setValue("toolChangeCommands", m_settings->toolChangeCommands());
    set->setValue("toolChangePause", m_settings->toolChangePause());
    set->setValue("toolChangeUseCommands", m_settings->toolChangeUseCommands());
    set->setValue("toolChangeUseCommandsConfirm", m_settings->toolChangeUseCommandsConfirm());
    set->setValue("referenceXPlus", m_settings->referenceXPlus());
    set->setValue("referenceYPlus", m_settings->referenceYPlus());
    set->setValue("referenceZPlus", m_settings->referenceZPlus());
    set->setValue("invertedSliderControls", m_settings->invertedSliderControls());

    set->setValue("feedOverride", ui->slbFeedOverride->isChecked());
    set->setValue("feedOverrideValue", ui->slbFeedOverride->value());
    set->setValue("rapidOverride", ui->slbRapidOverride->isChecked());
    set->setValue("rapidOverrideValue", ui->slbRapidOverride->value());
    set->setValue("spindleOverride", ui->slbSpindleOverride->isChecked());
    set->setValue("spindleOverrideValue", ui->slbSpindleOverride->value());

    set->setValue("jogSteps", (QStringList)ui->cboJogStep->items().mid(1, ui->cboJogStep->items().count() - 1));
    set->setValue("jogStep", ui->cboJogStep->currentIndex());
    set->setValue("jogFeeds", ui->cboJogFeed->items());
    set->setValue("jogFeed", ui->cboJogFeed->currentIndex());

    set->setValue("heightmapBorderX", ui->txtHeightMapBorderX->value());
    set->setValue("heightmapBorderY", ui->txtHeightMapBorderY->value());
    set->setValue("heightmapBorderWidth", ui->txtHeightMapBorderWidth->value());
    set->setValue("heightmapBorderHeight", ui->txtHeightMapBorderHeight->value());
    set->setValue("heightmapBorderShow", ui->chkHeightMapBorderShow->isChecked());

    set->setValue("heightmapOriginX", ui->txtHeightMapOriginX->value());
    set->setValue("heightmapOriginY", ui->txtHeightMapOriginY->value());
    set->setValue("heightmapOriginShow", ui->chkHeightMapOriginShow->isChecked());

    set->setValue("heightmapGridX", ui->txtHeightMapGridX->value());
    set->setValue("heightmapGridY", ui->txtHeightMapGridY->value());
    set->setValue("heightmapGridZTop", ui->txtHeightMapGridZTop->value());
    set->setValue("heightmapGridZBottom", ui->txtHeightMapGridZBottom->value());
    set->setValue("heightmapProbeFeed", ui->txtHeightMapProbeFeed->value());
    set->setValue("heightmapGridShow", ui->chkHeightMapGridShow->isChecked());

    set->setValue("heightmapInterpolationStepX", ui->txtHeightMapInterpolationStepX->value());
    set->setValue("heightmapInterpolationStepY", ui->txtHeightMapInterpolationStepY->value());
    set->setValue("heightmapInterpolationType", ui->cboHeightMapInterpolationType->currentIndex());
    set->setValue("heightmapInterpolationShow", ui->chkHeightMapInterpolationShow->isChecked());

    set->setValue("viewPerspective", ui->cmdPerspective->isChecked());

    foreach (ColorPicker* pick, m_settings->colors()) {
        set->setValue("" + pick->objectName().mid(3), pick->color().name());
    }

    QStringList list;

    for (int i = 0; i < ui->cboCommand->count(); i++) list.append(ui->cboCommand->itemText(i));
    set->setValue("recentCommands", list);

    // Shortcuts
    ShortcutsMap m;
    QByteArray ba;
    QDataStream s(&ba, QIODevice::WriteOnly);
    QList<QAction*> acts = findChildren<QAction*>(QRegExp("act.*"));

    foreach (QAction *a, acts) m[a->objectName()] = a->shortcuts();
    s << m;
    set->setValue("shortcuts", ba);

    // Menu
    set->setValue("lockWindows", ui->actViewLockWindows->isChecked());
    set->setValue("lockPanels", ui->actViewLockPanels->isChecked());

    // Mark the current, validated panel layout. This key is stored in the
    // active profile; it does not touch UserCommands macros or machine data.
    set->setValue("layoutVersion", 1);

    // Panels
    set->setValue("devicePanels", ui->scrollContentsDevice->saveState());
    set->setValue("modificationPanels", ui->scrollContentsModification->saveState());
    set->setValue("userPanels", ui->scrollContentsUser->saveState());

    QStringList panels;
    QStringList hiddenPanels;
    QStringList collapsedPanels;

    if (ui->scrollContentsDevice->isVisible()) panels << ui->scrollContentsDevice->saveState();
    if (ui->scrollContentsModification->isVisible()) panels << ui->scrollContentsModification->saveState();
    if (ui->scrollContentsUser->isVisible()) panels << ui->scrollContentsUser->saveState();

    foreach (QString s, panels) {
        QGroupBox *b = findChild<QGroupBox*>(s);
        if (b && b->isHidden()) hiddenPanels << s;
        if (b && b->isCheckable() && !b->isChecked()) collapsedPanels << s;
    }

    set->setValue("hiddenPanels", hiddenPanels);
    set->setValue("collapsedPanels", collapsedPanels);
    set->setValue("formState", saveState());

    // Save script variables
    QScriptEngine e;
    QScriptValue d = e.globalObject();
    QScriptValueIterator i(d);
    QStringList l;
    while (i.hasNext()) {
        i.next();
        l << i.name();
    }

    auto scriptSet = set->group("Script");
    QScriptValue v = m_scriptEngine.globalObject();
    QScriptValueIterator it(v);
    while (it.hasNext()) {
        it.next();
        if (!l.contains(it.name())) {
            if (it.value().isNumber() || it.value().isString()) {
                scriptSet->setValue(it.name(), it.value().toVariant());
            }
        }
    }

    emit settingsSaved();

    delete scriptSet;
    delete set;    
}

void frmMain::restoreSettings()
{
    auto set = m_storage.group("General");

    m_settingsLoading = true;

    emit settingsAboutToLoad();

    if (set->childKeys().size()) {
        m_settings->setFontSize(set->value("fontSize", 9).toInt());
        m_settings->setPanelWidth(set->value("panelWidth", 48).toInt());
        m_settings->setPort(set->value("port").toString());
        m_settings->setBaud(set->value("baud", 115200).toInt());
        m_settings->setIgnoreErrors(set->value("ignoreErrors", false).toBool());
        m_settings->setAutoLine(set->value("autoLine", true).toBool());
        m_settings->setToolDiameter(set->value("toolDiameter", 3).toDouble());
        m_settings->setToolLength(set->value("toolLength", 30).toDouble());
        m_settings->setToolAngle(set->value("toolAngle", 15).toDouble());
        m_settings->setToolType(set->value("toolType", 1).toInt());
        m_settings->setAntialiasing(set->value("antialiasing", true).toBool());
        m_settings->setMsaa(set->value("msaa", true).toBool());
        m_settings->setVsync(set->value("vsync", false).toBool());
        m_settings->setZBuffer(set->value("zBuffer", false).toBool());
        m_settings->setSimplify(set->value("simplify", true).toBool());
        m_settings->setSimplifyPrecision(set->value("simplifyPrecision", 0).toDouble());
        m_settings->setGrayscaleSegments(set->value("grayscaleSegments", false).toBool());
        m_settings->setGrayscaleSCode(set->value("grayscaleSCode", true).toBool());
        m_settings->setDrawModeVectors(set->value("drawModeVectors", true).toBool());
        m_settings->setLineWidth(set->value("lineWidth", 1.5).toDouble());
        m_settings->setArcLength(set->value("arcLength", 0).toDouble());
        m_settings->setArcDegree(set->value("arcDegree", 5).toDouble());
        m_settings->setArcDegreeMode(set->value("arcDegreeMode", true).toBool());
        m_settings->setShowProgramCommands(set->value("showProgramCommands", 0).toBool());
        m_settings->setShowUICommands(set->value("showUICommands", 0).toBool());
        m_settings->setSpindleSpeedMin(set->value("spindleSpeedMin", 0).toInt());
        m_settings->setSpindleSpeedMax(set->value("spindleSpeedMax", 10000).toInt());
        m_settings->setLaserPowerMin(set->value("laserPowerMin", 0).toInt());
        m_settings->setLaserPowerMax(set->value("laserPowerMax", 100).toInt());
        m_settings->setRapidSpeed(set->value("rapidSpeed", 0).toInt());
        m_settings->setAcceleration(set->value("acceleration", 10).toInt());
        m_settings->setFps(set->value("fps", 60).toInt());
        m_settings->setQueryStateTime(set->value("queryStateTime", 40).toInt());
        m_settings->setUseStartCommands(set->value("useStartCommands").toBool());
        m_settings->setStartCommands(set->value("startCommands").toString());
        m_settings->setUseEndCommands(set->value("useEndCommands").toBool());
        m_settings->setEndCommands(set->value("endCommands").toString());
        m_settings->setToolChangeCommands(set->value("toolChangeCommands").toString());
        m_settings->setToolChangePause(set->value("toolChangePause").toBool());
        m_settings->setToolChangeUseCommands(set->value("toolChangeUseCommands").toBool());
        m_settings->setToolChangeUseCommandsConfirm(set->value("toolChangeUseCommandsConfirm").toBool());
        m_settings->setReferenceXPlus(set->value("referenceXPlus", false).toBool());
        m_settings->setReferenceYPlus(set->value("referenceYPlus", false).toBool());
        m_settings->setReferenceZPlus(set->value("referenceZPlus", false).toBool());
        m_settings->setAutoCompletion(set->value("autoCompletion", true).toBool());
        m_settings->setUnits(set->value("units", 0).toInt());
        m_settings->setInvertedSliderControls(set->value("invertedSliderControls", false).toBool());
        m_settings->setAxisAEnabled(set->value("axisAEnabled", false).toBool());
        m_settings->setAxisAX(set->value("axisAX", true).toBool());
        m_settings->setAxisBEnabled(set->value("axisBEnabled", false).toBool());
        m_settings->setPivotAX(set->value("pivotAX", 0.0).toDouble());
        m_settings->setPivotAY(set->value("pivotAY", 0.0).toDouble());
        m_settings->setPivotAZ(set->value("pivotAZ", 0.0).toDouble());
        m_settings->setPivotBX(set->value("pivotBX", 0.0).toDouble());
        m_settings->setPivotBY(set->value("pivotBY", 0.0).toDouble());
        m_settings->setPivotBZ(set->value("pivotBZ", 0.0).toDouble());
        m_settings->setShowRotaryA(set->value("showRotaryA", true).toBool());
        m_settings->setShowRotaryB(set->value("showRotaryB", true).toBool());
        m_settings->setRotaryAWidth(set->value("rotaryAWidth", 32.0).toDouble());
        m_settings->setRotaryADepth(set->value("rotaryADepth", 24.0).toDouble());
        m_settings->setRotaryBWidth(set->value("rotaryBWidth", 32.0).toDouble());
        m_settings->setRotaryBDepth(set->value("rotaryBDepth", 24.0).toDouble());
        m_settings->setStockAWidth(set->value("stockAWidth", 19.2).toDouble());
        m_settings->setStockADepth(set->value("stockADepth", 14.4).toDouble());
        m_settings->setStockBWidth(set->value("stockBWidth", 19.2).toDouble());
        m_settings->setStockBDepth(set->value("stockBDepth", 14.4).toDouble());
        m_settings->setStockAHeight(set->value("stockAHeight", 8.0).toDouble());
        m_settings->setStockBHeight(set->value("stockBHeight", 8.0).toDouble());
        m_settings->setStockAShape(set->value("stockAShape", 0).toInt());
        m_settings->setStockBShape(set->value("stockBShape", 0).toInt());

        foreach (ColorPicker* pick, m_settings->colors()) {
            pick->setColor(QColor(set->value(pick->objectName().mid(3), "black").toString()));
        }
    } else {
        m_settings->setShortcuts(findChildren<QAction*>(QRegExp("act.*")));
        m_settings->setDefaultSettings();
    }

    ui->chkAutoScroll->setChecked(set->value("autoScroll", false).toBool());

    ui->slbSpindle->setRatio(100);
    ui->slbSpindle->setMinimum(m_settings->spindleSpeedMin());
    ui->slbSpindle->setMaximum(m_settings->spindleSpeedMax());
    ui->slbSpindle->setValue(set->value("spindleSpeed", 100).toInt());

    ui->slbFeedOverride->setChecked(set->value("feedOverride", false).toBool());
    ui->slbFeedOverride->setValue(set->value("feedOverrideValue", 100).toInt());

    ui->slbRapidOverride->setChecked(set->value("rapidOverride", false).toBool());
    ui->slbRapidOverride->setValue(set->value("rapidOverrideValue", 100).toInt());

    ui->slbSpindleOverride->setChecked(set->value("spindleOverride", false).toBool());
    ui->slbSpindleOverride->setValue(set->value("spindleOverrideValue", 100).toInt());

    m_recentFiles = set->value("recentFiles", QStringList()).toStringList();
    m_recentHeightmaps = set->value("recentHeightmaps", QStringList()).toStringList();
    m_lastFolder = set->value("lastFolder", QDir::homePath()).toString();

    m_storedKeyboardControl = set->value("keyboardControl", false).toBool();

    QStringList steps = set->value("jogSteps").toStringList();
    if (steps.count() > 0) {
        steps.insert(0, ui->cboJogStep->items().first());
        ui->cboJogStep->setItems(steps);
    }
    ui->cboJogStep->setCurrentIndex(set->value("jogStep", "3").toInt());
    ui->cboJogFeed->setItems(set->value("jogFeeds").toStringList());
    ui->cboJogFeed->setCurrentIndex(set->value("jogFeed", "2").toInt());

    ui->txtHeightMapBorderX->setValue(set->value("heightmapBorderX", 0).toDouble());
    ui->txtHeightMapBorderY->setValue(set->value("heightmapBorderY", 0).toDouble());
    ui->txtHeightMapBorderWidth->setValue(set->value("heightmapBorderWidth", 1).toDouble());
    ui->txtHeightMapBorderHeight->setValue(set->value("heightmapBorderHeight", 1).toDouble());
    ui->chkHeightMapBorderShow->setChecked(set->value("heightmapBorderShow", true).toBool());
    ui->chkHeightMapOriginShow->setChecked(set->value("heightmapOriginShow", true).toBool());

    ui->txtHeightMapOriginX->setValue(set->value("heightmapOriginX", 0).toDouble());
    ui->txtHeightMapOriginY->setValue(set->value("heightmapOriginY", 0).toDouble());

    ui->txtHeightMapGridX->setValue(set->value("heightmapGridX", 1).toDouble());
    ui->txtHeightMapGridY->setValue(set->value("heightmapGridY", 1).toDouble());
    ui->txtHeightMapGridZTop->setValue(set->value("heightmapGridZTop", 1).toDouble());
    ui->txtHeightMapGridZBottom->setValue(set->value("heightmapGridZBottom", -1).toDouble());
    ui->txtHeightMapProbeFeed->setValue(set->value("heightmapProbeFeed", 10).toDouble());
    ui->chkHeightMapGridShow->setChecked(set->value("heightmapGridShow", true).toBool());

    ui->txtHeightMapInterpolationStepX->setValue(set->value("heightmapInterpolationStepX", 1).toDouble());
    ui->txtHeightMapInterpolationStepY->setValue(set->value("heightmapInterpolationStepY", 1).toDouble());
    ui->cboHeightMapInterpolationType->setCurrentIndex(set->value("heightmapInterpolationType", 0).toInt());
    ui->chkHeightMapInterpolationShow->setChecked(set->value("heightmapInterpolationShow", true).toBool());

    ui->cmdPerspective->setChecked(set->value("viewPerspective", true).toBool());

    updateRecentFilesMenu();

    ui->tblProgram->horizontalHeader()->restoreState(set->value("header", QByteArray()).toByteArray());

    // Apply settings
    applySettings();

    // Restore last commands list
    ui->cboCommand->clear();
    ui->cboCommand->addItems(set->value("recentCommands", QStringList()).toStringList());
    ui->cboCommand->setCurrentIndex(-1);

    // Setup coords textboxes
    setupCoordsTextboxes();

    // Load plugin settings
    emit settingsLoaded();

    // Layout migration: discard only obsolete panel/dock visibility and geometry
    // once. Machine profiles, macros, offsets and controller settings are kept.
    // Older saved states could restore a valid-but-unusable miniature layout.
    const bool forceDefaultLayout = set->value("layoutVersion", 0).toInt() < 1;

    // Panels
    if (!forceDefaultLayout) {
        ui->scrollContentsDevice->restoreState(this, set->value("devicePanels").toStringList());
        ui->scrollContentsModification->restoreState(this, set->value("modificationPanels").toStringList());
        ui->scrollContentsUser->restoreState(this, set->value("userPanels").toStringList());

        QStringList hiddenPanels = set->value("hiddenPanels").toStringList();
        foreach (QString s, hiddenPanels) {
            QGroupBox *b = findChild<QGroupBox*>(s);
            if (b) b->setHidden(true);
        }

        QStringList collapsedPanels = set->value("collapsedPanels").toStringList();
        foreach (QString s, collapsedPanels) {
            QGroupBox *b = findChild<QGroupBox*>(s);
            if (b) b->setChecked(false);
        }
    }

    // Main window state
    auto formState = set->value("formState").toByteArray();

    if (forceDefaultLayout || !formState.size()) {
        ui->dockVisualizer->setVisible(true);
        ui->dockConsole->setVisible(true);
        ui->dockDevice->setVisible(true);
        ui->dockUser->setVisible(true);
        ui->dockScript->setVisible(false);
        ui->dockLog->setVisible(false);

        auto cameraDock = findChild<QDockWidget*>("dockCameraPlugin");
        if (cameraDock) cameraDock->setVisible(false);

        resizeDocks({ui->dockModification, ui->dockUser}, {1, 1}, Qt::Vertical);
        splitDockWidget(ui->dockVisualizer, ui->dockConsole, Qt::Horizontal);
        splitDockWidget(ui->dockUser, ui->dockDevice, Qt::Horizontal);
    } else {
        if (!restoreState(formState)) {
            ui->dockScript->setVisible(false);
            ui->dockLog->setVisible(false);

            auto cameraDock = findChild<QDockWidget*>("dockCameraPlugin");
            if (cameraDock) cameraDock->setVisible(false);

            ui->dockVisualizer->setVisible(true);
            ui->dockConsole->setVisible(true);
            ui->dockDevice->setVisible(true);
            ui->dockUser->setVisible(true);
            resizeDocks({ui->dockModification, ui->dockUser}, {1, 1}, Qt::Vertical);
            splitDockWidget(ui->dockVisualizer, ui->dockConsole, Qt::Horizontal);
            splitDockWidget(ui->dockUser, ui->dockDevice, Qt::Horizontal);
        }
    }

    // Shortcuts
    qRegisterMetaTypeStreamOperators<ShortcutsMap>("ShortcutsMap");

    ShortcutsMap m;
    QByteArray ba = set->value("shortcuts").toByteArray();
    QDataStream s(&ba, QIODevice::ReadOnly);
    s >> m;
    for (int i = 0; i < m.count(); i++) {
        QAction *a = findChild<QAction*>(m.keys().at(i));
        if (a) a->setShortcuts(m.values().at(i));
    }

    // Loading stored script variables
    QScriptValue g = m_scriptEngine.globalObject();

    // Clear script global object
    QStringList defaultObjects = {"print", "version", "gc", "vars", "script"};
    QScriptValueIterator it(g);
    while (it.hasNext()) {
        it.next();
        if ((it.flags() & QScriptValue::SkipInEnumeration) || defaultObjects.contains(it.name()))
            continue;
        g.setProperty(it.name(), QScriptValue());
    }

    auto scriptSet = set->group("Script");
    QStringList l = scriptSet->childKeys();
    foreach (const QString &k, l) {
        g.setProperty(k, m_scriptEngine.newVariant(scriptSet->value(k)));
    }

    // Update inverted slider controls
    auto sliders = this->findChildren<QSlider*>();
    foreach (auto slider, sliders) {
        slider->setInvertedControls(m_settings->invertedSliderControls());
    }

    delete scriptSet;
    delete set;

    m_settingsLoading = false;
}

void frmMain::saveProfiles(QSettings &set)
{
    // Profiles
    QVariantList profiles;
    auto actions = m_profilesActionGroup->actions();

    for (auto it = actions.constBegin(); it != actions.constEnd(); it++) {
        profiles.append((*it)->data());
    }
    set.setValue("profiles", profiles);
    set.setValue("currentProfileName", m_currentProfileName);    
}

void frmMain::loadProfiles(QSettings &set)
{
    // Register types
    qRegisterMetaType<SettingsProfileEntry>();
    qRegisterMetaTypeStreamOperators<SettingsProfileEntry>("SettingsProfileEntry");
    QMetaType::registerDebugStreamOperator<SettingsProfileEntry>();

    // Group for exclusive menu item check
    m_profilesActionGroup = new QActionGroup(this);
    m_profilesActionGroup->setExclusive(true);

    // Find separator to insert items before it
    auto menuActions = ui->mnuServiceProfiles->actions();
    auto separator = *std::find_if(menuActions.constBegin(), menuActions.constEnd(), [](QAction *action) {
        return action->isSeparator();
    });

    // Load profiles
    auto profiles = set.value("profiles").toList();
    m_currentProfileName = set.value("currentProfileName").toString();

    if (profiles.count() > 0) {
        // Default profile always first
        ui->actServiceProfilesDefault->setData(profiles.first().value<SettingsProfileEntry>());
    } else {
        // No profiles saved
        ui->actServiceProfilesDefault->setData(SettingsProfileEntry {
            ui->actServiceProfilesDefault->text(),
            QByteArray()
        });
    }

    m_profilesActionGroup->addAction(ui->actServiceProfilesDefault);
    connect(ui->actServiceProfilesDefault, &QAction::toggled, this, &frmMain::onActServiceProfilesSelected);

    // Rest of profiles
    if (profiles.count() > 1) {
        for (auto it = profiles.cbegin() + 1; it != profiles.cend(); it++) {
            auto settingsProfileEntry = (*it).value<SettingsProfileEntry>();
            auto action = new QAction(settingsProfileEntry.name, m_profilesActionGroup);
            action->setData(settingsProfileEntry);
            action->setCheckable(true);

            m_profilesActionGroup->addAction(action);
            ui->mnuServiceProfiles->insertAction(separator, action);

            connect(action, &QAction::toggled, this, &frmMain::onActServiceProfilesSelected);
        }
    }

    // Select current profile
    auto actions = m_profilesActionGroup->actions();
    auto it = std::find_if(actions.constBegin(), actions.constEnd(), [=](QAction *action) {
        return action->text() == m_currentProfileName;
    });

    (it != actions.constEnd() ? *it : ui->actServiceProfilesDefault)->setChecked(true);
}

void frmMain::applySettings()
{
    // Apply font size QWidget {font-size: 8pt}
    qApp->setStyleSheet(QString(qApp->styleSheet()).replace(QRegExp(
        "QWidget \\{font-size: \\d+pt\\}"),
        QString("QWidget {font-size: %1pt}").arg(m_settings->fontSize()))
    );

    // Panel buttons style
    int panelButtonSize = ui->cmdReset->minimumWidth();

    setStyleSheet(styleSheet() + QString("\nStyledToolButton[adjustSize='true'] {\n\
	    qproperty-iconSize: %1px;\n\
        }").arg(qRound(panelButtonSize * 0.8)));

    // Ensure styles
    ensurePolished();

    // Docks
    foreach (QDockWidget *w, findChildren<QDockWidget*>()) w->setStyleSheet("");

    // Adjust docks width
    auto panelWidth = QFontMetrics(font()).averageCharWidth() * m_settings->panelWidth();

    ui->dockDevice->setMinimumWidth(panelWidth);
    ui->dockDevice->setMaximumWidth(panelWidth + ui->scrollArea->verticalScrollBar()->width());
    ui->dockModification->setMinimumWidth(panelWidth);
    ui->dockModification->setMaximumWidth(panelWidth + ui->scrollArea->verticalScrollBar()->width());
    ui->dockUser->setMinimumWidth(panelWidth);
    ui->dockUser->setMaximumWidth(panelWidth + ui->scrollArea->verticalScrollBar()->width());

    // Update shortcuts
    QList<QAction*> acts = findChildren<QAction*>(QRegExp("act.*"));
    QTableWidget *shortcuts = m_settings->shortcuts();

    for (int i = 0; i < shortcuts->rowCount(); i++) {
        auto shortcut = shortcuts->item(i, 0);
        auto act = std::find_if(
            acts.begin(),
            acts.end(),
            [shortcut](const QAction *act) {
                return act->objectName() == shortcut->data(Qt::DisplayRole).toString();
            }
        );

        if (act != acts.end()) {
            (*act)->setShortcut(QKeySequence(shortcuts->item(i, 2)->data(Qt::DisplayRole).toString()));
        }
    }

    m_originDrawer->setLineWidth(m_settings->lineWidth());
    m_toolDrawer.setToolDiameter(m_settings->toolDiameter());
    m_toolDrawer.setToolLength(m_settings->toolLength());
    m_toolDrawer.setLineWidth(m_settings->lineWidth());
    m_codeDrawer->setLineWidth(m_settings->lineWidth());
    m_heightMapBorderDrawer.setLineWidth(m_settings->lineWidth());
    m_heightMapGridDrawer.setLineWidth(0.1);
    m_heightMapInterpolationDrawer.setLineWidth(m_settings->lineWidth());
    ui->glwVisualizer->setLineWidth(m_settings->lineWidth());
    m_timerStateQuery.setInterval(m_settings->queryStateTime());

    m_toolDrawer.setToolAngle(m_settings->toolType() == 0 ? 180 : m_settings->toolAngle());
    m_toolDrawer.setColor(m_settings->colors("Tool"));
    m_toolDrawer.update();

    ui->glwVisualizer->setAntialiasing(m_settings->antialiasing());
    ui->glwVisualizer->setMsaa(m_settings->msaa());
    ui->glwVisualizer->setZBuffer(m_settings->zBuffer());
    ui->glwVisualizer->setVsync(m_settings->vsync());
    ui->glwVisualizer->setFps(m_settings->fps());
    ui->glwVisualizer->setColorBackground(m_settings->colors("VisualizerBackground"));
    ui->glwVisualizer->setColorText(m_settings->colors("VisualizerText"));

    ui->slbSpindle->setRatio(pow(10, qMax<double>(0, floor(log10(m_settings->spindleSpeedMax())) - 2)));
    ui->slbSpindle->setMinimum(m_settings->spindleSpeedMin());
    ui->slbSpindle->setMaximum(m_settings->spindleSpeedMax());

    ui->cboCommand->setAutoCompletion(m_settings->autoCompletion());

    m_codeDrawer->setSimplify(m_settings->simplify());
    m_codeDrawer->setSimplifyPrecision(m_settings->simplifyPrecision());
    m_codeDrawer->setColorNormal(m_settings->colors("ToolpathNormal"));
    // G0 rapid moves use a dedicated blue; G1 cutting moves retain the configured normal color.
    m_codeDrawer->setColorRapid(QColor(30, 144, 255));
    m_codeDrawer->setColorDrawn(m_settings->colors("ToolpathDrawn"));
    m_codeDrawer->setColorHighlight(m_settings->colors("ToolpathHighlight"));
    m_codeDrawer->setColorZMovement(m_settings->colors("ToolpathZMovement"));
    m_codeDrawer->setColorStart(m_settings->colors("ToolpathStart"));
    m_codeDrawer->setColorEnd(m_settings->colors("ToolpathEnd"));
    m_codeDrawer->setIgnoreZ(m_settings->grayscaleSegments() || !m_settings->drawModeVectors());
    m_codeDrawer->setGrayscaleSegments(m_settings->grayscaleSegments());
    m_codeDrawer->setGrayscaleCode(m_settings->grayscaleSCode() ? GcodeDrawer::S : GcodeDrawer::Z);
    m_codeDrawer->setDrawMode(m_settings->drawModeVectors() ? GcodeDrawer::Vectors : GcodeDrawer::Raster);
    m_codeDrawer->setGrayscaleMin(m_settings->laserPowerMin());
    m_codeDrawer->setGrayscaleMax(m_settings->laserPowerMax());
    m_codeDrawer->update();

    m_selectionDrawer.setColor(m_settings->colors("ToolpathHighlight"));

    // Axis A
    m_viewParser.setAxisRotationVector(
        GcodeViewParse::RotationAxisA,
        Util::rotationVector(m_settings->axisAEnabled()
            ? (m_settings->axisAX() ? Util::RotationVectorX : Util::RotationVectorY)
            : Util::RotationVectorNone)
    );
    // Conventional rotary-axis mapping: A rotates around X, B around Y.
    // Keep B disabled in the preview unless its axis is enabled in settings.
    m_viewParser.setAxisRotationVector(
        GcodeViewParse::RotationAxisB,
        Util::rotationVector(m_settings->axisBEnabled()
            ? Util::RotationVectorY
            : Util::RotationVectorNone)
    );
    // Phase 11: configurable preview pivots. Values are model-coordinate offsets;
    // defaults remain zero to preserve the legacy preview until calibrated.
    m_viewParser.setAxisRotationPivot(GcodeViewParse::RotationAxisA,
        QVector3D(m_settings->pivotAX(), m_settings->pivotAY(), m_settings->pivotAZ()));
    m_viewParser.setAxisRotationPivot(GcodeViewParse::RotationAxisB,
        QVector3D(m_settings->pivotBX(), m_settings->pivotBY(), m_settings->pivotBZ()));
    // Phase 12: draw independent A/B pivot rings and center marks in the 3D preview.
    m_rotaryPivotDrawer.setPivotA(
        QVector3D(m_settings->pivotAX(), m_settings->pivotAY(), m_settings->pivotAZ()));
    m_rotaryPivotDrawer.setPivotB(
        QVector3D(m_settings->pivotBX(), m_settings->pivotBY(), m_settings->pivotBZ()));
    m_rotaryPivotDrawer.setAxisAVisible(m_settings->axisAEnabled() && m_settings->showRotaryA());
    m_rotaryPivotDrawer.setAxisBVisible(m_settings->axisBEnabled() && m_settings->showRotaryB());
    m_rotaryPivotDrawer.setPlateSizeA(float(m_settings->rotaryAWidth()), float(m_settings->rotaryADepth()));
    m_rotaryPivotDrawer.setPlateSizeB(float(m_settings->rotaryBWidth()), float(m_settings->rotaryBDepth()));
    m_rotaryPivotDrawer.setWorkpieceA(float(m_settings->stockAWidth()), float(m_settings->stockADepth()), float(m_settings->stockAHeight()), m_settings->stockAShape());
    m_rotaryPivotDrawer.setWorkpieceB(float(m_settings->stockBWidth()), float(m_settings->stockBDepth()), float(m_settings->stockBHeight()), m_settings->stockBShape());
    ui->glwVisualizer->update();

    ui->lblPosA->setVisible(m_settings->axisAEnabled());
    ui->txtWPosA->setVisible(m_settings->axisAEnabled());
    ui->txtMPosA->setVisible(m_settings->axisAEnabled());

    ui->cmdAMinus->setVisible(m_settings->axisAEnabled());
    ui->cmdAPlusX->setVisible(m_settings->axisAEnabled() && m_settings->axisAX());
    ui->cmdAPlusY->setVisible(m_settings->axisAEnabled() && !m_settings->axisAX());

    // Axis B visibility is independently configurable.
    ui->lblPosB->setVisible(m_settings->axisBEnabled());
    ui->txtWPosB->setVisible(m_settings->axisBEnabled());
    ui->txtMPosB->setVisible(m_settings->axisBEnabled());
    ui->cmdBMinus->setVisible(m_settings->axisBEnabled());
    ui->cmdBPlus->setVisible(m_settings->axisBEnabled());

    ui->cmdAMinus->setIcon(m_settings->axisAX()
        ? QIcon(":/images/circle_down.png")
        : QIcon(":/images/circle_left.png")
    );

    // Adapt visualizer buttons colors
    const int LIGHTBOUND = 127;
    const int NORMALSHIFT = 40;
    const int HIGHLIGHTSHIFT = 80;

    QColor base = m_settings->colors("VisualizerBackground");
    bool light = base.value() > LIGHTBOUND;
    QColor normal, highlight;

    normal.setHsv(base.hue(), base.saturation(), base.value() + (light ? -NORMALSHIFT : NORMALSHIFT));
    highlight.setHsv(base.hue(), base.saturation(), base.value() + (light ? -HIGHLIGHTSHIFT : HIGHLIGHTSHIFT));

    ui->glwVisualizer->setStyleSheet(QString("QToolButton {border: 1px solid %1; \
                background-color: %3} QToolButton:hover {border: 1px solid %2;}")
                .arg(normal.name()).arg(highlight.name())
                .arg(base.name()));

    ui->cmdFit->setIcon(QIcon(":/images/fit_1.png"));
    ui->cmdIsometric->setIcon(QIcon(":/images/cube.png"));
    ui->cmdFront->setIcon(QIcon(":/images/cubeFront.png"));
    ui->cmdLeft->setIcon(QIcon(":/images/cubeLeft.png"));
    ui->cmdTop->setIcon(QIcon(":/images/cubeTop.png"));
    ui->cmdPerspective->setIcon(QIcon(":/images/perspective.png"));

    if (!light) {
        Util::invertButtonIconColors(ui->cmdFit);
        Util::invertButtonIconColors(ui->cmdIsometric);
        Util::invertButtonIconColors(ui->cmdFront);
        Util::invertButtonIconColors(ui->cmdLeft);
        Util::invertButtonIconColors(ui->cmdTop);
        Util::invertButtonIconColors(ui->cmdPerspective);
    }

    int h = ui->cmdFileOpen->sizeHint().height();
    QSize s(h, h);
    ui->cboCommand->setMinimumHeight(h);
    ui->cmdClearConsole->setFixedSize(s);
    ui->cmdCommandSend->setFixedSize(s);

    ui->spaJog->changeSize(0, ui->cboJogStep->height() / 2);

    // Visualizer buttons style
    int visualizerButtonSize = ui->cmdIsometric->minimumWidth();
    setStyleSheet(styleSheet() + QString("\n#fraProgram QToolButton {\n\
	    qproperty-iconSize: %1px;\n\
        }").arg(qRound(visualizerButtonSize * 0.7)));

    // Console buttons style
    int consoleButtonSize = ui->cmdCommandSend->minimumWidth();
    setStyleSheet(styleSheet() + QString("\n#fraConsole QPushButton {\n\
	    qproperty-iconSize: %1px;\n\
        }").arg(qRound(consoleButtonSize * 0.6)));

    // Apply port settings
    if ((m_settings->port() != m_serialPort.portName() || m_settings->baud() != m_serialPort.baudRate()))
    {
        if (m_serialPort.isOpen()) m_serialPort.close();
        m_serialPort.setPortName(m_settings->port());
        m_serialPort.setBaudRate(m_settings->baud());
        openPort();
    }

    updateControlsState();
}

void frmMain::loadPlugins()
{
    QString pluginsDir = qApp->applicationDirPath() + "/candleplugins/";

    // Get plugins list
    QStringList pl = QDir(pluginsDir).entryList(QDir::Dirs | QDir::NoDotAndDotDot);

    foreach (QString p, pl) {
        // Config
        QSettings set(pluginsDir + p + "/config.ini", QSettings::IniFormat);
        QString title = set.value("title").toString();
        QString name = set.value("name").toString();
        qInfo(generalLogCategory) << "Loading plugin path:" << p << "title:" << title << "name:" << name;

        // Translation
        QString loc = m_settings->language();
        QString translationFileName = pluginsDir + p + "/translation_" + loc + ".qm";
        if(QFile::exists(translationFileName)) {
            QTranslator *translator = new QTranslator();
            if (translator->load(translationFileName)) qApp->installTranslator(translator);
            else delete translator;
        }

        // Script
        QFile f;
        f.setFileName(pluginsDir + p + "/script.js");
        if (f.open(QFile::ReadOnly)) {
            QScriptEngine *se = new QScriptEngine();

            QScriptValue sv = se->newObject();
            sv.setProperty("importExtension", se->newFunction(frmMain::importExtension));
            sv.setProperty("path", pluginsDir + p);
            sv.setProperty("name", name);
            se->globalObject().setProperty("script", sv);
            se->setObjectName(p);
            connect(se, &QScriptEngine::signalHandlerException, this, &frmMain::onScriptException);

            // Delegate objects
            // App
            QScriptValue app = se->newQObject(m_scriptApp);
            app.setProperty("path", qApp->applicationDirPath());
            se->globalObject().setProperty("app", app);

            // Settings
            QScriptValue settings = se->newQObject(m_settings);
            app.setProperty("settings", settings);

            // Storage
            qScriptRegisterMetaType<StorageGroup*>(se,
            [](QScriptEngine *e, StorageGroup* const &g) {
                return e->newQObject(g, QScriptEngine::ScriptOwnership);
            },
            [](const QScriptValue &v, StorageGroup *&g) {
                g = qobject_cast<StorageGroup*>(v.toQObject());
            });

            QScriptValue storage = se->newQObject(&m_storage);
            app.setProperty("storage", storage);

            // TODO: remove
            // Stored vars
            QScriptValue vars = se->newQObject(&m_storedVars);
            se->globalObject().setProperty("vars", vars);

            // Translator
            se->installTranslatorFunctions();

            // Run script
            QString script = f.readAll();

            qInfo(generalLogCategory) << "Starting plugin path:" << p << "title:" << title << "name:" << name;

            sv = se->evaluate(script);
            if (sv.isError()) {
                qCritical(scriptLogCategory) << "Error evaluating plugin script" << sv.toString()
                    << se->uncaughtExceptionBacktrace();
            }

            // Init
            sv = se->evaluate("init()");
            if (sv.isError()) {
                qInfo(scriptLogCategory) << "Error evaluating init function" << sv.toString()
                    << se->uncaughtExceptionBacktrace();
            }

            // Panel widget
            sv = se->evaluate("createPanelWidget()");
            if (sv.isError()) {
                qInfo(scriptLogCategory) << "Error evaluating panel widget function" << sv.toString()
                    << se->uncaughtExceptionBacktrace();
            } else {
                QWidget *w = qobject_cast<QWidget*>(sv.toQObject());
                if (w) {
                    // Create panel
                    QGroupBox *box = new QGroupBox(this);
                    QVBoxLayout *layout1 = new QVBoxLayout(box);
                    QWidget *bw = new QWidget(box);
                    QVBoxLayout *layout2 = new QVBoxLayout(bw);
                    box->setObjectName("grp" + name);
                    box->setTitle(tr(title.toLatin1()));
                    box->setLayout(layout1);
                    box->setCheckable(true);
                    box->setProperty("overrided", false);
                    layout1->addWidget(bw);
                    bw->setLayout(layout2);
                    layout2->addWidget(w);
                    layout2->setMargin(0);
                    connect(box, &QGroupBox::toggled, bw, &QWidget::setVisible);

                    // Add panel to user window
                    static_cast<QVBoxLayout*>(ui->scrollContentsUser->layout())->insertWidget(0, box);
                }
            }

            // Window widget
            sv = se->evaluate("createWindowWidget()");
            if (sv.isError()) {
                qInfo(scriptLogCategory) << "Error evaluating window widget function" << sv.toString()
                    << se->uncaughtExceptionBacktrace();
            } else {
                QWidget *w = qobject_cast<QWidget*>(sv.toQObject());
                if (w) {
                    // Create dock widget
                    QDockWidget *dock = new QDockWidget(this);
                    QWidget *contents = new QWidget(dock);
                    QFrame *frame = new QFrame(contents);
                    QVBoxLayout *layout1 = new QVBoxLayout(contents);
                    QVBoxLayout *layout2 = new QVBoxLayout(frame);
                    dock->setObjectName("dock" + name);
                    dock->setWindowTitle(tr(title.toLatin1()));
                    dock->setWidget(contents);
                    contents->setLayout(layout1);
                    layout1->addWidget(frame);
                    QMargins m = layout1->contentsMargins();
                    m.setLeft(0);
                    m.setRight(0);
                    layout1->setContentsMargins(m);
                    frame->setLayout(layout2);
                    layout2->addWidget(w);
                    layout2->setMargin(0);

                    // Add to main form
                    this->addDockWidget(Qt::LeftDockWidgetArea, dock);
                }
            }

            // Settings widget
            sv = se->evaluate("createSettingsWidget()");
            if (sv.isError()) {
                qInfo(scriptLogCategory) << "Error evaluating settings widget function" << sv.toString()
                    << se->uncaughtExceptionBacktrace();
            } else {
                QWidget *w = qobject_cast<QWidget*>(sv.toQObject());
                if (w) {
                    // Create groupbox
                    QGroupBox *box = new QGroupBox(m_settings);
                    QVBoxLayout *layout1 = new QVBoxLayout(box);
                    box->setObjectName("grpSettings" + name);
                    box->setTitle(tr(title.toLatin1()));
                    box->setLayout(layout1);
                    layout1->addWidget(w);

                    // Add to settings form
                    m_settings->addCustomSettings(box);
                }
            }

            f.close();
        }
    }
}

void frmMain::openPort()
{
    if (m_serialPort.open(QIODevice::ReadWrite)) {
        ui->txtStatus->setText(tr("Port opened"));
        ui->txtStatus->setStyleSheet(QString("background-color: palette(button); color: palette(text);"));
        grblReset();
    }
}

void frmMain::grblReset()
{
    m_serialPort.write(QByteArray(1, (char)24));

    setSenderState(SenderStopped);
    setDeviceState(DeviceUnknown);
    m_fileCommandIndex = 0;

    m_reseting = true;
    m_homing = false;
    m_resetCompleted = false;
    m_updateSpindleSpeed = true;
    m_statusReceived = true;

    // Drop all remaining commands in buffer
    m_commands.clear();
    m_queue.clear();

    // Prepare reset response catch
    CommandAttributes ca;
    ca.command = "[CTRL+X]";
    if (m_settings->showUICommands()) ui->txtConsole->appendPlainText(ca.command);
    ca.consoleIndex = m_settings->showUICommands() ? ui->txtConsole->blockCount() - 1 : -1;
    ca.tableIndex = -1;
    ca.length = ca.command.length() + 1;
    m_commands.append(ca);

    updateControlsState();
}

frmMain::SendCommandResult frmMain::sendCommand(QString command, int tableIndex, bool showInConsole, bool wait)
{
    // tableIndex:
    // 0...n - commands from g-code program
    // -1 - ui commands
    // -2 - utility commands
    // -3 - utility commands

    if (!m_serialPort.isOpen() || !m_resetCompleted) return SendDone;

    // Check command
    if (command.isEmpty()) return SendEmpty;

    // Place to queue on 'wait' flag
    if (wait) {
        m_queue.append(CommandQueue(command, tableIndex, showInConsole));
        return SendQueue;
    }

    // Evaluate scripts in command
    if (tableIndex < 0) command = evaluateCommand(command);

    // Check evaluated command
    if (command.isEmpty()) return SendEmpty;

    // Place to queue if command buffer is full
    if ((bufferLength() + command.length() + 1) > BUFFERLENGTH) {
        m_queue.append(CommandQueue(command, tableIndex, showInConsole));
        return SendQueue;
    }

    command = command.toUpper();

    CommandAttributes ca;
    if (showInConsole) {
        ui->txtConsole->appendPlainText(command);
        ca.consoleIndex = ui->txtConsole->blockCount() - 1;
    } else {
        ca.consoleIndex = -1;
    }

    ca.command = command;
    ca.length = command.length() + 1;
    ca.tableIndex = tableIndex;

    m_commands.append(ca);

    QString uncomment = GcodePreprocessorUtils::removeComment(command);

    // Processing spindle speed only from g-code program
    static QRegExp s("[Ss]0*(\\d+)");
    if (s.indexIn(uncomment) != -1 && ca.tableIndex > -2) {
        int speed = s.cap(1).toInt();
        if (ui->slbSpindle->value() != speed) {
            ui->slbSpindle->setValue(speed);
        }
    }

    // Set M2 & M30 commands sent flag
    static QRegExp M230("(M0*2|M30|M0*6|M25)(?!\\d)");
    static QRegExp M6("(M0*6)(?!\\d)");
    if ((m_senderState == SenderTransferring) && uncomment.contains(M230)) {
        if (!uncomment.contains(M6) || m_settings->toolChangeUseCommands() || m_settings->toolChangePause()) setSenderState(SenderPausing);
    }

    // Queue offsets request on G92, G10 commands
    static QRegExp G92("(G92|G10)(?!\\d)");
    if (uncomment.contains(G92)) sendCommand("$#", -3, showInConsole, true);

    m_serialPort.write((command + "\r").toLatin1());

    return SendDone;
}

void frmMain::sendCommands(QString commands, int tableIndex)
{
    QStringList list = commands.split("\n");

    bool q = m_queue.size();
    foreach (QString cmd, list) {
        SendCommandResult r = sendCommand(cmd.trimmed(), tableIndex, m_settings->showUICommands(), q);
        if (r == SendDone || r == SendQueue) q = true;
    }
}

void frmMain::sendNextFileCommands() {
    if (m_queue.length() > 0) return;

    QString command = m_currentModel->data(m_currentModel->index(m_fileCommandIndex, 1)).toString();
    static QRegExp M230("(M0*2|M30|M0*6)(?!\\d)");

    while ((bufferLength() + command.length() + 1) <= BUFFERLENGTH
        && m_fileCommandIndex < m_currentModel->rowCount() - 1
        && !(!m_commands.isEmpty() && GcodePreprocessorUtils::removeComment(m_commands.last().command).contains(M230))
        )
    {
        m_currentModel->setData(m_currentModel->index(m_fileCommandIndex, 2), GCodeItem::Sent);
        sendCommand(command, m_fileCommandIndex, m_settings->showProgramCommands());
        m_fileCommandIndex++;
        command = m_currentModel->data(m_currentModel->index(m_fileCommandIndex, 1)).toString();
    }
}

QString frmMain::evaluateCommand(QString command)
{
    // Evaluate script  
    static QRegularExpression rx("\\{(?:(?>[^\\{\\}])|(?0))*\\}");
    QRegularExpressionMatch m;
    QScriptValue v;
    QString vs;

    while ((m = rx.match(command)).hasMatch()) {
        v = m_scriptEngine.evaluate(m.captured(0));
        vs = v.isUndefined() ? "" : v.isNumber() ? QString::number(v.toNumber(), 'f', 4) : v.toString();
        command.replace(m.captured(0), vs);
    }

    return command;
}

void frmMain::updateParser()
{
    ui->glwVisualizer->setUpdatesEnabled(false);

    GcodeViewParse *parser = m_currentDrawer->viewParser();

    GcodeParser gp;
    gp.setTraverseSpeed(m_settings->rapidSpeed());
    if (m_codeDrawer->getIgnoreZ()) gp.reset(QVector3D(qQNaN(), qQNaN(), 0));

    ui->tblProgram->setUpdatesEnabled(false);

    QString stripped;
    QList<QString> args;

    QProgressDialog progress(tr("Updating..."), tr("Abort"), 0, m_currentModel->rowCount() - 2, this);
    progress.setWindowModality(Qt::WindowModal);
    progress.setFixedSize(progress.sizeHint());

    if (m_currentModel->rowCount() > PROGRESSMINLINES) {
        progress.show();
        progress.setStyleSheet("QProgressBar {text-align: center; qproperty-format: \"\"}");
    }

    for (int i = 0; i < m_currentModel->rowCount() - 1; i++) {
        // Get stored args
        args = m_currentModel->data().at(i).args;

        // Store args if none
        if (args.isEmpty()) {
            stripped = GcodePreprocessorUtils::removeComment(m_currentModel->data().at(i).command);
            args = GcodePreprocessorUtils::splitCommand(stripped);
            m_currentModel->data()[i].args = args;
        }

        // Add command to parser
        gp.addCommand(args);

        // Update table model
        m_currentModel->data()[i].state = GCodeItem::InQueue;
        m_currentModel->data()[i].response = QString();
        m_currentModel->data()[i].line = gp.getCommandNumber();

        if (progress.isVisible() && (i % PROGRESSSTEP == 0)) {
            progress.setValue(i);
            qApp->processEvents();
            if (progress.wasCanceled()) break;
        }
    }
    progress.close();

    ui->tblProgram->setUpdatesEnabled(true);

    parser->reset();

    updateProgramEstimatedTime(parser->getLinesFromParser(&gp, m_settings->arcPrecision(), m_settings->arcDegreeMode()));
    m_currentDrawer->update();
    ui->glwVisualizer->updateModelBounds(m_currentDrawer);
    updateControlsState();

    if (m_currentModel == &m_programModel) m_fileChanged = true;

    ui->glwVisualizer->setUpdatesEnabled(!isMinimized() && ui->dockVisualizer->isVisible());
}

void frmMain::storeParserState()
{
    m_storedParserStatus = ui->glwVisualizer->parserStatus().remove(
                QRegExp("GC:|\\[|\\]|G[01234]\\s|M[0345]+\\s|\\sF[\\d\\.]+|\\sS[\\d\\.]+"));
}

void frmMain::restoreParserState()
{
    if (!m_storedParserStatus.isEmpty()) sendCommand(m_storedParserStatus, -1, m_settings->showUICommands());
}

void frmMain::restoreOffsets()
{
    // Still have pre-reset working position. Restore enabled rotary machine
    // coordinates as well as XYZ so an abort/reset does not silently discard
    // the independent A/B positions. Disabled rotary axes are never emitted.
    QString machinePosition = QString("%4G53G90X%1Y%2Z%3")
                                  .arg(ui->txtMPosX->value())
                                  .arg(ui->txtMPosY->value())
                                  .arg(ui->txtMPosZ->value())
                                  .arg(m_settings->units() ? "G20" : "G21");
    if (m_settings->axisAEnabled())
        machinePosition += QString("A%1").arg(ui->txtMPosA->value());
    if (m_settings->axisBEnabled())
        machinePosition += QString("B%1").arg(ui->txtMPosB->value());

    sendCommand(machinePosition, -2, m_settings->showUICommands());

    // Re-establish the saved work coordinates independently for A and B.
    QString workPosition = QString("%4G92X%1Y%2Z%3")
                               .arg(ui->txtWPosX->value())
                               .arg(ui->txtWPosY->value())
                               .arg(ui->txtWPosZ->value())
                               .arg(m_settings->units() ? "G20" : "G21");
    if (m_settings->axisAEnabled())
        workPosition += QString("A%1").arg(ui->txtWPosA->value());
    if (m_settings->axisBEnabled())
        workPosition += QString("B%1").arg(ui->txtWPosB->value());

    sendCommand(workPosition, -2, m_settings->showUICommands());
}

void frmMain::storeOffsetsVars(QString response)
{
    static QRegExp gx("\\[(G5[4-9]|G28|G30|G92|PRB):([\\d\\.\\-]+),([\\d\\.\\-]+),([\\d\\.\\-]+)");
    static QRegExp tx("\\[(TLO):([\\d\\.\\-]+)");

    // TODO: remove
    int p = 0;
    while ((p = gx.indexIn(response, p)) != -1) {
        m_storedVars.setCoords(gx.cap(1), QVector3D(
            gx.cap(2).toDouble(),
            gx.cap(3).toDouble(),
            gx.cap(4).toDouble()
        ));

        p += gx.matchedLength();
    }

    if (tx.indexIn(response) != -1) {
        m_storedVars.setCoords(tx.cap(1), QVector3D(
            0,
            0,
            tx.cap(2).toDouble()
        ));
    }
}

void frmMain::loadFile(QString fileName)
{
    QFile file(fileName);

    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, this->windowTitle(), tr("Can't open file:\n") + fileName);
        return;
    }

    // Set filename
    m_programFileName = fileName;

    // Prepare text stream
    QTextStream textStream(&file);

    // Read lines
    QList<QString> data;
    while (!textStream.atEnd()) data.append(textStream.readLine());

    // Load lines
    loadFile(data);
}

void frmMain::loadFile(QList<QString> data)
{
    // Reset tables
    clearTable();
    m_probeModel.clear();
    m_programHeightmapModel.clear();
    m_currentModel = &m_programModel;

    // Reset parsers
    m_viewParser.reset();
    m_probeParser.reset();

    // Reset code drawer
    m_currentDrawer = m_codeDrawer;
    m_codeDrawer->update();
    ui->glwVisualizer->fitDrawable(m_codeDrawer);
    ui->glwVisualizer->setUpdatesEnabled(false);
    updateProgramEstimatedTime(QList<LineSegment*>());

    // Update interface
    ui->chkHeightMapUse->setChecked(false);
    ui->grpHeightMap->setProperty("overrided", false);
    style()->unpolish(ui->grpHeightMap);
    ui->grpHeightMap->ensurePolished();

    // Reset tableview
    QByteArray headerState = ui->tblProgram->horizontalHeader()->saveState();
    ui->tblProgram->setModel(NULL);

    // Prepare parser
    GcodeParser gp;
    gp.setTraverseSpeed(m_settings->rapidSpeed());
    if (m_codeDrawer->getIgnoreZ()) gp.reset(QVector3D(qQNaN(), qQNaN(), 0));

    // Block parser updates on table changes
    m_programLoading = true;

    QString command;
    QString stripped;
    QString trimmed;
    QList<QString> args;
    GCodeItem item;

    // Prepare model
    m_programModel.data().clear();
    m_programModel.data().reserve(data.count());

    QProgressDialog progress(tr("Opening file..."), tr("Abort"), 0, data.count(), this);
    progress.setWindowModality(Qt::WindowModal);
    progress.setFixedSize(progress.sizeHint());
    if (data.count() > PROGRESSMINLINES) {
        progress.show();
        progress.setStyleSheet("QProgressBar {text-align: center; qproperty-format: \"\"}");
    }

    while (!data.isEmpty())
    {
        command = data.takeFirst();

        // Trim command
        trimmed = command.trimmed();

        if (!trimmed.isEmpty()) {
            // Split command
            stripped = GcodePreprocessorUtils::removeComment(command);
            args = GcodePreprocessorUtils::splitCommand(stripped);

            gp.addCommand(args);

            item.command = trimmed;
            item.state = GCodeItem::InQueue;
            item.line = gp.getCommandNumber();
            item.args = args;

            m_programModel.data().append(item);
        }

        if (progress.isVisible() && (data.count() % PROGRESSSTEP == 0)) {
            progress.setValue(progress.maximum() - data.count());
            qApp->processEvents();
            if (progress.wasCanceled()) break;
        }
    }
    progress.close();

    m_programModel.insertRow(m_programModel.rowCount());

    updateProgramEstimatedTime(m_viewParser.getLinesFromParser(&gp, m_settings->arcPrecision(), m_settings->arcDegreeMode()));

    m_programLoading = false;

    // Set table model
    ui->tblProgram->setModel(&m_programModel);
    ui->tblProgram->horizontalHeader()->restoreState(headerState);

    // Update tableview
    connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));
    ui->tblProgram->selectRow(0);

    //  Update code drawer
    m_codeDrawer->update();
    ui->glwVisualizer->fitDrawable(m_codeDrawer);
    ui->glwVisualizer->setUpdatesEnabled(!isMinimized() && ui->dockVisualizer->isVisible());

    resetHeightmap();
    updateControlsState();
}

bool frmMain::saveChanges(bool heightMapMode)
{
    if ((!heightMapMode && m_fileChanged)) {
        int res = QMessageBox::warning(this, this->windowTitle(), tr("G-code program file was changed. Save?"),
                                       QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        if (res == QMessageBox::Cancel) return false;
        else if (res == QMessageBox::Yes) on_actFileSave_triggered();
        m_fileChanged = false;
    }

    if (m_heightMapChanged) {
        int res = QMessageBox::warning(this, this->windowTitle(), tr("Heightmap file was changed. Save?"),
                                       QMessageBox::Yes | QMessageBox::No | QMessageBox::Cancel);
        if (res == QMessageBox::Cancel) return false;
        else if (res == QMessageBox::Yes) {
            m_heightMapMode = true;
            on_actFileSave_triggered();
            m_heightMapMode = heightMapMode;
            updateRecentFilesMenu(); // Restore g-code files recent menu
        }

        m_fileChanged = false;
    }

    return true;
}

bool frmMain::saveProgramToFile(QString fileName, GCodeTableModel *model)
{
    QFile file(fileName);
    QDir dir;

    if (file.exists()) dir.remove(file.fileName());
    if (!file.open(QIODevice::WriteOnly)) return false;

    QTextStream textStream(&file);

    for (int i = 0; i < model->rowCount() - 1; i++) {
        textStream << model->data(model->index(i, 1)).toString() << "\r\n";
    }

    file.close();

    return true;
}

void frmMain::loadHeightMap(QString fileName)
{
    QFile file(fileName);

    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, this->windowTitle(), tr("Can't open file:\n") + fileName);
        return;
    }

    QTextStream textStream(&file);
    auto signature = textStream.readLine();
    if (signature != "candle map v2") {
        QMessageBox::critical(this, this->windowTitle(), tr("Can't open file:\n") + fileName);
        file.close();
        return;
    }

    m_settingsLoading = true;

    // Storing previous values
    ui->txtHeightMapBorderX->setValue(qQNaN());
    ui->txtHeightMapBorderY->setValue(qQNaN());
    ui->txtHeightMapBorderWidth->setValue(qQNaN());
    ui->txtHeightMapBorderHeight->setValue(qQNaN());

    ui->txtHeightMapOriginX->setValue(qQNaN());
    ui->txtHeightMapOriginY->setValue(qQNaN());

    ui->txtHeightMapGridX->setValue(qQNaN());
    ui->txtHeightMapGridY->setValue(qQNaN());
    ui->txtHeightMapGridZBottom->setValue(qQNaN());
    ui->txtHeightMapGridZTop->setValue(qQNaN());

    QList<QString> list = textStream.readLine().split(";");
    ui->txtHeightMapBorderX->setValue(list[0].toDouble());
    ui->txtHeightMapBorderY->setValue(list[1].toDouble());
    ui->txtHeightMapBorderWidth->setValue(list[2].toDouble());
    ui->txtHeightMapBorderHeight->setValue(list[3].toDouble());

    list = textStream.readLine().split(";");
    ui->txtHeightMapOriginX->setValue(list[0].toDouble());
    ui->txtHeightMapOriginY->setValue(list[1].toDouble());

    list = textStream.readLine().split(";");
    ui->txtHeightMapGridX->setValue(list[0].toDouble());
    ui->txtHeightMapGridY->setValue(list[1].toDouble());
    ui->txtHeightMapGridZBottom->setValue(list[2].toDouble());
    ui->txtHeightMapGridZTop->setValue(list[3].toDouble());

    m_settingsLoading = false;

    updateHeightMapBorderDrawer();

    m_heightMapModel.clear();   // To avoid probe data wipe message
    updateHeightMapGrid();

    list = textStream.readLine().split(";");

    for (int i = 0; i < m_heightMapModel.rowCount(); i++) {
        QList<QString> row = textStream.readLine().split(";");
        for (int j = 0; j < m_heightMapModel.columnCount(); j++) {
            m_heightMapModel.setData(m_heightMapModel.index(i, j), row[j].toDouble(), Qt::UserRole);
        }
    }

    file.close();

    ui->txtHeightMap->setText(fileName.mid(fileName.lastIndexOf("/") + 1));
    m_heightMapFileName = fileName;
    m_heightMapChanged = false;

    ui->cboHeightMapInterpolationType->setCurrentIndex(list[0].toInt());
    ui->txtHeightMapInterpolationStepX->setValue(list[1].toDouble());
    ui->txtHeightMapInterpolationStepY->setValue(list[2].toDouble());

    updateHeightMapInterpolationDrawer();
}

bool frmMain::saveHeightMap(QString fileName)
{
    QFile file(fileName);
    QDir dir;

    if (file.exists()) dir.remove(file.fileName());
    if (!file.open(QIODevice::WriteOnly)) return false;

    QTextStream textStream(&file);
    textStream << "candle map v2\r\n";
    textStream << ui->txtHeightMapBorderX->text() << ";"
               << ui->txtHeightMapBorderY->text() << ";"
               << ui->txtHeightMapBorderWidth->text() << ";"
               << ui->txtHeightMapBorderHeight->text() << "\r\n";
    textStream << ui->txtHeightMapOriginX->text() << ";"
               << ui->txtHeightMapOriginY->text() << "\r\n";
    textStream << ui->txtHeightMapGridX->text() << ";"
               << ui->txtHeightMapGridY->text() << ";"
               << ui->txtHeightMapGridZBottom->text() << ";"
               << ui->txtHeightMapGridZTop->text() << "\r\n";
    textStream << ui->cboHeightMapInterpolationType->currentIndex() << ";"
               << ui->txtHeightMapInterpolationStepX->text() << ";"
                << ui->txtHeightMapInterpolationStepY->text() << "\r\n";

    for (int i = 0; i < m_heightMapModel.rowCount(); i++) {
        for (int j = 0; j < m_heightMapModel.columnCount(); j++) {
            textStream << m_heightMapModel.data(m_heightMapModel.index(i, j), Qt::UserRole).toString() << ((j == m_heightMapModel.columnCount() - 1) ? "" : ";");
        }
        textStream << "\r\n";
    }

    file.close();

    m_heightMapChanged = false;

    return true;
}

void frmMain::clearTable()
{
    m_programModel.clear();
    m_programModel.insertRow(0);
}

void frmMain::resetHeightmap()
{
    delete m_heightMapInterpolationDrawer.data();
    m_heightMapInterpolationDrawer.setData(NULL);

    ui->tblHeightMap->setModel(NULL);
    m_heightMapModel.resize(1, 1);

    ui->txtHeightMap->clear();
    m_heightMapFileName.clear();
    m_heightMapChanged = false;
}

void frmMain::newFile()
{
    // Reset tables
    clearTable();
    m_probeModel.clear();
    m_programHeightmapModel.clear();
    m_currentModel = &m_programModel;

    // Reset parsers
    m_viewParser.reset();
    m_probeParser.reset();

    // Reset code drawer
    m_codeDrawer->update();
    m_currentDrawer = m_codeDrawer;
    ui->glwVisualizer->fitDrawable();
    updateProgramEstimatedTime(QList<LineSegment*>());

    m_programFileName = "";
    ui->chkHeightMapUse->setChecked(false);
    ui->grpHeightMap->setProperty("overrided", false);
    style()->unpolish(ui->grpHeightMap);
    ui->grpHeightMap->ensurePolished();

    // Reset tableview
    QByteArray headerState = ui->tblProgram->horizontalHeader()->saveState();
    ui->tblProgram->setModel(NULL);

    // Set table model
    ui->tblProgram->setModel(&m_programModel);
    ui->tblProgram->horizontalHeader()->restoreState(headerState);

    // Update tableview
    connect(ui->tblProgram->selectionModel(), SIGNAL(currentChanged(QModelIndex,QModelIndex)), this, SLOT(onTableCurrentChanged(QModelIndex,QModelIndex)));
    ui->tblProgram->selectRow(0);

    // Clear selection marker
    m_selectionDrawer.setVisible(false);

    resetHeightmap();

    updateControlsState();
}

void frmMain::newHeightmap()
{
    m_heightMapModel.clear();
    on_cmdFileReset_clicked();
    ui->txtHeightMap->setText(tr("Untitled"));
    m_heightMapFileName.clear();

    updateHeightMapBorderDrawer();
    updateHeightMapGrid();

    m_heightMapChanged = false;

    updateControlsState();
}

void frmMain::setupCoordsTextboxes()
{
    int prec = m_settings->units() == 0 ? 3 : 4;
    int bound = m_settings->units() == 0 ? 9999 : 999;

    ui->txtMPosX->setDecimals(prec);
    ui->txtMPosX->setMinimum(-bound);
    ui->txtMPosX->setMaximum(bound);
    ui->txtMPosY->setDecimals(prec);
    ui->txtMPosY->setMinimum(-bound);
    ui->txtMPosY->setMaximum(bound);
    ui->txtMPosZ->setDecimals(prec);
    ui->txtMPosZ->setMinimum(-bound);
    ui->txtMPosZ->setMaximum(bound);

    ui->txtWPosX->setDecimals(prec);
    ui->txtWPosX->setMinimum(-bound);
    ui->txtWPosX->setMaximum(bound);
    ui->txtWPosY->setDecimals(prec);
    ui->txtWPosY->setMinimum(-bound);
    ui->txtWPosY->setMaximum(bound);
    ui->txtWPosZ->setDecimals(prec);
    ui->txtWPosZ->setMinimum(-bound);
    ui->txtWPosZ->setMaximum(bound);
}

void frmMain::updateControlsState() {
    bool portOpened = m_serialPort.isOpen();
    bool process = (m_senderState == SenderTransferring) || (m_senderState == SenderStopping);
    bool paused = (m_senderState == SenderPausing) || (m_senderState == SenderPaused) || (m_senderState == SenderChangingTool);

    ui->grpState->setEnabled(portOpened);
    ui->grpControl->setEnabled(portOpened);
    ui->widgetSpindle->setEnabled(portOpened);
    ui->widgetJog->setEnabled(portOpened && ((m_senderState == SenderStopped)
        || (m_senderState == SenderChangingTool)));
    ui->cboCommand->setEnabled(portOpened && (!ui->chkKeyboardControl->isChecked()));
    ui->cmdCommandSend->setEnabled(portOpened);

    ui->cmdCheck->setEnabled(portOpened && !process);
    ui->cmdHome->setEnabled(!process);
    ui->cmdCheck->setEnabled(!process);
    ui->cmdUnlock->setEnabled(!process);
    ui->cmdSpindle->setEnabled(!process);
    ui->cmdSleep->setEnabled(!process);

    ui->actFileNew->setEnabled(m_senderState == SenderStopped);
    ui->actFileOpen->setEnabled(m_senderState == SenderStopped);
    ui->actFileReload->setEnabled(m_senderState == SenderStopped
        && (m_heightMapMode ? !m_heightMapFileName.isEmpty(): !m_programFileName.isEmpty()));
    ui->cmdFileOpen->setEnabled(m_senderState == SenderStopped);
    ui->cmdFileReset->setEnabled((m_senderState == SenderStopped) && m_programModel.rowCount() > 1);
    ui->cmdFileSend->setEnabled(portOpened && (m_senderState == SenderStopped) && m_programModel.rowCount() > 1);
    ui->cmdFilePause->setEnabled(portOpened && (process || paused) && (m_senderState != SenderPausing));
    ui->cmdFilePause->setChecked(paused);
    ui->cmdFileAbort->setEnabled(m_senderState != SenderStopped && m_senderState != SenderStopping);
    ui->mnuRecent->setEnabled((m_senderState == SenderStopped) && ((m_recentFiles.count() > 0 && !m_heightMapMode)
                                                      || (m_recentHeightmaps.count() > 0 && m_heightMapMode)));
    ui->actFileSave->setEnabled(m_programModel.rowCount() > 1);
    ui->actFileSaveAs->setEnabled(m_programModel.rowCount() > 1);

    ui->tblProgram->setEditTriggers((m_senderState != SenderStopped) ? QAbstractItemView::NoEditTriggers :
        QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked |
        QAbstractItemView::EditKeyPressed | QAbstractItemView::AnyKeyPressed);

    if (!portOpened) {
        ui->txtStatus->setText(tr("Not connected"));
        ui->txtStatus->setStyleSheet(QString("background-color: palette(button); color: palette(text);"));
        emit deviceStateChanged(-1);
    }

    this->setWindowTitle(m_programFileName.isEmpty()
        ? m_currentProfileName + " - " + qApp->applicationDisplayName()
        : m_programFileName.mid(m_programFileName.lastIndexOf("/") + 1) + " - " + m_currentProfileName
            + " - " + qApp->applicationDisplayName());

    if (!process) ui->chkKeyboardControl->setChecked(m_storedKeyboardControl);

#ifdef WINDOWS
    if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
        if (m_taskBarProgress) m_taskBarProgress->setPaused(paused);
    }

    if (QSysInfo::windowsVersion() >= QSysInfo::WV_WINDOWS7) {
        if (m_taskBarProgress && m_senderState == SenderStopped) m_taskBarProgress->hide();
    }
#endif

    style()->unpolish(ui->cmdFileOpen);
    style()->unpolish(ui->cmdFileReset);
    style()->unpolish(ui->cmdFileSend);
    style()->unpolish(ui->cmdFilePause);
    style()->unpolish(ui->cmdFileAbort);
    ui->cmdFileOpen->ensurePolished();
    ui->cmdFileReset->ensurePolished();
    ui->cmdFileSend->ensurePolished();
    ui->cmdFilePause->ensurePolished();
    ui->cmdFileAbort->ensurePolished();

    // Heightmap
    m_heightMapBorderDrawer.setVisible(ui->chkHeightMapBorderShow->isChecked() && m_heightMapMode);
    m_heightMapOriginDrawer.setVisible(ui->chkHeightMapOriginShow->isChecked() && m_heightMapMode);
    m_heightMapGridDrawer.setVisible(ui->chkHeightMapGridShow->isChecked() && m_heightMapMode);
    m_heightMapInterpolationDrawer.setVisible(ui->chkHeightMapInterpolationShow->isChecked() && m_heightMapMode);

    ui->grpProgram->setText(m_heightMapMode ? tr("Heightmap") : tr("G-code program"));
    ui->grpProgram->setProperty("overrided", m_heightMapMode);
    style()->unpolish(ui->grpProgram);
    ui->grpProgram->ensurePolished();

    ui->cboJogStep->setEditable(!ui->chkKeyboardControl->isChecked());
    ui->cboJogFeed->setEditable(!ui->chkKeyboardControl->isChecked());
    ui->cboJogStep->setEnabled(!ui->chkKeyboardControl->isChecked());
    ui->cboJogFeed->setEnabled(!ui->chkKeyboardControl->isChecked());
    ui->cboJogStep->setStyleSheet(QString("font-size: %1").arg(m_settings->fontSize()));
    ui->cboJogFeed->setStyleSheet(ui->cboJogStep->styleSheet());

    ui->tblHeightMap->setVisible(m_heightMapMode);
    ui->tblProgram->setVisible(!m_heightMapMode);

    ui->widgetHeightMap->setEnabled(!process && m_programModel.rowCount() > 1
        && !m_currentDrawer->viewParser()->axisRotationUsed(GcodeViewParse::RotationAxisA));
    ui->cmdHeightMapMode->setEnabled(!ui->txtHeightMap->text().isEmpty());
    ui->cmdHeightMapOrigin->setEnabled(!ui->txtHeightMap->text().isEmpty() && portOpened && !process);

    ui->cmdFileSend->setText(m_heightMapMode ? tr("Probe") : tr("Send"));

    ui->chkHeightMapUse->setEnabled(!m_heightMapMode && !ui->txtHeightMap->text().isEmpty());

    ui->actFileSaveTransformedAs->setVisible(ui->chkHeightMapUse->isChecked());

    ui->cmdFileSend->menu()->actions().first()->setEnabled(!ui->cmdHeightMapMode->isChecked());
}

void frmMain::updateLayouts()
{
    this->update();
    qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
}

void frmMain::updateRecentFilesMenu()
{
    foreach (QAction * action, ui->mnuRecent->actions()) {
        if (action->text() == "") break; else {
            ui->mnuRecent->removeAction(action);
            delete action;
        }
    }

    foreach (QString file, !m_heightMapMode ? m_recentFiles : m_recentHeightmaps) {
        QAction *action = new QAction(file, this);
        connect(action, SIGNAL(triggered()), this, SLOT(onActRecentFileTriggered()));
        ui->mnuRecent->insertAction(ui->mnuRecent->actions()[0], action);
    }

    updateControlsState();
}

void frmMain::updateOverride(SliderBox *slider, int value, char command)
{
    slider->setCurrentValue(value);

    int target = slider->isChecked() ? slider->value() : 100;
    bool smallStep = abs(target - slider->currentValue()) < 10 || m_settings->queryStateTime() < 100;

    if (slider->currentValue() < target) {
        m_serialPort.write(QByteArray(1, char(smallStep ? command + 2 : command)));
    } else if (slider->currentValue() > target) {
        m_serialPort.write(QByteArray(1, char(smallStep ? command + 3 : command + 1)));
    }
}

void frmMain::updateJogTitle()
{
    if (ui->grpJog->isChecked() || !ui->chkKeyboardControl->isChecked()) {
        ui->grpJog->setTitle(tr("Jog"));
    } else if (ui->chkKeyboardControl->isChecked()) {
        ui->grpJog->setTitle(tr("Jog") + QString(tr(" (%1/%2)"))
                             .arg(ui->cboJogStep->currentText().toDouble() > 0 ? ui->cboJogStep->currentText() : tr("C"))
                             .arg(ui->cboJogFeed->currentText()));
    }
}

void frmMain::addRecentFile(QString fileName)
{
    m_recentFiles.removeAll(fileName);
    m_recentFiles.append(fileName);
    if (m_recentFiles.count() > 5) m_recentFiles.takeFirst();
}

void frmMain::addRecentHeightmap(QString fileName)
{
    m_recentHeightmaps.removeAll(fileName);
    m_recentHeightmaps.append(fileName);
    if (m_recentHeightmaps.count() > 5) m_recentHeightmaps.takeFirst();
}

QRectF frmMain::borderRectFromTextboxes()
{
    QRectF rect;

    rect.setX(ui->txtHeightMapBorderX->value());
    rect.setY(ui->txtHeightMapBorderY->value());
    rect.setWidth(ui->txtHeightMapBorderWidth->value());
    rect.setHeight(ui->txtHeightMapBorderHeight->value());

    return rect;
}

QRectF frmMain::borderRectFromExtremes()
{
    QRectF rect;

    rect.setX(m_codeDrawer->getViewLowerBounds().x());
    rect.setY(m_codeDrawer->getViewLowerBounds().y());
    rect.setWidth(m_codeDrawer->getViewRanges().x());
    rect.setHeight(m_codeDrawer->getViewRanges().y());

    return rect;
}

void frmMain::updateHeightMapBorderDrawer()
{
    if (m_settingsLoading) return;

    m_heightMapBorderDrawer.setBorderRect(borderRectFromTextboxes());
}

bool frmMain::updateHeightMapGrid()
{
    if (m_settingsLoading) return true;

    // Grid map changing warning
    bool nan = true;
    for (int i = 0; i < m_heightMapModel.rowCount(); i++)
        for (int j = 0; j < m_heightMapModel.columnCount(); j++)
            if (!qIsNaN(m_heightMapModel.data(m_heightMapModel.index(i, j), Qt::UserRole).toDouble())) {
                nan = false;
                break;
            }
    if (!nan && QMessageBox::warning(this, this->windowTitle(), tr("Changing grid settings will reset probe data. Continue?"),
                                                           QMessageBox::Yes | QMessageBox::No) == QMessageBox::No) return false;

    // Update grid drawer
    QRectF borderRect = borderRectFromTextboxes();
    m_heightMapGridDrawer.setBorderRect(borderRect);
    m_heightMapGridDrawer.setGridSize(QPointF(ui->txtHeightMapGridX->value(), ui->txtHeightMapGridY->value()));
    m_heightMapGridDrawer.setZBottom(ui->txtHeightMapGridZBottom->value());
    m_heightMapGridDrawer.setZTop(ui->txtHeightMapGridZTop->value());

    // Update origin drawer
    m_heightMapOriginDrawer.setTranslation(QVector3D(ui->txtHeightMapOriginX->value(), ui->txtHeightMapOriginY->value(), 0.0));

    // Reset model
    int gridPointsX = ui->txtHeightMapGridX->value();
    int gridPointsY = ui->txtHeightMapGridY->value();

    m_heightMapModel.resize(gridPointsX, gridPointsY);
    ui->tblHeightMap->setModel(NULL);
    ui->tblHeightMap->setModel(&m_heightMapModel);
    resizeTableHeightMapSections();

    // Update interpolation
    updateHeightMapInterpolationDrawer(true);

    // Generate probe program
    double gridStepX = gridPointsX > 1 ? borderRect.width() / (gridPointsX - 1) : 0;
    double gridStepY = gridPointsY > 1 ? borderRect.height() / (gridPointsY - 1) : 0;

    m_programLoading = true;
    m_probeModel.clear();
    m_probeModel.insertRow(0);

    m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G21G90F%1")
                        .arg(ui->txtHeightMapProbeFeed->value()));
    m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G0X%1Y%2")
                        .arg(ui->txtHeightMapOriginX->value())
                        .arg(ui->txtHeightMapOriginY->value()));
    m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G0Z%1")
                        .arg(ui->txtHeightMapGridZTop->value()));
    m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G38.2Z%1")
                        .arg(ui->txtHeightMapGridZBottom->value()));
    m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G0Z%1")
                        .arg(ui->txtHeightMapGridZTop->value()));

    double x, y;

    for (int i = 0; i < gridPointsY; i++) {
        y = borderRect.top() + gridStepY * i;
        for (int j = 0; j < gridPointsX; j++) {
            x = borderRect.left() + gridStepX * (i % 2 ? gridPointsX - 1 - j : j);
            m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G0X%1Y%2")
                                 .arg(x, 0, 'f', 3).arg(y, 0, 'f', 3));
            m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G38.2Z%1")
                                 .arg(ui->txtHeightMapGridZBottom->value()));
            m_probeModel.setData(m_probeModel.index(m_probeModel.rowCount() - 1, 1), QString("G0Z%1")
                                 .arg(ui->txtHeightMapGridZTop->value()));
        }
    }

    m_programLoading = false;

    if (m_currentDrawer == m_probeDrawer) updateParser();

    m_heightMapChanged = true;
    return true;
}

void frmMain::updateHeightMapGrid(double arg1)
{
    if (sender()->property("previousValue").toDouble() != arg1 && !updateHeightMapGrid())
        static_cast<QDoubleSpinBox*>(sender())->setValue(sender()->property("previousValue").toDouble());
    else sender()->setProperty("previousValue", arg1);
}

void frmMain::resizeTableHeightMapSections()
{
    if (ui->tblHeightMap->horizontalHeader()->defaultSectionSize()
            * ui->tblHeightMap->horizontalHeader()->count() < ui->glwVisualizer->width())
        ui->tblHeightMap->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); else {
        ui->tblHeightMap->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
    }
}

void frmMain::scrollToTableIndex(QModelIndex index)
{
    static const int INTERVAL = 40;
    static QElapsedTimer intervalTimer;
    static QTimer *pendingTimer = nullptr;
    static QModelIndex pendingIndex;

    if (!pendingTimer) {
        pendingTimer = new QTimer(this);
        pendingTimer->setSingleShot(true);
        pendingTimer->setInterval(INTERVAL * 2);
        connect(pendingTimer, &QTimer::timeout, [=] {
            ui->tblProgram->scrollTo(pendingIndex);
            ui->tblProgram->setCurrentIndex(pendingIndex);
            intervalTimer.start();
        });
    }

    if (!intervalTimer.isValid() || intervalTimer.hasExpired(INTERVAL)) {
        pendingTimer->stop();
        intervalTimer.start();
        ui->tblProgram->scrollTo(index);
        ui->tblProgram->setCurrentIndex(index);
    } else {
        pendingIndex = index;
        pendingTimer->start();
    }
}

bool frmMain::eventFilter(QObject *obj, QEvent *event)
{
    if (obj->inherits("QWidgetWindow")) {

        // Jog on keyboard control
        QKeySequence ks;
        QKeyEvent *ev = static_cast<QKeyEvent*>(event);

        if ((event->type() == QEvent::ShortcutOverride || event->type() == QEvent::KeyRelease)) {
            if (ev->key() == Qt::Key_Shift) {
                ks = QKeySequence(Qt::ShiftModifier);
            } else if (ev->key() == Qt::Key_Control) {
                ks = QKeySequence(Qt::ControlModifier);
            } else if (ev->key() == Qt::Key_Alt) {
                ks = QKeySequence(Qt::AltModifier);
            } else {
                ks = QKeySequence(ev->key() | ev->modifiers());
            }
        }

        if ((m_senderState != SenderTransferring) && (m_senderState != SenderStopping)
            && ui->chkKeyboardControl->isChecked() && !ev->isAutoRepeat())
        {
            static QList<QAction*> acts;
            if (acts.isEmpty()) acts << ui->actJogXMinus << ui->actJogXPlus
                                     << ui->actJogYMinus << ui->actJogYPlus
                                     << ui->actJogZMinus << ui->actJogZPlus
                                     << ui->actJogAMinus << ui->actJogAPlus << ui->actJogAPlus;

            static QList<QAbstractButton*> buttons;
            if (buttons.isEmpty()) buttons << ui->cmdXMinus << ui->cmdXPlus
                                           << ui->cmdYMinus << ui->cmdYPlus
                                           << ui->cmdZMinus << ui->cmdZPlus
                                           << ui->cmdAMinus << ui->cmdAPlusX << ui->cmdAPlusY;

            for (int i = 0; i < acts.count(); i++) {
                if ((!buttons.at(i)->isDown()) && (event->type() == QEvent::ShortcutOverride)) {
                    if (acts.at(i)->shortcut().matches(ks) == QKeySequence::ExactMatch) {
                        buttons.at(i)->pressed();
                        buttons.at(i)->setDown(true);
                    }
                } else if (buttons.at(i)->isDown() && (event->type() == QEvent::KeyRelease)) {
                    if ((acts.at(i)->shortcut().matches(ks) == QKeySequence::ExactMatch)
                        || (acts.at(i)->shortcut().toString().contains(ks.toString()))
                        || (ks.toString().contains(acts.at(i)->shortcut().toString()))
                        )
                    {
                        buttons.at(i)->released();
                        buttons.at(i)->setDown(false);
                    }
                }
            }
        }
    } else if (obj == ui->tblProgram && ((m_senderState == SenderTransferring) || (m_senderState == SenderStopping))) {
        QKeyEvent *keyEvent = static_cast<QKeyEvent*>(event);
        if (keyEvent->key() == Qt::Key_PageDown || keyEvent->key() == Qt::Key_PageUp
                    || keyEvent->key() == Qt::Key_Down || keyEvent->key() == Qt::Key_Up) {
            ui->chkAutoScroll->setChecked(false);
        }
    }

    // Visualizer updates
    if (obj == this && event->type() == QEvent::WindowStateChange) {
        ui->glwVisualizer->setUpdatesEnabled(!isMinimized() && ui->dockVisualizer->isVisible());
    }

    // Drag & drop panels
    if (!ui->actViewLockPanels->isChecked() && obj->inherits("QGroupBox")
        && (obj->parent()->objectName() == "scrollContentsDevice"
        || obj->parent()->objectName() == "scrollContentsModification"
        || obj->parent()->objectName() == "scrollContentsUser")
        && obj->objectName().startsWith("grp")) {

        if (event->type() == QEvent::MouseButtonPress) {

            QMouseEvent *e = static_cast<QMouseEvent*>(event);
            m_mousePressPos = e->pos();

        } else if (event->type() == QEvent::MouseMove) {

            QMouseEvent *e = static_cast<QMouseEvent*>(event);
            int d = (e->pos() - m_mousePressPos).manhattanLength();

            if (e->buttons() & Qt::LeftButton && d > QApplication::startDragDistance()) {
                QDrag *drag = new QDrag(this);
                WidgetMimeData *mimeData = new WidgetMimeData();

                mimeData->setWidget(static_cast<QWidget*>(obj));

                QPixmap *pix = new QPixmap(static_cast<QWidget*>(obj)->size());
                static_cast<QWidget*>(obj)->render(pix);

                drag->setMimeData(mimeData);
                drag->setPixmap(*pix);
                drag->exec();
            }
        }
    }

    return QMainWindow::eventFilter(obj, event);
}

int frmMain::bufferLength()
{
    int length = 0;

    foreach (CommandAttributes ca, m_commands) {
        length += ca.length;
    }

    return length;
}

bool frmMain::dataIsFloating(QString data) {
    QStringList ends;

    ends << "Reset to continue";
    ends << "'$H'|'$X' to unlock";
    ends << "ALARM: Soft limit";
    ends << "ALARM: Hard limit";
    ends << "Check Door";

    foreach (QString str, ends) {
        if (data.contains(str)) return true;
    }

    return false;
}

bool frmMain::dataIsEnd(QString data) {
    QStringList ends;

    ends << "ok";
    ends << "error";

    foreach (QString str, ends) {
        if (data.contains(str)) return true;
    }

    return false;
}

bool frmMain::dataIsReset(QString data) {
    return QRegExp("^GRBL|GCARVIN\\s\\d\\.\\d.").indexIn(data.toUpper()) != -1;
}

QTime frmMain::updateProgramEstimatedTime(QList<LineSegment*> lines)
{
    // Phase 19: mirror parsed A/B rotary moves into the independent preview
    // drawer. It stores value copies, never pointers owned by the parser.
    m_rotaryPivotDrawer.setToolpath(lines);
    double time = 0;

    for (int i = 0; i < lines.count(); i++) {
        LineSegment *ls = lines[i];
        double length = !m_viewParser.axisRotationUsed(GcodeViewParse::RotationAxisA)
            ? (ls->getEnd() - ls->getStart()).length()
            : (QVector4D(ls->getEnd(), ls->axesEnd().x()) - QVector4D(ls->getStart(), ls->axesStart().x())).length();

        if (!qIsNaN(length) && !qIsNaN(ls->getSpeed()) && ls->getSpeed() != 0) time +=
                length / ((ui->slbFeedOverride->isChecked() && !ls->isFastTraverse())
                          ? (ls->getSpeed() * ui->slbFeedOverride->value() / 100) :
                            (ui->slbRapidOverride->isChecked() && ls->isFastTraverse())
                             ? (ls->getSpeed() * ui->slbRapidOverride->value() / 100) : ls->getSpeed());
    }

    time *= 60;

    QTime t;

    t.setHMS(0, 0, 0);
    t = t.addSecs(time);

    ui->glwVisualizer->setSpendTime(QTime(0, 0, 0));
    ui->glwVisualizer->setEstimatedTime(t);

    return t;
}

QList<LineSegment*> frmMain::subdivideSegment(LineSegment* segment)
{
    QList<LineSegment*> list;

    QRectF borderRect = borderRectFromTextboxes();

    double interpolationStepX = borderRect.width() / (ui->txtHeightMapInterpolationStepX->value() - 1);
    double interpolationStepY = borderRect.height() / (ui->txtHeightMapInterpolationStepY->value() - 1);

    double length;

    QVector3D vec = segment->getEnd() - segment->getStart();

    if (qIsNaN(vec.length())) return QList<LineSegment*>();

    if (fabs(vec.x()) / fabs(vec.y()) < interpolationStepX / interpolationStepY) length = interpolationStepY / (vec.y() / vec.length());
    else length = interpolationStepX / (vec.x() / vec.length());

    length = fabs(length);

    if (qIsNaN(length)) {
        return QList<LineSegment*>();
    }

    QVector3D seg = vec.normalized() * length;
    // int count = trunc(vec.length() / length);
    int count = (vec.length() / length);

    if (count == 0) return QList<LineSegment*>();

    for (int i = 0; i < count; i++) {
        LineSegment* line = new LineSegment(segment);
        line->setStart(i == 0 ? segment->getStart() : list[i - 1]->getEnd());
        line->setEnd(line->getStart() + seg);
        list.append(line);
    }

    if (list.count() > 0 && list.last()->getEnd() != segment->getEnd()) {
        LineSegment* line = new LineSegment(segment);
        line->setStart(list.last()->getEnd());
        line->setEnd(segment->getEnd());
        list.append(line);
    }

    return list;
}

void frmMain::jogStep()
{
    const double linearStep = ui->cboJogStep->currentText().toDouble();
    if (!qIsFinite(linearStep) || linearStep <= 0.0) return; // Continuous motion is handled by jogContinuous().

    // Rotary axes have their own degree increment. Never reuse the linear
    // millimetre/inch step for A or B: the two rotary axes remain independent.
    const double rotaryStep = ui->cboRotaryJogStep->currentText().toDouble();
    const bool rotaryRequested = (m_settings->axisAEnabled() && !qFuzzyIsNull(m_jogVector.w())) ||
                                 (m_settings->axisBEnabled() && !qFuzzyIsNull(m_jogB));
    if (rotaryRequested && (!qIsFinite(rotaryStep) || rotaryStep <= 0.0)) return;

    const double rotaryA = m_settings->axisAEnabled() ? m_jogVector.w() * rotaryStep : 0.0;
    const QVector4D vec(m_jogVector.x() * linearStep,
                        m_jogVector.y() * linearStep,
                        m_jogVector.z() * linearStep,
                        rotaryA);
    const double b = m_settings->axisBEnabled() ? m_jogB * rotaryStep : 0.0;
    if (vec.lengthSquared() == 0.0 && qFuzzyIsNull(b)) return;

    QString command = QString("$J=%1G91")
        .arg(m_settings->units() ? "G20" : "G21");
    const int linearPrecision = m_settings->units() ? 4 : 3;
    if (!qFuzzyIsNull(vec.x())) command += QString("X%1").arg(vec.x(), 0, 'f', linearPrecision);
    if (!qFuzzyIsNull(vec.y())) command += QString("Y%1").arg(vec.y(), 0, 'f', linearPrecision);
    if (!qFuzzyIsNull(vec.z())) command += QString("Z%1").arg(vec.z(), 0, 'f', linearPrecision);
    if (m_settings->axisAEnabled() && !qFuzzyIsNull(vec.w()))
        command += QString("A%1").arg(vec.w(), 0, 'f', 3);
    if (m_settings->axisBEnabled() && !qFuzzyIsNull(b))
        command += QString("B%1").arg(b, 0, 'f', 3);

    const bool rotaryOnly = (qFuzzyIsNull(vec.x()) && qFuzzyIsNull(vec.y()) &&
                             qFuzzyIsNull(vec.z()) && (!qFuzzyIsNull(vec.w()) || !qFuzzyIsNull(b)));
    const double jogFeed = rotaryOnly ? ui->cboRotaryJogFeed->currentText().toDouble()
                                      : ui->cboJogFeed->currentText().toDouble();
    // Never emit an invalid or non-positive feed value to the controller.
    if (!qIsFinite(jogFeed) || jogFeed <= 0.0) return;
    command += QString("F%1").arg(jogFeed);
    sendCommand(command, -3, m_settings->showUICommands());
}

void frmMain::jogContinuous()
{
    if ((ui->cboJogStep->currentText().toDouble() == 0) && !m_continuousJogTransition) {
        const double currentB = m_settings->axisBEnabled() ? m_jogB : 0.0;
        if (m_jogVector != m_lastContinuousJogVector ||
            !qFuzzyCompare(currentB + 1.0, m_lastContinuousJogB + 1.0)) {
            // Save the requested direction before stopping the previous jog.
            const QVector4D j = m_jogVector;
            const double jb = currentB;

            if (m_lastContinuousJogVector.lengthSquared() > 0.0 || !qFuzzyIsNull(m_lastContinuousJogB)) {
                m_continuousJogTransition = true;
                m_serialPort.write(QByteArray(1, char(0x85)));
                while (m_deviceState == DeviceJog) qApp->processEvents();
                m_continuousJogTransition = false;
            }

            // A Stop click or a direction change can be processed while the
            // previous jog is stopping. Never launch the stale captured move.
            const double latestB = m_settings->axisBEnabled() ? m_jogB : 0.0;
            if (m_jogVector != j || !qFuzzyCompare(latestB + 1.0, jb + 1.0)) {
                m_lastContinuousJogVector = m_jogVector;
                m_lastContinuousJogB = latestB;
                return;
            }

            // Linear soft limits apply to X/Y/Z. Rotary A/B are angular axes.
            const QVector3D bounds = m_settings->machineBounds();
            const QVector3D machine(toMetric(m_storedVars.Mx()),
                                    toMetric(m_storedVars.My()),
                                    toMetric(m_storedVars.Mz()));
            QVector3D distance;
            double d = 0.0;
            if (m_settings->softLimitsEnabled()) {
                distance = QVector3D(j.x() * bounds.x() < 0 ? -machine.x() : bounds.x() - machine.x(),
                                     j.y() * bounds.y() < 0 ? -machine.y() : bounds.y() - machine.y(),
                                     j.z() * bounds.z() < 0 ? -machine.z() : bounds.z() - machine.z());
                for (int i = 0; i < 3; ++i)
                    if (j[i] && (qAbs(distance[i]) < d || qFuzzyIsNull(d))) d = qAbs(distance[i]);
                if (d > 0.0) d -= m_settings->units() ? toMetric(0.0005) : 0.005;
            } else {
                for (int i = 0; i < 3; ++i)
                    if (j[i] && qAbs(bounds[i]) > d) d = qAbs(bounds[i]);
            }

            QVector4D vec = j * toInches(d);
            vec.setW(j.w() * 360.0);
            const double b = jb * 360.0;

            if (vec.lengthSquared() > 0.0 || !qFuzzyIsNull(b)) {
                QString command = QString("$J=%1G91")
                    .arg(m_settings->units() ? "G20" : "G21");
                const int linearPrecision = m_settings->units() ? 4 : 3;
                if (!qFuzzyIsNull(vec.x())) command += QString("X%1").arg(vec.x(), 0, 'f', linearPrecision);
                if (!qFuzzyIsNull(vec.y())) command += QString("Y%1").arg(vec.y(), 0, 'f', linearPrecision);
                if (!qFuzzyIsNull(vec.z())) command += QString("Z%1").arg(vec.z(), 0, 'f', linearPrecision);
                if (m_settings->axisAEnabled() && !qFuzzyIsNull(vec.w()))
                    command += QString("A%1").arg(vec.w(), 0, 'f', 3);
                if (m_settings->axisBEnabled() && !qFuzzyIsNull(b))
                    command += QString("B%1").arg(b, 0, 'f', 3);
                const bool rotaryOnly = (qFuzzyIsNull(j.x()) && qFuzzyIsNull(j.y()) &&
                                         qFuzzyIsNull(j.z()) &&
                                         ((m_settings->axisAEnabled() && !qFuzzyIsNull(j.w())) ||
                                          (m_settings->axisBEnabled() && !qFuzzyIsNull(jb))));
                const double jogFeed = rotaryOnly ? ui->cboRotaryJogFeed->currentText().toDouble()
                                                  : ui->cboJogFeed->currentText().toDouble();
                // Continuous jog uses the same feed validation as incremental jog.
                if (!qIsFinite(jogFeed) || jogFeed <= 0.0) {
                    m_lastContinuousJogVector = j;
                    m_lastContinuousJogB = jb;
                    return;
                }
                command += QString("F%1").arg(jogFeed);
                sendCommand(command, -2, m_settings->showUICommands());
            }
            m_lastContinuousJogVector = j;
            m_lastContinuousJogB = jb;
        }
    }
}

double frmMain::toMetric(double value)
{
    return m_settings->units() == 0 ? value : value * 25.4;
}

double frmMain::toInches(double value)
{
    return m_settings->units() == 0 ? value : value / 25.4;
}

bool frmMain::compareCoordinates(double x, double y, double z)
{
    return ui->txtMPosX->value() == x && ui->txtMPosY->value() == y && ui->txtMPosZ->value() == z;
}

bool frmMain::isGCodeFile(QString fileName)
{
    return fileName.endsWith(".txt", Qt::CaseInsensitive)
          || fileName.endsWith(".nc", Qt::CaseInsensitive)
          || fileName.endsWith(".ncc", Qt::CaseInsensitive)
          || fileName.endsWith(".ngc", Qt::CaseInsensitive)
          || fileName.endsWith(".tap", Qt::CaseInsensitive)
          || fileName.endsWith(".gcode", Qt::CaseInsensitive);
}

bool frmMain::isHeightmapFile(QString fileName)
{
    return fileName.endsWith(".map", Qt::CaseInsensitive);
}

int frmMain::buttonSize()
{
    return ui->cmdHome->minimumWidth();
}

void frmMain::setSenderState(SenderState state)
{
    if (m_senderState != state) {
        m_senderState = state;
        emit senderStateChanged(state);
    }
}

void frmMain::setDeviceState(DeviceState state)
{
    if (m_deviceState != state) {
        m_deviceState = state;
        emit deviceStateChanged(state);
    }
}

void frmMain::completeTransfer()
{
    // Shadow last segment
    GcodeViewParse *parser = m_currentDrawer->viewParser();
    QList<LineSegment*> list = parser->getLineSegmentList();
    if (m_lastDrawnLineIndex < list.count()) {
        list[m_lastDrawnLineIndex]->setDrawn(true);
        m_currentDrawer->update(QList<int>() << m_lastDrawnLineIndex);
        m_rotaryPivotDrawer.setToolpath(list);
    }

    // Update state
    setSenderState(SenderStopped);
    m_fileProcessedCommandIndex = 0;
    m_lastDrawnLineIndex = 0;
    m_storedParserStatus.clear();

    updateControlsState();

    // Send end commands
    if (m_settings->useEndCommands()) sendCommands(m_settings->endCommands());

    // Show message box
    qApp->beep();
    m_timerStateQuery.stop();
    m_timerConnection.stop();

    QMessageBox::information(this, qApp->applicationDisplayName(), tr("Job done.\nTime elapsed: %1")
                                .arg(ui->glwVisualizer->spendTime().toString("hh:mm:ss")));

    m_timerStateQuery.setInterval(m_settings->queryStateTime());
    m_timerConnection.start();
    m_timerStateQuery.start();
}

QString frmMain::getLineInitCommands(int row)
{
    int commandIndex = row;
    QString commands;

    GcodeViewParse *parser = m_currentDrawer->viewParser();
    QList<LineSegment*> list = parser->getLineSegmentList();
    QVector<QList<int>> lineIndexes = parser->getLinesIndexes();

    int lineNumber = m_currentModel->data(m_currentModel->index(commandIndex, 4)).toInt();
    if (lineNumber < 0) {
        return "";
    }

    LineSegment* firstSegment = list.at(lineIndexes.at(lineNumber).first());
    LineSegment* lastSegment = list.at(lineIndexes.at(lineNumber).last());
    LineSegment* feedSegment = lastSegment;
    LineSegment* preFirstSegment = firstSegment;

    int segmentIndex = list.indexOf(feedSegment);
    while (feedSegment->isFastTraverse() && segmentIndex > 0) feedSegment = list.at(--segmentIndex);
    segmentIndex = list.indexOf(firstSegment);
    if (segmentIndex > 0) preFirstSegment = list.at(--segmentIndex);

    commands.append(QString("M3 S%1\n").arg(qMax<double>(lastSegment->getSpindleSpeed(), ui->slbSpindle->value())));

    if (m_settings->axisAEnabled() && parser->axisRotationUsed(GcodeViewParse::RotationAxisA)) {
        QMatrix4x4 rotation;

        if (!qIsNaN(preFirstSegment->axesEnd().x())) 
            rotation.rotate(preFirstSegment->axesEnd().x(),
                Util::rotationVector(m_settings->axisAX() ? Util::RotationVectorX : Util::RotationVectorY));

        QVector3D rotated = rotation * firstSegment->getStart();

        if (!qIsNaN(rotated.x()) || !qIsNaN(rotated.y()) || !qIsNaN(firstSegment->axesEnd().x())) {
            commands.append(QString("G21 G90 G0%1%2%3\n")
                .arg(optArg("X", rotated.x(), 0, 'f', 4))
                .arg(optArg("Y", rotated.y(), 0, 'f', 4))
                .arg(optArg("A", firstSegment->axesEnd().x(), 0, 'f', 4)));
        }

        if (!qIsNaN(firstSegment->getStart().z())) {
            commands.append(QString("G1 Z%1 F%2\n")
                .arg(rotated.z(), 0, 'f', 4)
                .arg(feedSegment->getSpeed()));
        }
    } else {
        if (!qIsNaN(firstSegment->getStart().x()) || !qIsNaN(firstSegment->getStart().y())) {
            commands.append(QString("G21 G90 G0%1%2\n")
                .arg(optArg("X", firstSegment->getStart().x()))
                .arg(optArg("Y", firstSegment->getStart().y())));
        }

        if (!qIsNaN(firstSegment->getStart().z())) {
            commands.append(QString("G1 Z%1 F%2\n")
                .arg(optArg("Z", firstSegment->getStart().z()))
                .arg(feedSegment->getSpeed()));
        }
    }

    commands.append(QString("%1 %2 %3 F%4")
        .arg(lastSegment->isMetric() ? "G21" : "G20")
        .arg(lastSegment->isAbsolute() ? "G90" : "G91")
        .arg(lastSegment->isFastTraverse() ? "G0" : "G1")
        .arg(lastSegment->isMetric() ? feedSegment->getSpeed() : feedSegment->getSpeed() / 25.4));

    if (lastSegment->isArc()) {
        commands.append(lastSegment->plane() == PointSegment::XY ? "G17" :
                lastSegment->plane() == PointSegment::ZX ? "G18" : "G19");
    }

    return commands;
}

bool frmMain::actionLessThan(const QAction *a1, const QAction *a2)
{
    return a1->objectName() < a2->objectName();
}

bool frmMain::actionTextLessThan(const QAction *a1, const QAction *a2)
{
    return a1->text() < a2->text();
}

QScriptValue frmMain::importExtension(QScriptContext *context, QScriptEngine *engine)
{
    return engine->importExtension(context->argument(0).toString());
}