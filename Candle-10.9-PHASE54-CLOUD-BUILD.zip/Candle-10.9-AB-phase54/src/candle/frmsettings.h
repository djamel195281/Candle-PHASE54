// This file is a part of "Candle" application.
// Copyright 2015-2021 Hayrullin Denis Ravilevich

#ifndef FRMSETTINGS_H
#define FRMSETTINGS_H

#include <QDialog>
#include <QMessageBox>
#include <QListWidgetItem>
#include <QSettings>
#include <QGroupBox>
#include <QVector3D>
#include <QComboBox>
#include <QPlainTextEdit>
#include <QTableWidget>
#include <QTranslator>
#include "colorpicker.h"

namespace Ui {
class frmSettings;
}

// TODO: Add overriding bounds settings
class frmSettings : public QDialog
{
    Q_OBJECT
    Q_PROPERTY(QString port READ port WRITE setPort)
    Q_PROPERTY(int baud READ baud WRITE setBaud)
    Q_PROPERTY(double toolDiameter READ toolDiameter WRITE setToolDiameter)
    Q_PROPERTY(double toolLength READ toolLength WRITE setToolLength)
    Q_PROPERTY(bool antialiasing READ antialiasing WRITE setAntialiasing)
    Q_PROPERTY(bool zBuffer READ zBuffer WRITE setZBuffer)
    Q_PROPERTY(double lineWidth READ lineWidth WRITE setLineWidth)
    Q_PROPERTY(double arcLength READ arcLength WRITE setArcLength)
    Q_PROPERTY(double arcDegree READ arcDegree WRITE setArcDegree)
    Q_PROPERTY(bool arcDegreeMode READ arcDegreeMode WRITE setArcDegreeMode)
    Q_PROPERTY(bool showProgramCommands READ showProgramCommands WRITE setShowProgramCommands)
    Q_PROPERTY(bool showUICommands READ showUICommands WRITE setShowUICommands)
    Q_PROPERTY(int spindleSpeedMin READ spindleSpeedMin WRITE setSpindleSpeedMin)
    Q_PROPERTY(int spindleSpeedMax READ spindleSpeedMax WRITE setSpindleSpeedMax)
    Q_PROPERTY(int laserPowerMin READ laserPowerMin WRITE setLaserPowerMin)
    Q_PROPERTY(int laserPowerMax READ laserPowerMax WRITE setLaserPowerMax)
    Q_PROPERTY(int queryStateTime READ queryStateTime WRITE setQueryStateTime)
    Q_PROPERTY(int toolType READ toolType WRITE setToolType)
    Q_PROPERTY(double toolAngle READ toolAngle WRITE setToolAngle)
    Q_PROPERTY(int fps READ fps WRITE setFps)
    Q_PROPERTY(bool vsync READ vsync WRITE setVsync)
    Q_PROPERTY(bool msaa READ msaa WRITE setMsaa)
    Q_PROPERTY(bool autoCompletion READ autoCompletion WRITE setAutoCompletion)
    Q_PROPERTY(bool simplify READ simplify WRITE setSimplify)
    Q_PROPERTY(double simplifyPrecision READ simplifyPrecision WRITE setSimplifyPrecision)
    Q_PROPERTY(int fontSize READ fontSize WRITE setFontSize)
    Q_PROPERTY(bool grayscaleSegments READ grayscaleSegments WRITE setGrayscaleSegments)
    Q_PROPERTY(bool grayscaleSCode READ grayscaleSCode WRITE setGrayscaleSCode)
    Q_PROPERTY(bool drawModeVectors READ drawModeVectors WRITE setDrawModeVectors)
    Q_PROPERTY(bool ignoreErrors READ ignoreErrors WRITE setIgnoreErrors)
    Q_PROPERTY(bool autoLine READ autoLine WRITE setAutoLine)
    Q_PROPERTY(bool useStartCommands READ useStartCommands WRITE setUseStartCommands)
    Q_PROPERTY(QString startCommands READ startCommands WRITE setStartCommands)
    Q_PROPERTY(bool useEndCommands READ useEndCommands WRITE setUseEndCommands)
    Q_PROPERTY(QString endCommands READ endCommands WRITE setEndCommands)
    Q_PROPERTY(QString toolChangeCommands READ toolChangeCommands WRITE setToolChangeCommands)
    Q_PROPERTY(bool toolChangePause READ toolChangePause WRITE setToolChangePause)
    Q_PROPERTY(bool toolChangeUseCommands READ toolChangeUseCommands WRITE setToolChangeUseCommands)
    Q_PROPERTY(bool toolChangeUseCommandsConfirm READ toolChangeUseCommandsConfirm WRITE setToolChangeUseCommandsConfirm)
    Q_PROPERTY(QString language READ language WRITE setLanguage)
    Q_PROPERTY(bool units READ units WRITE setUnits)
    Q_PROPERTY(int rapidSpeed READ rapidSpeed WRITE setRapidSpeed)
    Q_PROPERTY(int acceleration READ acceleration WRITE setAcceleration)
    Q_PROPERTY(QVector3D machineBounds READ machineBounds WRITE setMachineBounds)
    Q_PROPERTY(bool homingEnabled READ homingEnabled WRITE setHomingEnabled)
    Q_PROPERTY(bool softLimitsEnabled READ softLimitsEnabled WRITE setSoftLimitsEnabled)
    Q_PROPERTY(bool axisAEnabled READ axisAEnabled)
    Q_PROPERTY(bool axisAX READ axisAX)
    Q_PROPERTY(bool axisBEnabled READ axisBEnabled)
    Q_PROPERTY(double pivotAX READ pivotAX WRITE setPivotAX)
    Q_PROPERTY(double pivotAY READ pivotAY WRITE setPivotAY)
    Q_PROPERTY(double pivotAZ READ pivotAZ WRITE setPivotAZ)
    Q_PROPERTY(double pivotBX READ pivotBX WRITE setPivotBX)
    Q_PROPERTY(double pivotBY READ pivotBY WRITE setPivotBY)
    Q_PROPERTY(double pivotBZ READ pivotBZ WRITE setPivotBZ)
    Q_PROPERTY(bool showRotaryA READ showRotaryA WRITE setShowRotaryA)
    Q_PROPERTY(bool showRotaryB READ showRotaryB WRITE setShowRotaryB)
    Q_PROPERTY(double rotaryAWidth READ rotaryAWidth WRITE setRotaryAWidth)
    Q_PROPERTY(double rotaryADepth READ rotaryADepth WRITE setRotaryADepth)
    Q_PROPERTY(double rotaryBWidth READ rotaryBWidth WRITE setRotaryBWidth)
    Q_PROPERTY(double rotaryBDepth READ rotaryBDepth WRITE setRotaryBDepth)
    Q_PROPERTY(double stockAWidth READ stockAWidth WRITE setStockAWidth)
    Q_PROPERTY(double stockADepth READ stockADepth WRITE setStockADepth)
    Q_PROPERTY(double stockBWidth READ stockBWidth WRITE setStockBWidth)
    Q_PROPERTY(double stockBDepth READ stockBDepth WRITE setStockBDepth)
    Q_PROPERTY(double stockAHeight READ stockAHeight WRITE setStockAHeight)
    Q_PROPERTY(double stockBHeight READ stockBHeight WRITE setStockBHeight)
    Q_PROPERTY(int stockAShape READ stockAShape WRITE setStockAShape)
    Q_PROPERTY(int stockBShape READ stockBShape WRITE setStockBShape)

public:
    explicit frmSettings(QWidget *parent = 0);
    ~frmSettings();

    int exec();
    void undo();

    void addCustomSettings(QGroupBox *box);

    QString port();
    void setPort(QString port);
    int baud();
    void setBaud(int baud);
    double toolDiameter();
    void setToolDiameter(double diameter);
    double toolLength();
    void setToolLength(double length);
    bool antialiasing();
    void setAntialiasing(bool antialiasing);
    bool zBuffer();
    void setZBuffer(bool zBuffer);
    double lineWidth();
    void setLineWidth(double lineWidth);
    double arcLength();
    void setArcLength(double arcLength);
    double arcDegree();
    void setArcDegree(double arcDegree);
    double arcPrecision();
    bool arcDegreeMode();
    void setArcDegreeMode(bool arcDegreeMode);
    bool showProgramCommands();
    void setShowProgramCommands(bool showProgramCommands);
    bool showUICommands();
    void setShowUICommands(bool showUICommands);
    int spindleSpeedMin();
    void setSpindleSpeedMin(int speed);
    int spindleSpeedMax();
    void setSpindleSpeedMax(int speed);
    int laserPowerMin();
    void setLaserPowerMin(int value);
    int laserPowerMax();
    void setLaserPowerMax(int value);
    int rapidSpeed();
    void setRapidSpeed(int rapidSpeed);
    int acceleration();
    void setAcceleration(int acceleration);
    int queryStateTime();
    void setQueryStateTime(int queryStateTime);
    int toolType();
    void setToolType(int toolType);
    double toolAngle();
    void setToolAngle(double toolAngle);
    int fps();
    void setFps(int fps);
    bool vsync();
    void setVsync(bool value);
    bool msaa();
    void setMsaa(bool msaa);
    bool autoCompletion();
    void setAutoCompletion(bool autoCompletion);
    int units();
    void setUnits(int units);
    bool simplify();
    void setSimplify(bool simplify);
    double simplifyPrecision();
    void setSimplifyPrecision(double simplifyPrecision);
    QList<ColorPicker*> colors();
    QColor colors(QString name);
    int fontSize();
    void setFontSize(int fontSize);
    int panelWidth();
    void setPanelWidth(int panelWidth);
    bool grayscaleSegments();
    void setGrayscaleSegments(bool value);
    bool grayscaleSCode();
    void setGrayscaleSCode(bool value);
    bool drawModeVectors();
    void setDrawModeVectors(bool value);
    bool ignoreErrors();
    void setIgnoreErrors(bool value);
    bool autoLine();
    void setAutoLine(bool value);
    bool useStartCommands();
    void setUseStartCommands(bool value);
    QString startCommands();
    void setStartCommands(QString commands);
    bool useEndCommands();
    void setUseEndCommands(bool value);
    QString endCommands();
    void setEndCommands(QString commands);
    QString toolChangeCommands();
    void setToolChangeCommands(QString commands);
    bool toolChangePause();
    void setToolChangePause(bool pause);
    bool toolChangeUseCommands();
    void setToolChangeUseCommands(bool value);
    bool toolChangeUseCommandsConfirm();
    void setToolChangeUseCommandsConfirm(bool value);
    QString language();
    void setLanguage(QString language);
    QVector3D machineBounds();
    void setMachineBounds(QVector3D bounds);
    bool homingEnabled();
    void setHomingEnabled(bool homing);
    bool softLimitsEnabled();
    void setSoftLimitsEnabled(bool softLimits);    
    bool referenceXPlus();
    void setReferenceXPlus(bool value);
    bool referenceYPlus();
    void setReferenceYPlus(bool value);
    bool referenceZPlus();
    void setReferenceZPlus(bool value);
    bool invertedSliderControls();
    void setInvertedSliderControls(bool value);
    QTableWidget* shortcuts();
    void setShortcuts(QList<QAction*> acts);
    bool axisAEnabled();
    void setAxisAEnabled(bool value);
    bool axisAX();
    bool axisBEnabled();
    void setAxisBEnabled(bool value);
    void setAxisAX(bool value);
    double pivotAX(); void setPivotAX(double value);
    double pivotAY(); void setPivotAY(double value);
    double pivotAZ(); void setPivotAZ(double value);
    double pivotBX(); void setPivotBX(double value);
    double pivotBY(); void setPivotBY(double value);
    double pivotBZ(); void setPivotBZ(double value);
    bool showRotaryA(); void setShowRotaryA(bool value);
    bool showRotaryB(); void setShowRotaryB(bool value);
    double rotaryAWidth(); void setRotaryAWidth(double value);
    double rotaryADepth(); void setRotaryADepth(double value);
    double rotaryBWidth(); void setRotaryBWidth(double value);
    double rotaryBDepth(); void setRotaryBDepth(double value);
    double stockAWidth(); void setStockAWidth(double value);
    double stockADepth(); void setStockADepth(double value);
    double stockBWidth(); void setStockBWidth(double value);
    double stockBDepth(); void setStockBDepth(double value);
    double stockAHeight(); void setStockAHeight(double value);
    double stockBHeight(); void setStockBHeight(double value);
    int stockAShape(); void setStockAShape(int value);
    int stockBShape(); void setStockBShape(int value);

    void setDefaultSettings();

signals:
    void settingsSetByDefault();

protected:
    void showEvent(QShowEvent *se);

private slots:
    void on_cmdRefresh_clicked();
    void on_cmdOK_clicked();
    void on_cmdCancel_clicked();
    void on_cboToolType_currentIndexChanged(int index);
    void on_listCategories_currentRowChanged(int currentRow);
    void on_cmdDefaults_clicked();
    void on_radDrawModeVectors_toggled(bool checked);
    void on_radDrawModeRaster_toggled(bool checked);
    void on_radGrayscaleS_toggled(bool checked);
    void on_radGrayscaleZ_toggled(bool checked);

private:
    Ui::frmSettings *ui;

    void searchPorts();

    QMap<QAbstractSpinBox*, double> m_storedValues;
    QMap<QAbstractButton*, bool> m_storedChecks;
    QMap<QComboBox*, QString> m_storedCombos;
    QMap<ColorPicker*, QColor> m_storedColors;
    QMap<QLineEdit*, QString> m_storedTextBoxes;
    QMap<QPlainTextEdit*, QString> m_storedPlainTexts;

    QIntValidator m_intValidator;

    QList<QWidget*> m_customSettings;

    int m_units;
    int m_acceleration;
    int m_rapidSpeed;
    QVector3D m_machineBounds;
    bool m_homingEnabled;
    bool m_softLimitsEnabled;
};

#endif // FRMSETTINGS_H
