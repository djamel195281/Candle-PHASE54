
#pragma once

#include <QThread>

