Candle 10.9 — Phase 36
======================

Purpose
-------
Improve the visual cursor that associates the live tool position with the
rotary toolpath. The previous matching used XYZ distance only, which could
select the wrong segment when paths crossed or when a rotary-only move kept
XYZ fixed.

Changes
-------
- Each tessellated preview segment now retains its interpolated A and B angle
  endpoints, independently, alongside its XYZ endpoints.
- Live cursor matching now considers XYZ, A and B together. The geometric
  metric uses 10 mm and 10 degree normalization scales.
- Rotary-only segments can therefore be matched by their changing A/B angles
  even when XYZ remains stationary.
- A-only and B-only segments only compare the rotary coordinate they contain;
  they do not require the other rotary axis to move.
- Updating live A/B angles now recalculates the highlighted preview segment,
  just as updating the live XYZ tool position does.
- Rotary endpoint fields are considered present only when both endpoints are
  finite, preventing a missing endpoint from being silently treated as zero.
- The cursor remains a geometric nearest-segment indicator. It is not a
  controller-reported execution line, elapsed-time estimate, or guarantee of
  actual machine position. It can still be ambiguous for repeated identical
  poses or paths that overlap in all displayed coordinates.

Safety and scope
----------------
- No G-code, jog command, homing, FluidNC setting, or machine motion behavior
  has been changed.
- The 10 mm / 10 degree scales are visualization matching weights, not
  machine calibration or kinematic dimensions.
- The preview still does not implement TCP/RTCP, pivot compensation,
  collision detection, or material-removal simulation.

Validation
----------
- Static source assertions and all Qt Designer .ui XML files are checked.
- ZIP integrity is checked.
- Qt compilation and physical machine tests have not been performed.
