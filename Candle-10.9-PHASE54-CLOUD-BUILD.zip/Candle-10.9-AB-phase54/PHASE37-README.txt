Candle 10.9 — Phase 37
======================

Purpose
-------
Make rapid G0 travel moves visually distinct from G1 feed/cutting moves in
both vector and raster toolpath preview modes.

Changes
-------
- Added a dedicated rapid-traverse color to GcodeDrawer.
- G0 segments are drawn in blue (RGB 30, 144, 255).
- G1 segments retain the configured ToolpathNormal color, except for existing
  higher-priority states such as drawn/highlighted and the existing Z-movement
  color rule.
- The same segment-color selection is used by vector and raster rendering.
- The rapid color has a validated setter/getter for future settings UI work.
- Existing simplification still keeps G0 and G1 segment types separate.

Compatibility and scope
-----------------------
- No G-code parsing, command transmission, jog, homing, FluidNC settings, or
  machine motion behavior has been changed.
- The blue rapid color is currently a source default, not a user-configurable
  preference in the settings dialog.
- Existing drawn/highlight and Z-movement color precedence is preserved.
- This phase only changes preview colors; it does not alter feed rates or
  distinguish actual controller execution state.

Validation
----------
- Static source assertions check the rapid-color member, setter/getter,
  G0 color branch, G1 fallback, and startup initialization.
- All Qt Designer .ui files are parsed as XML.
- ZIP integrity is checked.
- Qt compilation and physical machine tests have not been performed.
