Candle 10.9 — Phase 17
======================

Adds independently configurable preview stock dimensions and shape for A and B.
Settings expose stock height and rectangular/cylindrical shape for each axis;
stock width, depth, and height are independent from table dimensions.
Values are persisted with the existing Candle settings.

The drawer renders a rectangular wireframe prism or a 24-segment cylindrical
wireframe, attached to its corresponding independent rotary preview axis.
The preview is graphical only: it does not change G-code, FluidNC configuration,
coordinates, offsets, or motor commands.

Defaults: 19.2 x 14.4 x 8 mm, rectangular stock for both axes. Dimensions are
provisional until the
real fixture and stock mounting geometry are measured.

Validation: XML parsing, source-level wiring checks, archive integrity.
Qt compilation and physical CNC testing have not been performed.
