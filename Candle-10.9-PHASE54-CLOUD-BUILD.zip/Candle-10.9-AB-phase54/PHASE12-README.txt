CANDLE 10.9 — PHASE 12

Objectif : rendre visibles dans le visualiseur 3D les centres de rotation A et B
configurés en Phase 11.

Modifications :
- Ajout de RotaryPivotDrawer, un drawable OpenGL dédié aux repères de pivots.
- Repère A orange : anneau dans le plan YZ et axe de rotation X.
- Repère B bleu/cyan : anneau dans le plan XZ et axe de rotation Y.
- Chaque repère possède son propre centre, son anneau et un réticule au centre.
- Les six coordonnées configurées en Phase 11 pilotent directement les deux repères.
- Les repères sont ajoutés au visualiseur 3D et rafraîchis lors de l'application
  des paramètres de la machine.
- Aucun mouvement ni commande G-code n'est envoyé à FluidNC par ce drawable.

Limites et précautions :
- Les anneaux sont des marqueurs de visualisation, pas un modèle mécanique complet.
- La convention A autour de X et B autour de Y reste provisoire et doit être
  confirmée par la géométrie réelle de la machine.
- Le rayon des anneaux (5 mm) et la longueur des axes (16 mm) sont des repères
  graphiques fixes, pas des dimensions physiques.
- Si les pivots sont éloignés de la zone du programme, ils peuvent se trouver hors
  du cadrage courant ; le cadrage automatique des pivots n'est pas encore implémenté.
- Pas de cinématique inverse, de détection de collision, de modèle de pièce ou
  de simulation d'enlèvement de matière.
- Compilation Qt et essai matériel non réalisés ici.

Vérifications statiques à effectuer : intégrité ZIP, XML Qt, symboles du drawable,
connexion au visualiseur et synchronisation des coordonnées A/B.
