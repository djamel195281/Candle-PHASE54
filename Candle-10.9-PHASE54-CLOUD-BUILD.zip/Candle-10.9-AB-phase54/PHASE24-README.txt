Candle 10.9 — Phase 24
Repère visuel du segment actif sur le parcours rotatif

Modifications :
- Le dessinateur rotatif recherche le segment de trajectoire tessellé le plus
  proche de la position courante de la pointe d'outil.
- Le segment le plus proche est surligné en jaune dans l'aperçu.
- Le calcul utilise la projection de la position outil sur chaque segment,
  et non uniquement la distance à ses extrémités.
- Le repère est recalculé lorsque la position outil change et lorsque le
  parcours est rechargé.
- Une limite de distance évite de surligner un segment éloigné lorsque la
  position outil n'est pas proche du parcours.
- Les couleurs existantes A, B, A+B et exécuté / restant sont conservées
  pour les autres segments.
- Aucun G-code, paramètre FluidNC, coordonnée machine ou commande moteur
  n'est modifié. A et B restent indépendants.

Limites importantes :
- Le surlignage est un curseur graphique basé sur le segment géométriquement
  le plus proche de la position outil. Il ne constitue pas une mesure exacte
  du temps d'exécution ni une interpolation temporelle.
- Si plusieurs segments se croisent ou sont très proches, le segment choisi
  peut être ambigu.
- Le calcul est effectué sur le chemin déjà tessellé par Candle; il ne crée
  pas de cinématique inverse, de détection de collision ni d'enlèvement
  de matière.
- Compilation Qt et essai sur machine non réalisés dans cet environnement.

Vérifications réalisées :
- Contrôle statique de la recherche du segment le plus proche et de son seuil.
- Validation XML des interfaces Qt.
- Contrôle d'intégrité de l'archive ZIP.
