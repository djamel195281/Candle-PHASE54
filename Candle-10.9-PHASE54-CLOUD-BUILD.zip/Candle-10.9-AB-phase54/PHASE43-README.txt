Candle 10.9 - Phase 43

Phase 43 builds on Phase 42's read-only XYZAB movement inspector and clipboard copy.

Changes:
- Adds Previous and Next buttons beside the movement inspector.
- Each button searches the currently active G-code table model for the nearest earlier/later row that has at least one valid drawable preview segment.
- Selecting a result uses Candle's existing table selection mechanism, so the existing toolpath highlighting, selection marker, and XYZAB inspector update together.
- The navigation skips comments, empty rows, and rows without drawable geometry.
- Parser line indexes and segment pointers are checked before use; the editable trailing row is excluded.
- Navigation is read-only and does not issue commands to FluidNC.

Safety scope:
- No G-code is modified.
- No serial command, jog, homing, spindle, motor, or FluidNC configuration behavior is added or changed.
- Preview coordinates are not confirmation of physical machine position.

Validation performed:
- Static assertions for both controls, direction-specific navigation, valid line/segment bounds, and use of the existing table selection path.
- XML parsing of all .ui files.
- ZIP integrity test and full archive listing test after packaging.

Not performed:
- Qt compilation (Qt development dependencies are not available in this environment).
- Runtime GUI testing or physical machine testing.
