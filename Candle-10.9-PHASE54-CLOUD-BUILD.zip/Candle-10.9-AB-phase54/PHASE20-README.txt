Candle 10.9 — Phase 20
Fiabilisation de la geometrie de l'outil dans l'aperçu 3D

Cette phase fiabilise le modele filaire de l'outil deja present dans Candle.

Modifications :
- Initialisation explicite de toutes les dimensions, angles, positions et de
  la couleur de l'outil, afin d'eviter une geometrie initiale indeterminee.
- Recalcul de la hauteur de pointe conique lorsque le diametre de l'outil
  change. Auparavant, cette hauteur n'etait recalculee que lors du changement
  d'angle.
- Validation des valeurs : diametre et longueur doivent etre finis et
  strictement positifs ; l'angle est borne entre 0 et 180 degres.
- La longueur affichee ne peut pas devenir inferieure a la hauteur necessaire
  pour representer la pointe conique.
- La geometrie reste un apercu filaire ; le diametre et l'angle proviennent
  des reglages d'outil existants de Candle.

Limites :
- Il ne s'agit pas d'une simulation de retrait de matiere.
- Pas de calcul de contact fraise/brut, de collision, de porte-outil ou de
  charge de coupe.
- La position de l'outil reste celle fournie par le suivi XYZ existant de
  Candle ; cette phase n'ajoute pas de cinematique cinq axes reelle.
- Aucun G-code, parametre FluidNC, decalage outil ou commande moteur modifie.
- Compilation Qt et essai sur machine non effectues dans cet environnement.

Verification effectuee : controle statique des changements et test d'integrite
ZIP. Cela ne remplace pas une compilation Qt ni un essai sur la machine.
