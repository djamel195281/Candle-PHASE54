Candle 10.9 – Phase 27
Rotary jog safety and state handling

Changes
- Rotary step validation is now conditional: XYZ jog is not blocked by an absent or invalid rotary step value when no A/B movement was requested.
- A and B jog release handlers always clear their pressed-direction state, even if the axis becomes hidden or disabled while the button is held.
- A-axis press handlers verify that A is enabled before recording a jog direction.
- Continuous-jog history is stored as frmMain state instead of function-local statics. The Stop button resets this history so repeating the same direction after Stop can start normally.
- During a continuous-jog direction transition, a Stop click or a changed direction processed by Qt's event loop cancels the stale captured move instead of launching it afterward.
- A and B remain separate coordinates; no axis coupling or automatic movement was introduced.

Safety boundaries
- These changes improve Candle-side jog state handling only. They do not replace FluidNC hard limits, a physical emergency stop, correct driver current setup, or safe mechanical commissioning.
- No motion is sent on application startup.
- A/B motor wiring, driver setup, limit inputs, and emergency-stop behavior must be verified before testing rotary motion.

Verification
- Source-level checks and XML parsing are performed for this archive.
- Qt compilation and physical machine testing are not available in this environment and are not claimed.
