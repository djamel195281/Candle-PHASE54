Candle 10.9 - Phase 42

Phase 42 builds on Phase 41's read-only XYZAB G-code row inspector.

Changes:
- Adds a Copy button beside the selected-movement details.
- Copies only the displayed inspection text to the system clipboard.
- The button remains disabled until a drawable movement is selected and is disabled again when the selection becomes invalid.
- Hardens the selected-row highlight loop against out-of-range parser line indexes and invalid segment indexes.
- Keeps all Phase 41 XYZAB inspection behavior and all Phase 40 rotary visibility filters.

Safety scope:
- Clipboard copy is local UI-only behavior.
- No G-code is modified.
- No serial command, jog, homing, spindle, or FluidNC configuration behavior is added or changed.
- Displayed coordinates are parsed-program preview values, not proof of physical machine position.

Validation performed for this source package:
- Static source assertions for the copy button, clipboard action, disabled-state handling, and bounds guards.
- XML parsing of all .ui files.
- ZIP integrity test after packaging.

Not performed:
- Qt compilation (Qt development dependencies are not available in this environment).
- Runtime GUI testing or physical machine testing.
