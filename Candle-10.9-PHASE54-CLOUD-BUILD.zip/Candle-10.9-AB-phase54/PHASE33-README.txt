Candle 10.9 – Phase 33
Bounded rotary preview tessellation

Changes
- Added a shared, finite-safe subdivision calculation for rotary preview paths.
- Large A/B angular deltas are capped at 4096 preview subdivisions per
  linear move or per generated arc chord. Normal moves retain the existing
  target density of approximately five degrees per subdivision.
- Arc subdivision totals now use a 64-bit counter to avoid integer overflow
  when combining generated arc chords with rotary subdivisions.
- Interpolation fractions are guarded against a zero subdivision total.
- These limits affect visual preview tessellation only. Original G-code,
  rotary coordinates, feed values, and controller commands are unchanged.
- A and B remain separate rotation channels; no machine kinematics or pivot
  geometry is assumed beyond the existing preview settings.

Safety and scope
- This is a graphics-resource protection, not a motion limit or machine safety
  feature. It does not alter commands sent to FluidNC.
- The preview still depends on the configured A/B rotation vectors and pivots.
  The default A-about-X and B-about-Y convention is provisional until the
  actual machine geometry is defined.

Validation performed
- Static checks confirmed the finite-safe subdivision helper is used for
  both linear and arc preview paths, the 4096 cap, and 64-bit arc totals.
- All .ui XML files were parsed successfully.
- ZIP integrity was checked after packaging.
- Qt compilation and physical machine tests were not performed.
