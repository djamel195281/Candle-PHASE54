Candle 10.9 – Phase 31
Validation of incoming five-axis status data

Changes
- Empty serial lines are ignored before the receive handler inspects the first
  character, preventing an empty-line index access.
- MPos XYZ values are parsed with conversion-status and finite-number checks.
  The XYZ position group is updated only when all three values are valid.
- Optional MPos A and B values are validated independently. Missing, malformed,
  or non-finite rotary fields preserve their last valid displayed positions.
- WCO XYZ offsets are updated only when all three values are valid. Optional
  rotary offsets A and B are validated independently and preserve their last
  valid values when omitted or malformed.
- Script-device coordinates continue to receive the displayed A/B positions,
  including retained values when the controller omits rotary fields.
- No G-code, motion command, homing, or controller configuration behavior was
  added or changed. A and B remain independent axes.

Safety and scope
- This is defensive serial-status parsing only; it commands no machine motion.
- Preserved values are the last valid values received, not proof of homing or
  current physical position after a reset, lost steps, or power interruption.
- Verify the actual FluidNC status format for the active five-axis profile.

Validation performed
- Static source assertions checked empty-line protection, finite XYZ parsing,
  and independent A/B validation for both MPos and WCO.
- All .ui XML files were parsed successfully.
- ZIP integrity was checked after packaging.
- Qt compilation and physical machine tests were not performed.
