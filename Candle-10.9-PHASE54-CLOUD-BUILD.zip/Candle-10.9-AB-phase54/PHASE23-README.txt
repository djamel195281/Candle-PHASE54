Candle 10.9 — Phase 23
Affinage de l'affichage des déplacements simultanés XYZ + A/B

Modifications :
- Les segments de trajectoire copiés dans RotaryPivotDrawer sont subdivisés
  pour l'affichage selon trois critères indépendants :
  * distance XYZ : au plus environ 2 mm par sous-segment ;
  * variation de A : au plus environ 5 degrés par sous-segment ;
  * variation de B : au plus environ 5 degrés par sous-segment.
- Le nombre de subdivisions est plafonné à 4096 par segment pour limiter
  l'utilisation mémoire et le coût de dessin.
- Les couleurs de progression existantes (exécuté / restant, A, B, A+B)
  sont conservées.
- Les coordonnées et angles sources du parseur ne sont pas modifiés.
- A et B restent traités indépendamment.

Limites importantes :
- Il s'agit d'une tessellation graphique des segments déjà fournis par le
  parseur, pas d'une interpolation temps réel entre deux rapports de position.
- Les extrémités XYZ proviennent du parseur existant. Cette phase ne calcule
  pas de nouvelle cinématique inverse, ne reconstruit pas la courbe physique
  exacte d'une pièce en rotation et ne garantit pas la trajectoire réelle
  d'un montage A/B particulier.
- Aucun G-code, paramètre FluidNC, coordonnée machine ou commande moteur
  n'est modifié.
- Aucun enlèvement de matière ni détection de collision n'est ajouté.
- Compilation Qt et essai sur machine non réalisés dans cet environnement.

Vérifications réalisées :
- Contrôle statique du nouveau calcul de subdivisions et de ses limites.
- Validation XML des interfaces Qt.
- Contrôle d'intégrité de l'archive ZIP.
