Candle 10.9 — Phase 19
A/B rotary toolpath overlay with execution progress

This phase adds a preview overlay for G-code segments that carry rotary A
and/or B coordinates. The existing GcodeViewParse has already subdivided
rotary moves and applied the configured independent A and B rotation vectors
and pivots. The rotary preview drawer now copies those parsed segment endpoints
and renders them in the same 3D scene as the rotary tables and workpieces.

Color convention:
- A-only path: orange (dim while pending, bright when marked drawn)
- B-only path: cyan (dim while pending, bright when marked drawn)
- simultaneous A/B path: violet (dim while pending, bright when marked drawn)

Progress is taken from Candle's existing LineSegment::drawn() state. The
preview is refreshed after parsing and when the sender's toolpath-shadowing
logic marks segments as completed. The drawer copies endpoint/color values;
it does not retain pointers to parser-owned LineSegment objects.

Important limitations:
- This is a 3D toolpath/progress overlay, not a Boolean stock-removal simulation.
- It does not calculate cutter diameter, flute engagement, material removal,
  collisions, holder clearance, or inverse kinematics.
- The path is shown in Candle's existing parsed preview coordinates. Correct
  alignment with a physical blank still depends on the user's work zero,
  stock placement, pivot calibration, and actual machine geometry.
- A and B remain independent in the preview. Their current convention (A about
  X and B about Y) is still provisional until confirmed against the machine.
- No G-code is modified and no additional commands are sent to FluidNC.
- Qt compilation and machine/hardware tests have not been performed here.

Checks performed for this archive:
- Static inspection of the new drawer/parser handoff and progress refresh.
- XML validation of all Qt .ui files.
- ZIP integrity test.
These checks do not replace a Qt build or an on-machine test.
