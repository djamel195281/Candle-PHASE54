Candle 10.9 – Phase 44

3D toolpath segment picking (read-only)

- A short left click on the 3D visualizer emits a scene-click event. Dragging the camera does not trigger selection.
- The G-code drawer projects visible toolpath segments through the current projection, view and model matrices, then finds the closest segment within a 10-pixel tolerance.
- The selected segment's source G-code line is mapped back to the program table. The existing row-selection handler updates the inspector and preview marker.
- Segments hidden by the A/B visibility filters are excluded from hit testing.
- The operation is read-only and never sends motion commands: it does not queue, send, home, jog, or otherwise command FluidNC.

Limitations and validation

- Hit testing uses the rendered segment endpoints. Curved moves are represented by the parser's tessellated line segments; the nearest visible segment is selected in screen space. Where paths overlap in the view, selection may choose the nearest screen-space candidate rather than the visually frontmost one.
- The 10-pixel tolerance is fixed in this phase.
- Qt compilation and hardware testing have not been performed in this environment. Compile and verify the visualizer on the target Windows/Qt setup before relying on it.
- A/B physical motion is not tested by this phase.
