Candle 10.9 — Phase 14
Independent A/B rotary-table preview geometry

Changes
- Extends the existing RotaryPivotDrawer with schematic rectangular table outlines.
- Adds an inner frame, center cross and off-centre index pointer to make rotation visible.
- A table is represented in the YZ plane and rotates about X using the live A angle.
- B table is represented in the XZ plane and rotates about Y using the live B angle.
- Each table is transformed about its own configured pivot (six settings from Phase 11).
- The two angles are evaluated independently. No G-code, machine coordinates, jog commands,
  or FluidNC outputs are changed by this drawer.

Important limitations
- The table outline is schematic (32 x 24 mm preview dimensions), not a calibrated model
  of the user's real fixtures. It is not yet configurable.
- This is wireframe preview geometry, not full solid 3D machine/stock simulation.
- It does not implement inverse kinematics, tool-center-point compensation, rotary offsets
  for the controller, collision detection, or physical machine geometry.
- The A=X and B=Y axis convention remains the provisional convention used in earlier phases.
- Qt compilation and hardware testing have not been performed in this environment.

Next recommended step
- Add user-configurable table dimensions and a clear preview visibility toggle, then compile
  with the project's supported Qt toolchain and validate against known A-only/B-only moves.
