CANDLE 10.9 - PHASE 8
A/B rotary preview refinement

DESIGN
- Keep A and B as separate G-code coordinates and separate jog commands.
- Retain the current preview convention: A about X, B about Y.
- No coupled motor commands or rotary kinematics are introduced.

CHANGE IN THIS PHASE
- Arc preview segments are now subdivided further when the rotary change
  assigned to a geometric arc chord would exceed the configured angular
  preview increment.
- The additional subdivisions interpolate each geometric chord and distribute
  both A and B rotation increments across the resulting preview segments.
- This complements the ceiling-based subdivision already present for linear
  moves in Phase 7.

LIMITATIONS
- This is a preview refinement, not full five-axis inverse kinematics.
- Rotary pivot offsets, actual machine geometry, tool orientation conventions,
  collision checking, and physical calibration are not implemented.
- A and B preview directions/orientations must be confirmed against the real
  machine before relying on the rendered path.
- No Qt build or machine test was possible in this environment.

VALIDATION
- ZIP integrity checked.
- UI XML files parsed.
- Targeted source checks performed for A/B arc and linear subdivision.
- CMake configuration attempted but stopped because Qt5 development files
  (Qt5Config.cmake) are not installed in this environment.
