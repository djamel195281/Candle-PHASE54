Candle 10.9 — Phase 34
======================

Purpose
-------
Improve the rotary preview's live tool-orientation indicator for the
independent A and B axes.

Changes
-------
- The live cutter-tip crosshair remains at the reported XYZ position.
- The preview now draws an orange tool-axis shaft and arrowhead.
- The displayed direction is calculated from the current A/B preview angles:
  start with +Z, rotate about +X by A, then about +Y by B.
- A and B are read independently from the existing rotary preview state.
- Non-finite A/B status values are rejected; the last valid preview angles
  remain in use.
- The angle calculations reduce values modulo 360 degrees before trigonometry.

Important limitations
---------------------
- The A-about-X then B-about-Y order is a visualization convention already
  used by this preview, not a verified kinematic model for the user's machine.
- This is not TCP/RTCP, pivot compensation, collision detection, stock removal,
  or a guarantee of the physical cutter orientation.
- The preview uses the existing displayed A/B angles and XYZ cutter-tip
  position. It does not change G-code, jog commands, FluidNC settings,
  homing, or machine motion.
- The A/B motors must not be moved for validation until wiring, driver
  current, limits, and the physical emergency stop are checked.

Validation
----------
- Source-level checks verify finite-angle guards and the orientation-vector
  and arrowhead code.
- Qt compilation and physical machine tests have not been performed.
