Candle 10.9 AB - Phase 50
========================

Selected-path travel totals for the multi-row XYZAB inspector.

Changes
-------
- Retains the Phase 49 selected-row count, drawable-segment count and net
  XYZAB endpoint change.
- Adds cumulative XYZ travel by summing the programmed model-space length of
  every parsed sub-segment in the selected rows.
- Adds cumulative absolute A and B travel independently, in degrees. Rotary
  degrees are deliberately not combined with linear coordinate units.
- Counts each segment index once, even if an index is repeated in the row map.
- Skips invalid row/line/segment references and reports non-finite totals as
  -- instead of presenting misleading values.
- Arc distance is the sum of the parser's preview chord segments, so its
  accuracy depends on the parser's arc subdivision resolution.

Safety / limitations
--------------------
Read-only inspection only. No G-code is changed, no commands are queued or
sent to FluidNC, and no axis movement, homing, or configuration is changed.
XYZ path length is reported in coordinate units; it is not converted between
G20/G21 modes here. A/B travel is reported separately in degrees. These are
parsed-program estimates, not measured machine travel or a guarantee of the
physical tool path.

Validation
----------
Source-level assertions and ZIP integrity checks only. Qt compilation,
interactive UI testing and physical CNC testing have not been performed.
