Candle 10.9 - Phase 3 (experimental source patch)

Adds two manual incremental jog buttons for rotary axis B (B+ and B-).
The buttons send FluidNC/Grbl-style incremental jog commands: $J=G91B...F...
They work only when a non-zero jog step is selected. Continuous B jog is intentionally
not implemented because Candle's existing shared jog vector is QVector4D (X/Y/Z/A).

This is source code only; it has not been compiled or tested against a live FluidNC
controller. Test with the B motor disconnected until the axis is physically wired,
then test at a very small step and low feed. Verify the B axis is enabled in FluidNC.
