CANDLE 10.9 — PHASE 9

Objectif : fiabiliser les informations d’axes rotatifs A et B dans les segments
de visualisation générés à partir des mouvements linéaires et des arcs.

Modification :
- Les coordonnées d’axes sont interpolées entre le début et la fin de chaque
  segment graphique subdivisé.
- Chaque sous-segment reçoit ses propres valeurs axesStart/axesEnd au lieu de
  recevoir à tort les valeurs complètes du mouvement d’origine.
- La correction s’applique aux arcs et aux lignes, sans fusionner les commandes A
  et B : chaque coordonnée reste distincte.
- Les valeurs d’axes non définies (NaN) sont traitées sans créer de calcul NaN.

Contrôles réalisés :
- Archive source Phase 8 vérifiée avant modification.
- Tous les fichiers .ui ont été analysés comme XML.
- Contrôles statiques ciblés sur l’interpolation des axes A/B effectués.

Limites :
- Compilation Qt non réalisée dans cet environnement.
- Aucun essai sur Wemos/FluidNC n’a été effectué.
- La visualisation reste une approximation géométrique ; les pivots mécaniques,
  les offsets et les cinématiques propres à la machine ne sont pas modélisés.
- L’orientation conventionnelle A autour de X et B autour de Y reste provisoire.
