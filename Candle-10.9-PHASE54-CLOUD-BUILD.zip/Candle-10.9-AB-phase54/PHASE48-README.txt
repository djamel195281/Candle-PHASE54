Candle 10.9 AB - Phase 48
========================

Purpose
-------
Allow multiple G-code source rows to be selected together and highlight all
preview segments belonging to those rows in the 3D toolpath view.

Changes
-------
- The program table now uses row selection with ExtendedSelection.
- The selected preview path is built from every selected source row, not only
the current row. Each row can contribute multiple tessellated segments,
including arc and rotary preview fragments.
- The current row remains the reference for the existing XYZAB inspector.
- Previously selected segments are cleared before the new selection is applied.
- Segment indices and source rows are bounds-checked; duplicate update indices
are removed before asking the drawer to refresh.
- Selection is visual-only: no G-code is altered and no serial/FluidNC command
is sent by this feature.

Validation
----------
- Source-level assertions and targeted checks performed for the new selection
mode and multi-row segment collection.
- ZIP archive integrity checked after packaging.
- Qt compilation, interactive UI testing, and physical machine testing have
not been performed in this environment.

Safety note
-----------
The preview is a parsed visualization, not proof of the machine's physical
position or of successful execution. Verify the work envelope, fixtures,
rotary axes, limits, and emergency stop before any real movement.
