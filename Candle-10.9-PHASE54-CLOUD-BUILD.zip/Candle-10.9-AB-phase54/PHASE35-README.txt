Candle 10.9 — Phase 35
======================

Purpose
-------
Harden the independent A/B rotary preview against invalid or extreme display data.

Changes
-------
- Pivot A and pivot B setters reject non-finite XYZ coordinates independently.
- The live tool-position setter rejects non-finite coordinates and retains the last valid position.
- Rotary plate and workpiece dimensions reject non-finite values and are bounded to 1..100000 mm.
- Rotary trigonometry reduces angles modulo 360 degrees before evaluating sine/cosine.
- The workpiece drawing applies a finite, bounded height defensively.
- A and B remain independent; no coupling, G-code, jog, homing, FluidNC, or motion changes.

Safety and limitations
----------------------
This protects the preview renderer only. It is not a machine safety system, kinematic calibration,
TCP/RTCP compensation, collision detection, or proof of physical position. The Phase 34 tool
orientation convention remains A about +X followed by B about +Y and must be validated against
the actual machine geometry before relying on the visual orientation.

Validation
----------
Static source assertions, UI XML parsing, and ZIP integrity checks are performed.
Qt compilation and physical machine tests have not been performed.
