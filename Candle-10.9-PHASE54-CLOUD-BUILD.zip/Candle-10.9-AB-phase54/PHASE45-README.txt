Candle 10.9 – Phase 45

Improved 3D toolpath picking for overlapping segments (read-only)

Changes
- Segment picking now records normalized device depth for each projected endpoint.
- When two candidates are effectively tied in screen distance (within 0.5 px²), the candidate nearer to the camera is preferred.
- Points behind the camera and points outside the normalized depth range are rejected.
- Screen-space distance remains the primary selection criterion; the existing tolerance and A/B visibility filtering are preserved.
- The existing scene-click to source-G-code-row selection remains unchanged.
- No G-code, FluidNC commands, homing, jogging, or machine configuration are modified by this phase.

Validation and limitations
- Static source checks and archive integrity checks performed.
- Qt compilation and real OpenGL visualizer testing were not performed in this environment.
- This remains endpoint-projection hit testing; clipping of segments crossing the camera near plane and exact GPU depth-buffer picking are not implemented.
- A/B physical motion is not tested by this phase.
