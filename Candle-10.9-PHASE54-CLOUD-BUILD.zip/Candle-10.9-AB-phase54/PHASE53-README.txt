Candle 10.9 AB — Phase 53

Changes
- Persists the preview-only angular envelope for axis A and axis B independently.
- Restores each axis enable checkbox and its minimum/maximum angle on startup.
- Uses QSettings under General/RotaryPreviewLimits.
- Gives the controls stable object names for diagnostics and future UI automation.
- Both checks remain disabled by default for installations without saved preferences.

Safety notes
- These are visual preflight limits only. They do not configure FluidNC, enforce motion limits,
  or replace controller-side soft limits, hard limits, homing, or emergency stop.
- The saved angles must be entered by the operator from the actual machine configuration.
- The default -360/+360 degree values are placeholders only.

Validation
- Source-level assertions and archive integrity checks performed.
- Qt compilation and runtime testing were not performed.
