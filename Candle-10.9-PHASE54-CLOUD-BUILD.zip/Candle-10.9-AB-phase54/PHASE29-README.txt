Candle 10.9 – Phase 29
Independent rotary coordinate restoration after abort/reset

Changes
- Extended frmMain::restoreOffsets() to include the saved machine-coordinate
  position for A and/or B when the corresponding axis is enabled.
- Extended the following G92 work-coordinate restoration to include A and/or B
  independently when enabled.
- A-only configurations emit A but not B; B-only configurations emit B but
  not A; configurations with both enabled emit both. Disabled axes are omitted.
- Existing XYZ restoration and unit-mode prefix are retained.
- No A/B coupling, automatic homing, startup movement, or new controller
  configuration behavior has been introduced.

Safety note
- This routine is used during Candle's existing abort/reset recovery flow.
  G53 restoration is a machine-coordinate move, so enabling A/B means the
  recovery sequence may command those axes to their previously reported
  machine positions. Before enabling rotary recovery on a real machine, verify
  A/B wiring, driver current, direction, travel limits, physical emergency stop,
  and that the controller reports valid machine coordinates. Do not test A/B
  motion until the hardware is commissioned safely.
- This is sender-side coordinate recovery, not a substitute for FluidNC
  homing, hard limits, or a physical emergency stop.

Validation performed
- Source-level assertions verified the conditional A/B additions in both
  G53 and G92 recovery commands.
- Existing UI XML files were parsed successfully.
- ZIP integrity was checked after packaging.
- Qt compilation and physical machine tests were not performed.
