Candle 10.9 – Phase 26
Independent rotary jog controls for A and B

Changes
- Added a dedicated Rotary step (°) selector in the Jog panel.
- Available increments: 0.1°, 1°, 5°, 10°, 45°.
- Default rotary increment: 1°.
- Added a dedicated Rotary feed (°/min) selector.
- Available rotary jog feeds: 10, 30, 60, 100, 180 degrees/minute.
- Default rotary feed: 30 degrees/minute, deliberately conservative.
- Existing A+/A- and B+/B- controls use the rotary degree increment and rotary feed.
- XYZ jog continues to use the original linear step and linear feed selectors.
- Incremental and continuous rotary jog commands include only the axis or axes actually requested. A-only jog does not include B; B-only jog does not include A.
- A and B remain separate G-code coordinates; no coupling or automatic movement is introduced.
- No movement is issued when the application opens; a command is sent only after an explicit jog-button press.

Safety and limitations
- Continuous rotary jogging retains Candle's existing continuous-jog behavior and its existing one-turn jog distance, but now uses the dedicated rotary feed.
- This phase does not change FluidNC configuration, motor wiring, driver current, homing, limits, or machine kinematics.
- The rotary feed is a software jog setting. Confirm it is suitable for the configured rotary axis and mechanics before testing.
- A/B motors were previously reported as not yet wired. Do not test rotary movement until the drivers, motor wiring, limits, and emergency stop have been checked.
- No Qt compilation or physical machine test was performed in this environment.
