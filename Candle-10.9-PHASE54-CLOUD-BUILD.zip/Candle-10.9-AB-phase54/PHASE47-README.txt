Candle 10.9 AB - Phase 47

Selected G-code row path highlighting
-------------------------------------
- Selecting a G-code row now highlights every drawable LineSegment indexed
  for that source line, rather than only the final fragment. This matters
  for tessellated arcs and rotary-preview paths that produce multiple pieces.
- Previous selected fragments are cleared before the new row is highlighted.
- Invalid/null segment indices are ignored and update indices are deduplicated.
- The existing inspector and endpoint marker continue to use the selected row.
- This is a visual-only change: no G-code is rewritten and no command is sent
  to FluidNC.

Validation performed: source-level assertions, UI XML parsing, ZIP integrity.
Qt compilation and physical machine testing have not been performed.
