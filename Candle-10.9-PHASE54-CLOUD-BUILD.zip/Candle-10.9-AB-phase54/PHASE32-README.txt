Candle 10.9 – Phase 32
Independent validation of all five-axis status components

Changes
- MPos values X, Y, Z, A and B are now validated and applied independently.
  A malformed XYZ component no longer prevents a valid rotary coordinate
  from being updated, and vice versa.
- WCO offsets X, Y, Z, A and B are likewise validated and retained per axis.
  Missing, malformed, or non-finite components preserve only their own last
  valid value; valid components in the same status report are still applied.
- Script-device machine coordinates continue to be refreshed from the last
  valid displayed values after each MPos report.
- Existing empty-line protection, finite-number checks, rotary jog behavior,
  and independent A/B controls are retained.
- No movement commands, homing behavior, or FluidNC configuration changes
  were introduced.

Safety and scope
- This is serial-status data handling only and commands no machine motion.
- Retained coordinates are the last valid values received. They do not prove
  physical position after a reset, lost steps, or power interruption.
- The parser continues to expect the FluidNC/Grbl-style ordered MPos and WCO
  fields: X,Y,Z and optional A,B. Confirm the actual controller report format.

Validation performed
- Source assertions verified per-axis finite checks for MPos and WCO and the
  preservation of independent A/B parsing.
- All .ui XML files were parsed successfully.
- ZIP integrity was checked after packaging.
- Qt compilation and physical machine tests were not performed.
