Candle 10.9 – Phase 28
Jog feed validation for linear and rotary movement

Changes
- Incremental jog now rejects a non-finite or non-positive linear step value.
- Incremental jog validates the selected feed before building/sending the jog command.
- Continuous jog applies the same finite, positive feed validation.
- Rotary-only jog continues to use the dedicated rotary feed selector; linear or mixed jog continues to use Candle's linear feed selector.
- Invalid feed values are not sent to FluidNC.
- A and B remain independent; no coupling, homing, configuration, or automatic movement is introduced.

Safety and limitations
- This is a sender-side input validation guard, not a replacement for FluidNC limits or a physical emergency stop.
- No motor command is issued on application startup.
- Verify A/B wiring, driver current, limits, and emergency-stop operation before physical rotary tests.
- Qt compilation and physical machine testing were not performed in this environment.

Verification
- Static source checks confirm feed validation in incremental and continuous jog paths.
- All .ui XML files are parsed as XML.
- Archive integrity is checked after packaging.
