Candle 10.9 – Phase 40
Independent A/B toolpath visibility filters

Changes
- Adds two preview-only checkboxes: Show A moves and Show B moves.
- A segments are hidden when the A filter is disabled; B segments are hidden when the B filter is disabled.
- A+B simultaneous segments are shown only when both A and B filters are enabled.
- Filters are enabled by default, preserving the complete toolpath view on startup.
- Vector and raster preview generation both honor the filters.
- Hidden vector segments have their vertex index reset to -1 so later incremental color updates cannot write to stale geometry positions.
- Changing either filter rebuilds the preview geometry.
- No G-code text, parser coordinates, sender commands, jogging, homing, or FluidNC configuration is changed.

Safety and limitations
- These are display filters only. Hiding a segment does not remove it from the G-code program and does not prevent the machine from executing it.
- A+B segments are intentionally hidden if either rotary-axis filter is off, because the combined segment depends on both axes.
- This change has not been compiled with Qt and has not been tested on a physical CNC machine.
