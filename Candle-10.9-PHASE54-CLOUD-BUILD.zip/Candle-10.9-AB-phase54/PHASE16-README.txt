Candle 10.9 — Phase 16
======================

Purpose
-------
Add a schematic workpiece (stock) preview attached independently to rotary
preview tables A and B.

Implementation
--------------
- RotaryPivotDrawer now draws a wireframe rectangular stock for each visible
  rotary table.
- The stock is transformed using the same independent pivot and live angle as
  its associated table.
- A stock is attached to the A table (rotation about X in the current preview
  convention); B stock is attached to the B table (rotation about Y).
- The preview stock uses 60% of the configured table width and depth, with a
  schematic 8 mm thickness and a 1 mm clearance from the table plane.
- Hiding a table also hides its associated stock.
- This is preview-only. It does not alter G-code, FluidNC settings, motor
  commands, work offsets, or machine kinematics.

Important limitations
---------------------
- The stock is a wireframe box, not a solid shaded model and not a simulation
  of material removal.
- The dimensions and mounting side are provisional visual defaults, not
  measured machine/fixture dimensions.
- A and B are displayed as separate independent preview fixtures. No physical
  nesting/serial kinematic relationship is assumed.
- No collision detection, tool/stock intersection, inverse kinematics, or
  physical machine validation is included.
- Qt compilation and hardware tests have not been performed in this build
  environment.

Next recommended phase
----------------------
Expose stock width, depth, and thickness in Settings, then add a selectable
stock shape and a true material-removal simulation only after the machine's
real rotary geometry and fixture arrangement are defined.
