Candle 10.9 — Phase 25
Moniteur compact des cinq axes XYZAB

Modifications :
- Ajout d'un moniteur permanent dans la barre d'état de la fenêtre principale.
- Affichage des coordonnées de travail X, Y et Z en millimètres selon les
  unités déjà présentées par les champs de coordonnées de Candle.
- Affichage séparé des angles A et B en degrés.
- Affichage d'un pourcentage de progression calculé à partir de l'index de
  commande traité et du nombre de lignes du programme.
- Le moniteur est rafraîchi lors de la réception des états qui actualisent les
  champs de coordonnées.
- A et B restent affichés séparément. Aucun couplage mécanique n'est introduit.

Limites :
- Le pourcentage est une estimation par lignes/commandes traitées, pas une
  progression pondérée par la durée ou la distance réelle.
- L'affichage reprend les champs de coordonnées de Candle; il ne constitue pas
  une mesure indépendante des encodeurs.
- L'ajout est purement visuel : aucun G-code, paramètre FluidNC ou commande
  moteur n'est modifié.
- Compilation Qt et essai sur machine non réalisés dans cet environnement.

Vérifications réalisées :
- Contrôle statique des nouveaux membres, initialisation et mise à jour.
- Validation XML des interfaces Qt.
- Contrôle d'intégrité de l'archive ZIP.
