Candle 10.9 AB - Phase 49
========================

Multi-row XYZAB selection summary in the read-only movement inspector.

Changes
-------
- Keeps the current row's existing movement details in the inspector.
- When more than one G-code row is selected, appends the selected row count
  and the total number of valid drawable line segments represented by those
  rows.
- Sorts selected rows into program order and reports the net XYZAB change
  from the first selected drawable segment's programmed start to the last
  selected drawable segment's programmed end.
- Invalid row/line/segment indexes are skipped; non-finite coordinate deltas
  are shown as -- rather than formatted as misleading numbers.
- The existing Copy action copies the expanded inspector text.

Safety / limitations
--------------------
This is a preview/inspection-only change. It does not alter G-code, enqueue
commands, communicate with FluidNC, move axes, or change homing/configuration.
The net change is a programmed endpoint difference, not total path length and
not proof of the machine's physical position. Selection and preview accuracy
still depend on Candle's parser and the loaded G-code.

Validation
----------
Source-level checks and archive integrity checks only. Qt compilation,
interactive UI testing, and physical CNC testing have not been performed.
