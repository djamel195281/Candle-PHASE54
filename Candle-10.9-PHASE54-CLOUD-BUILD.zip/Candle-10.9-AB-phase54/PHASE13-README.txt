Candle 10.9 — Phase 13: live independent A/B rotary indicators

Changes
-------
- RotaryPivotDrawer now accepts independent live A and B angles in degrees.
- The A pivot ring (axis X, YZ plane) displays a radial pointer that follows A.
- The B pivot ring (axis Y, XZ plane) displays its own radial pointer that follows B.
- frmMain updates both indicators from the current WPos A/B values received in
  FluidNC status reports. The pivot centers remain those configured in Phase 11.
- The indicators are preview-only. They do not issue motion commands, alter G-code,
  or change the controller's machine coordinates.

Conventions and limitations
---------------------------
- Preview convention: A rotates about +X; B rotates about +Y.
- Positive-angle pointer direction follows the right-hand rule.
- The two pointers show angular orientation at the current reported work position.
  They are not physical rotary tables, full machine kinematics, or a collision model.
- Correct physical interpretation still depends on measured pivot centers, the real
  machine's axis directions, work offsets, and the configured FluidNC axis mapping.
- No Qt compilation or physical machine test was possible in this environment.

Validation performed
--------------------
- ZIP integrity check.
- XML parsing of all .ui files.
- Static checks for independent A/B angle storage, pointer geometry, and live update.
