Candle 10.9 AB - Phase 46

This phase adds a distinct visual selection state for one drawable toolpath
segment associated with the currently selected G-code row.

Changes:
- LineSegment now stores an independent selected flag. Constructors initialize
  it safely and the copy constructor preserves it.
- The selected segment is rendered in a dedicated amber/yellow color, with
  priority over executed-path and ordinary highlight colors.
- When the current G-code row changes, the previous selected segment is cleared
  and the last valid drawable segment mapped to the new row is selected.
- Selection is visual-only; it does not issue serial commands or change G-code.

Validation:
- Source-level assertions and diff checks performed.
- ZIP integrity test performed after packaging.
- Qt compilation and runtime/3D interaction tests were not performed here.
